#!/usr/bin/env python3
"""genesis_header_check.py — the standing test for the Numina genesis claim.

Question it answers: given a block-0 header's fields, does the standard
Ethereum header hash (Keccak-256 of the RLP-encoded header) reproduce the
recorded genesis value 0xea95dac2...b53e1 for chain 962421430?

Status as of 2026-10-20: the harness is built and CALIBRATED against
Ethereum mainnet block 0, whose header fields and hash are public ground
truth (see --calibrate). The Numina receipt JSON (raw SHA-256 5dd92b85...)
and its header fields have never been produced, so the Numina check itself
remains UNRUN. Supply the fields and the verdict takes seconds.

Input format (JSON): {"fields": ["0x...", ...], "expected": "0x..."}
  * fields are the header's field VALUES as raw byte strings in hex, in
    header order. Quantities use minimal big-endian form; quantity 0 is
    the empty string ("0x"). This is exactly how a block header is built
    from a JSON-RPC block object.
  * For a pre-merge header the order is: parentHash, ommersHash,
    beneficiary, stateRoot, transactionsRoot, receiptsRoot, logsBloom,
    difficulty, number, gasLimit, gasUsed, timestamp, extraData,
    mixHash, nonce. Post-merge headers append baseFeePerGas and later
    fields; include whatever the receipt records, in order.

No third-party dependencies: Keccak-256 is implemented here directly
(original Keccak padding 0x01..0x80 — NOT NIST SHA3-256).
"""

import json
import sys

# ---------------- Keccak-256 (Keccak-f[1600]) ----------------

_RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
_ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]
_MASK = (1 << 64) - 1


def _rotl(x, n):
    return ((x << n) | (x >> (64 - n))) & _MASK if n else x


def _keccak_f(state):
    for rc in _RC:
        # theta
        c = [state[x] ^ state[x + 5] ^ state[x + 10] ^ state[x + 15] ^ state[x + 20]
             for x in range(5)]
        d = [c[(x - 1) % 5] ^ _rotl(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                state[x + 5 * y] ^= d[x]
        # rho + pi
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = _rotl(state[x + 5 * y], _ROT[x][y])
        # chi
        for x in range(5):
            for y in range(5):
                state[x + 5 * y] = (b[x + 5 * y]
                                    ^ ((~b[(x + 1) % 5 + 5 * y]) & b[(x + 2) % 5 + 5 * y])) & _MASK
        # iota
        state[0] ^= rc


def keccak_256(data: bytes) -> bytes:
    rate = 136  # (1600 - 2*256) / 8
    padded = bytearray(data)
    padded.append(0x01)
    while len(padded) % rate != rate - 1:
        padded.append(0x00)
    padded.append(0x80)
    state = [0] * 25
    for off in range(0, len(padded), rate):
        block = padded[off:off + rate]
        for i in range(rate // 8):
            state[i] ^= int.from_bytes(block[8 * i:8 * i + 8], "little")
        _keccak_f(state)
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out += state[i].to_bytes(8, "little")
        if len(out) >= 32:
            break
        _keccak_f(state)
    return bytes(out[:32])


# ---------------- RLP ----------------

def _rlp_bytes(b: bytes) -> bytes:
    if len(b) == 1 and b[0] < 0x80:
        return b
    if len(b) <= 55:
        return bytes([0x80 + len(b)]) + b
    lb = len(b).to_bytes((len(b).bit_length() + 7) // 8, "big")
    return bytes([0xB7 + len(lb)]) + lb + b


def rlp_encode(item) -> bytes:
    if isinstance(item, (bytes, bytearray)):
        return _rlp_bytes(bytes(item))
    if isinstance(item, list):
        payload = b"".join(rlp_encode(x) for x in item)
        if len(payload) <= 55:
            return bytes([0xC0 + len(payload)]) + payload
        lp = len(payload).to_bytes((len(payload).bit_length() + 7) // 8, "big")
        return bytes([0xF7 + len(lp)]) + lp + payload
    raise TypeError(f"cannot RLP-encode {type(item)}")


def header_hash(fields) -> str:
    return "0x" + keccak_256(rlp_encode(fields)).hex()


# ---------------- Calibration: Ethereum mainnet block 0 ----------------

def _h(hexstr):
    return bytes.fromhex(hexstr[2:] if hexstr.startswith("0x") else hexstr)


MAINNET_GENESIS_FIELDS = [
    _h("0x" + "00" * 32),                                            # parentHash
    _h("0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347"),  # ommersHash
    _h("0x" + "00" * 20),                                            # beneficiary
    _h("0xd7f8974fb5ac78d9ac099b9ad5018bedc2ce0a72dad1827a1709da30580f0544"),  # stateRoot
    _h("0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421"),  # transactionsRoot
    _h("0x56e81f171bcc55a6ff8345e692c0f86e5b48e01b996cadc001622fb5e363b421"),  # receiptsRoot
    _h("0x" + "00" * 256),                                           # logsBloom
    (17179869184).to_bytes(5, "big"),                                # difficulty
    b"",                                                             # number = 0
    (5000).to_bytes(2, "big"),                                       # gasLimit
    b"",                                                             # gasUsed = 0
    b"",                                                             # timestamp = 0
    _h("0x11bbe8db4e347b4e8c937c1c8370e4b5ed33adb3db69cbdb7a38e1e50b1b82fa"),  # extraData
    _h("0x" + "00" * 32),                                            # mixHash
    _h("0x0000000000000042"),                                        # nonce
]
MAINNET_GENESIS_HASH = "0xd4e56740f876aef8c010b86a40d5f56745a118d0906a34e69aec8c0db1cb8fa3"

NUMINA_RECORDED_GENESIS = "0xea95dac2ad854c835bc526d6be70a5a4614ccd47412a4bc710308b41010b53e1"


def calibrate():
    got = header_hash(MAINNET_GENESIS_FIELDS)
    ok = got == MAINNET_GENESIS_HASH
    print(f"calibration: computed {got}")
    print(f"calibration: expected {MAINNET_GENESIS_HASH}")
    print("calibration:", "PASS — Keccak+RLP harness reproduces mainnet block 0"
          if ok else "FAIL — harness is wrong, do not trust its verdicts")
    return ok


def main(argv):
    if len(argv) == 2 and argv[1] == "--calibrate":
        return 0 if calibrate() else 1
    if len(argv) != 2:
        print(__doc__)
        print("usage: genesis_header_check.py --calibrate | fields.json")
        return 2
    if not calibrate():
        return 1
    with open(argv[1]) as f:
        spec = json.load(f)
    fields = [_h(x) for x in spec["fields"]]
    expected = spec.get("expected", NUMINA_RECORDED_GENESIS).lower()
    got = header_hash(fields)
    print(f"computed header hash: {got}")
    print(f"expected            : {expected}")
    print("verdict:", "MATCH — independent derivation CONFIRMED"
          if got.lower() == expected else
          "NO MATCH — the supplied fields do not reproduce the recorded value")
    return 0 if got.lower() == expected else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
