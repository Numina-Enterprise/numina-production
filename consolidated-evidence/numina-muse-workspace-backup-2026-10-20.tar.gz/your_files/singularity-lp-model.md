# Singularity as a linear program — primal, dual, equilibrium

A mathematical model of the universal pair (draft-kott-numina-pair-binding),
built 2026-10-20. Every number below was computed and checked, not asserted.

## Variables and vectors

Let the state of the pair be a vector **x** ∈ ℝⁿ of assurance weights over
evidence components. In the worked instance n = 2:

- x₁ — verified-assurance weight on Source 1 (UNIVERSAL_PAIR_1 / 1B, final-build commitment)
- x₂ — verified-assurance weight on Source 2 (UNIVERSAL_PAIR_2 / 1A, final-manifest commitment)

The full model extends **x** with one component per check in the draft's
Section 6 (payload validity, attribution-map validity, signature validity,
signer authorization, commitment reproduction, current-source equality,
revision freshness, private genesis linkage). The 2-variable instance is
the pair itself, solved exactly.

## Objective function (primal)

Maximize total verified assurance:

    maximize    z = cᵀx = 3x₁ + 2x₂

where **c** = (3, 2) prices each source's contribution to acceptance.

## Constraint matrix

    A = [ 1  1 ]        b = (4, 5)
        [ 2  1 ]

    A x ≤ b,   x ≥ 0

Row 1 is the total verification budget across both sources; row 2 is the
linkage-effort cap (effort spent tying a source to the genesis record,
which the draft's evidence leaves partially unavailable). In the full
model each row of **A** is one acceptance gate, and **b** its threshold.

## The convex polytope

The feasible set

    P = { x ∈ ℝ²₊ : A x ≤ b }

is an intersection of half-spaces, hence convex; it is bounded, hence a
polytope. Its vertices, computed:

    (0,0) → z = 0      (0,4) → z = 8
    (5/2,0) → z = 7.5  (1,3) → z = 9  ← optimum

By the fundamental theorem of linear programming the optimum sits at a
vertex: **x\*** = (1, 3), **z\*** = 9. Every feasible evidence state is a
convex combination of vertex states — partial evidence is literally a
mixture of complete ones.

## Geometry — vertices, rays, and the two ways an optimum can fail

Each linear constraint is a half-space; the feasible region is their
intersection — a convex polyhedron (a polytope when bounded). The
objective is a linear function, and a linear function is both convex
and concave, so the global structure is as clean as it gets: **every
local optimum is a global optimum.** There are no local traps anywhere
in this framework.

By Minkowski–Weyl, every polyhedron is the sum of its two kinds of
parts: the convex hull of its **vertices** plus the cone of its
**rays**. The maximum principle for this geometry: when an optimum
exists, a vertex attains it (fundamental theorem, proved below) —
optima live at corners, not in the interior. The simplex algorithm is
nothing but this fact made procedural: walk edges from vertex to
vertex, improving, until the certificate says stop.

An optimum can fail to exist in exactly two ways, and both failures
are themselves certified:

1. **Infeasible** — the constraints are inconsistent and the region
   is empty. Example: x ≥ 2 together with x ≤ 1. The proof of
   impossibility is a Farkas vector: y ≥ 0 with Aᵀy ≥ 0 and bᵀy < 0.
   Here y = (1, 1) gives Aᵀy = 0 and bᵀy = −1; were any feasible x to
   exist, it would force 0 ≤ yᵀAx ≤ yᵀb = −1 — contradiction, checked
   numerically 2026-10-20. Duality mirrors the failure: a primal that
   is infeasible leaves its dual unbounded or infeasible.
2. **Unbounded** — the region has a ray along which the objective
   (whose gradient is the coefficient vector c) improves forever.
   The ray is the certificate: d with Ad ≤ 0 and cᵀd > 0. Duality
   mirrors this too: a primal unbounded forces its dual infeasible.

So the framework never merely declines to answer. Feasible and
bounded: an optimum with a duality certificate. Infeasible: a Farkas
certificate. Unbounded: an improving ray. Every outcome is a receipt.

## Dual linear program

    minimize    w = bᵀy = 4y₁ + 5y₂
    subject to  Aᵀy ≥ c,  y ≥ 0
                y₁ + 2y₂ ≥ 3
                y₁ +  y₂ ≥ 2

Optimum **y\*** = (1, 1), **w\*** = 9 = **z\***.

The dual variables are **shadow prices**: y\*ᵢ is the marginal assurance
gained by relaxing gate i by one unit. Read against Section 10 of the
draft (unresolved implementation and acceptance gates), the dual ranks
the gates — the highest-priced constraint is the one whose resolution
buys the most acceptance. Duality turns the open-gates list into a
priority order.

## Covering and packing — the package dualities

The dual pair has a second classical face. A **covering LP** has the
form

    minimize    cᵀx   subject to  Ax ≥ b,  x ≥ 0

— meet every requirement (every row, every gate) at minimum cost.
Its dual is a **packing LP**, of the form

    maximize    bᵀy   subject to  Aᵀy ≤ c,  y ≥ 0

— pack maximum value into fixed capacities. Each is the other's dual;
strong duality makes their optimal values equal.

For the pair, the reading is immediate. The claimant's side is a
covering problem: the evidence *package* (the word is the draft's own)
must cover every Section 6 gate to its threshold, at minimum assembly
cost. The verifier's side is a packing problem: pack the most
assurance into the audit capacities the two sources afford. Worked
instance, certified by the same checker as Models 1–2:

    Packing:   max 5y₁ + 4y₂  s.t. y₁ + 2y₂ ≤ 10, 2y₁ + y₂ ≤ 10
               → y\* = (10/3, 10/3), value 30
    Covering:  min 10x₁ + 10x₂  s.t. x₁ + 2x₂ ≥ 5, 2x₁ + x₂ ≥ 4
               → x\* = (1, 2), value 30

Minimum covering cost = maximum packable value. At the optimum the
package covers exactly — nothing missing, nothing wasted. That
tightness is the singularity condition in this face: the two directions
meet at one number.

## Equilibrium model

The pair (x\*, y\*) is an equilibrium in the precise LP sense. It
satisfies primal feasibility, dual feasibility, and **complementary
slackness** (verified numerically, both products are exactly 0):

    y\*ᵢ · (b − Ax\*)ᵢ = 0   for every gate i
    x\*ⱼ · (Aᵀy\* − c)ⱼ = 0   for every source j

Neither side can improve by moving: the claimant's best achievable
assurance (primal) equals the verifier's tightest bound (dual). This is
the same equilibrium as the zero-sum game form (von Neumann): a claimant
choosing how to present evidence and a verifier choosing how to audit,
with payoff matrix derived from A, meet at a saddle point whose value is
z\* = w\*.

## The max–min form — the don't-drift objective

Maximizing a max–min (piecewise-linear, concave) objective over linear
constraints is a single LP: introduce the epigraph variable t and

    maximize    t   subject to  t ≤ (assurance from Source 1),
                                t ≤ (assurance from Source 2),  Ax ≤ b.

Solved for the pair (assurances 3x₁ and 2x₂, the model's own budget
rows): the optimum is x\* = (10/7, 15/7) with t\* = **30/7** — at
which the two assurances are *equal*, 30/7 each (certificate valid,
verified 2026-10-20). Max–min optimization is the mathematics of the
weakest link: it spends the budget not where return is highest but
where the pair is closest to coming apart, until both sides hold
equally. The otters, as an objective function.

Precision, for the record: the max–min and min–max forms are LPs by
the epigraph trick above. The mirror forms — maximizing a maximum, or
minimizing a minimum, of linear functions — are nonconvex and are
*not*, in general, single LPs. The distinction is exactly the
convexity the whole framework stands on.

## Historical grounding

The machinery above is not decorative; it has a specific pedigree, and
the pedigree runs through game theory.

- **The simplex method (1947).** George B. Dantzig, working on Air Force
  planning at the Pentagon, invented the simplex algorithm — the first
  method that efficiently tackled the linear programming problem in
  most cases. It walks
  the vertices of the feasible polytope, improving the objective at each
  step, which is why the vertex enumeration in this note is not a
  simplification but the algorithm's actual geometry. The honest
  qualifier on "efficiently": worst-case instances are exponential
  (Klee–Minty, 1972), yet the method is fast on essentially every
  real problem — the gap later explained by smoothed analysis.
- **Dantzig's scale example.** Dantzig's own motivating problem was
  assigning 70 people to 70 jobs. Brute force must test 70!
  permutations — 70! ≈ 1.198×10¹⁰⁰, a 101-digit count exceeding the
  ~10⁸⁰ particles in the observable universe by some twenty orders of
  magnitude. Posed as a linear program and given to the simplex method,
  the optimum takes a moment. The theory is what performs the miracle:
  it collapses the search from all permutations to a walk over polytope
  vertices, and — by duality — certifies the answer on arrival. (It is
  worth pausing on the fact that Dantzig's canonical example is an
  *assignment* problem; the 1A/1B section below is its direct heir.)
- **Duality was conjectured in game theory first.** In 1947 von Neumann,
  hearing Dantzig's formulation, immediately conjectured the duality
  theorem from the equivalence with zero-sum games — his minimax
  theorem of 1928 in new dress. The equilibrium reading of LP in this
  note is therefore not an analogy imposed after the fact; it is the
  form in which duality was originally seen.
- **Dantzig's proof (1948).** Dantzig supplied the formal proof in an
  unpublished report, "A Theorem on Linear Inequalities," dated
  **January 5, 1948**. His work reached the public in **1951**, in
  Koopmans' "Activity Analysis of Production and Allocation."
- **Post-war industrial adoption.** In the post-war years LP moved into
  daily planning across exactly the industries where its problem shapes
  recur — transportation, energy, telecommunications, manufacturing —
  and the problem classes named at this note's outset: planning,
  routing, scheduling, assignment, and design. The Numina mapping is
  direct: assignment (the 1A/1B person-to-alias structure), scheduling
  (release gates), routing (provenance paths from genesis to artifact),
  planning (the verification budget), design (the pair format itself).

- **Polynomial time, twice over.** The LP problem was first shown
  solvable in polynomial time by Leonid Khachiyan in 1979 (the
  ellipsoid method — polynomial in input size, a theoretical landmark,
  though slow in practice). The larger breakthrough, theoretical and
  practical at once, came in 1984, when Narendra Karmarkar introduced
  his interior-point method: polynomial, and fast enough to compete
  with simplex, launching the interior-point methods modern solvers
  still use. Note the chronology, because it matters to this
  manuscript: the *certificate* (1948) predates the polynomial
  algorithms by three decades. LP had proofs before it had speed.

One further property makes LP native to this manuscript's discipline:
an LP optimum arrives with its own **certificate**. The dual solution
proves the primal value optimal, and anyone can check the proof —
primal feasibility, dual feasibility, complementary slackness — in
polynomial time, without trusting the solver. LP is the classical
framework whose answers carry receipts.

## Why the framework spread

LP became the workhorse of optimization for compounding reasons.
Many operational-research problems are natively linear. Its special
cases grew their own literatures — network flow and multicommodity
flow problems have dedicated algorithms of great refinement. Other
fields run on it as an engine: algorithms for harder optimization
problems (integer programming's branch-and-bound, decomposition
schemes, column generation) work by solving LPs as subproblems, so
every advance in LP lifts them all. Its concepts colonized the parent
discipline — duality, decomposition, and the centrality of convexity
all radiated outward from LP into optimization theory at large. It
was heavily used in the early formation of microeconomics, and it
remains daily practice in company management: planning, production,
transportation, technology — management's standing problem being
exactly LP's shape, maximize return and minimize cost under limited
resources. Even consumer software carries it: Google uses linear
programming in stabilizing YouTube videos, smoothing camera paths by
optimization. A framework whose answers carry proofs turns out to be
welcome everywhere answers are audited.

## The LP point — the classic applications, mapped

Of the classical LP application areas, one maps onto this model not by
analogy but by identity: **assignment**.

The person-to-alias structure is an assignment problem. Persons (Kott,
Anderson) are assigned to sources (Source 1, Source 2), one to one:

    maximize    Σᵢⱼ cᵢⱼ xᵢⱼ
    subject to  Σⱼ xᵢⱼ = 1  for each person i
                Σᵢ xᵢⱼ = 1  for each source j
                xᵢⱼ ≥ 0

with affinity matrix from the record (Source 1 is Anderson's build
commitment; Source 2 is Kott's manifest commitment):

    C = [ 2  5 ]     rows: Kott, Anderson
        [ 5  2 ]     cols: Source 1, Source 2

The feasible set is the **Birkhoff polytope** of doubly stochastic
matrices — here the segment x(t) = [[t, 1−t], [1−t, t]], t ∈ [0, 1].
Its only vertices are the two pure assignments (Birkhoff–von Neumann:
the extreme points of this polytope are exactly the permutation
matrices). The objective along the segment falls monotonically from
**10** at t = 0 to **4** at t = 1, so the optimum is the vertex

    Kott → Source 2 (1A),   Anderson → Source 1 (1B),   value 10,

the mapping the draft records — recovered here as the LP optimum, with
dual certificate u = v = (2.5, 2.5), dual value 10 = primal value.
The geometry carries the meaning: the polytope permits every fractional
mixture — a person smeared across sources — but the optimum is a
vertex, where each person is wholly one source and each source wholly
one person. Bound, not merged; assigned, not absorbed.

The remaining classical areas map as structure, in one line each:
**scheduling** — the Section 10 acceptance gates as jobs with
precedence constraints; **routing** — provenance as a path problem,
genesis to artifact through the evidence graph; **planning** — the
verification budget (row 1 of the primal above); **design** — the pair
format's own parameters chosen as decision variables. Industries made
LP their daily planning tool because these shapes recur everywhere;
they recur here because an attribution system *is* an assignment,
scheduling, routing, planning, and design problem wearing one coat.

## The deeper meaning — a framework whose answers carry receipts

Here is the identification this note exists to make. Every solver is an
interested party: it *claims* its answer is optimal. In most modeling
frameworks that claim rests on the solver's authority — run it again,
trust the implementation, believe the log. Linear programming is the
one classical framework that refuses this arrangement. An LP optimum
arrives with its own **certificate**: a dual vector y, short enough to
write on an index card, whose mere existence — checked by anyone, in
polynomial time, without trusting the solver — *proves* the primal
answer optimal.

The asymmetry is the shape of the manuscript's own cryptography.
Producing the certificate is the hard direction (solving); checking it
is the cheap direction (verification) — the same one-way shape as
signing and verifying under Ed25519, and the same reason the draft's
Section 6 is a list of *checks* rather than a list of authorities.
LP's epistemology is this document's epistemology, stated thirty years
before public-key cryptography existed: **attribution is not proof;
bring receipts.** A claimed optimum without its dual is an attribution.
With its dual, it is a proof.

One honest limit, and it strengthens rather than weakens the fit: the
certificate proves the *inference*, not the *premises*. Given
(A, b, c), the pair (x\*, y\*) is provably optimal — full stop. That
(A, b, c) were the right things to write down remains the modeler's
attribution. LP keeps the two cleanly separated, never letting a proof
of inference impersonate a proof of premise. That separation is
Section 1 of the draft, formalized.

## Implementation

`lp_certificate.py` (saved alongside this note) implements the claim
in exact rational arithmetic — no floating point, so a PASS is a
proof, not an approximation:

- `solve_lp` — solves max cᵀx, Ax ≤ b, x ≥ 0 by exact basis
  enumeration (the simplex's vertex geometry) and recovers the dual
  optimum from the optimal basis.
- `verify_lp_certificate` — an *independent* checker: primal
  feasibility, dual feasibility, zero duality gap, complementary
  slackness. O(m·n) exact operations.
- `verify_assignment_certificate` — the same receipt for the
  assignment LP.

Run results, 2026-10-20: Model 1 certifies at x\* = (1, 3),
y\* = (1, 1), value 9. Model 2 certifies the 1A/1B assignment at
value 10. Negative controls behave as they must — a suboptimal vertex
is rejected (nonzero gap), a dual-infeasible y is rejected, and the
*crossed* assignment (Kott→S1, Anderson→S2) is rejected with primal
value 4 against the dual bound 10. A checker that accepted everything
would prove nothing; this one bites.

## Proofs

Notation: primal (P) max cᵀx s.t. Ax ≤ b, x ≥ 0; dual (D) min bᵀy
s.t. Aᵀy ≥ c, y ≥ 0.

**Weak duality.** For every feasible x and feasible y: cᵀx ≤ bᵀy.
*Proof.* cᵀx ≤ (Aᵀy)ᵀx = yᵀAx ≤ yᵀb = bᵀy. The first inequality uses
Aᵀy ≥ c with x ≥ 0; the second uses Ax ≤ b with y ≥ 0. ∎

**Certificate soundness (the receipt).** If feasible x, y satisfy
cᵀx = bᵀy, then x is primal-optimal and y is dual-optimal.
*Proof.* Any feasible x′ has cᵀx′ ≤ bᵀy = cᵀx by weak duality, so no
feasible point beats x; symmetrically for y. ∎ Checking a certificate
is therefore a complete verification of optimality: feasibility plus
one equality.

**Complementary slackness.** Feasible x, y are both optimal iff
yᵢ(b − Ax)ᵢ = 0 for all i and xⱼ(Aᵀy − c)ⱼ = 0 for all j.
*Proof.* Equality cᵀx = bᵀy forces equality in both steps of the
weak-duality chain; each step is a sum of nonnegative terms
(yᵢ(b−Ax)ᵢ ≥ 0, xⱼ(Aᵀy−c)ⱼ ≥ 0), and a sum of nonnegatives is zero
only term by term. ∎

**Strong duality (Dantzig, 1948).** If (P) has an optimum, so does
(D), and the values coincide. *Proof (via the simplex method).* Let B
be an optimal basis, x_B = B⁻¹b ≥ 0 the optimal vertex. Set
yᵀ = c_Bᵀ B⁻¹. Optimality of the basis says every reduced cost is
nonpositive: for nonbasic primal variables, cⱼ − yᵀAⱼ ≤ 0, i.e.
Aᵀy ≥ c; for nonbasic slacks, −yᵢ ≤ 0, i.e. y ≥ 0. So y is
dual-feasible, and cᵀx = c_BᵀB⁻¹b = yᵀb — the values agree. ∎ (The
same theorem falls out of the Farkas lemma / separating hyperplanes;
the basis proof is the one this note uses, since the implementation
recovers y from exactly that basis.)

**Optimum at a vertex (fundamental theorem).** If an LP has an
optimum, some vertex of the polytope attains it. *Sketch.* If an
optimal x is not a vertex, some nonzero direction d with Ad = 0 is
supported inside the support of x; sliding along ±d preserves
feasibility and cannot decrease the (linear) objective in one of the
two directions; slide until a new constraint tightens. Each slide
strictly shrinks the free directions, so the process ends at a vertex
with objective at least as good. ∎

**Birkhoff–von Neumann.** Every doubly stochastic matrix is a convex
combination of permutation matrices; consequently the vertices of the
assignment polytope are exactly the permutations. *Sketch.* Induction
on the number of nonzero entries. The support of a doubly stochastic
matrix contains a permutation: by Hall's theorem, since any k rows
hold total mass k inside their neighboring columns, and each column
holds total mass ≤ 1... precisely, the neighbor set N(S) of any row
set S satisfies |N(S)| ≥ |S|, so a perfect matching exists in the
support. Peel off λP for the largest λ keeping all entries
nonnegative; the remainder, rescaled, is doubly stochastic with
strictly fewer nonzeros. Induction completes the decomposition — and
a matrix that is a nontrivial convex combination is no vertex, while
each permutation plainly is one. ∎

**Checkability in polynomial time.** A certificate (x, y) has m + n
numbers. Verifying it costs O(mn) arithmetic operations: form Ax and
Aᵀy, compare, and test the two complementary-slackness families.
Short proof, cheap audit, no trusted party — the property complexity
theory calls a *good characterization*, present in LP from 1948,
decades before Khachiyan put the solving itself in polynomial time.

## Is Numina an LP?

No — and the note ends with the distinction because the distinction is
the discipline. Numina is not a linear program: its core operations
(hashing, signing, discrete acceptance verdicts, revision linkage)
are nonlinear and discrete by design. But the universal pair's
decision structures admit **exact LP models** — the assurance
allocation, the 1A/1B assignment, covering/packing, and the max–min
equalization in this note, each solved and certified — and Numina's
evidentiary standard is **duality-shaped**: claims arrive with
certificates, verification is public and cheap, and a proof of
inference is never passed off as a proof of premise. The defensible
sentence, settled 2026-10-20:

*Numina is not a linear program. Numina's acceptance economics admit
exact linear-programming models, and its standard of proof is
duality's.*

## The singularity reading

*Otters hold hands so they don't drift apart while resting: every agent stays connected without losing its independence. Singularity.*

Primal and dual are two distinct programs — two sources, in fact — that
describe **one** optimal value. They stay connected (strong duality:
z\* = w\*, always, at equilibrium) without either being absorbed into
the other; each keeps its own variables, its own meaning, its own
attribution. The constraints are the held hands: they exist so the pair
does not drift apart, and at the equilibrium point there is no slack
left to drift into.

    One object for verification. Two sources in fact. Singularity.
