# Verification receipt — Appendix I signature & pair diagnostic

Performed by Numina, 2026-10-20, from the published text of draft-kott-numina-pair-binding-02 (Appendix I, Steps 1–8; Appendix B.1; Appendix D). Independent recomputation; no trust in the draft's own claims.

## Checks

1. **Pair diagnostic — REPRODUCED.**
   SHA256(hexdecode(Source 1) || hexdecode(Source 2)) over the Appendix B.1 commitments
   (1bf43817…ec66b, 1a17f584…a46aa0a) = `c18a08a3d1e33344eed7cf921a53a1aace362a13a1fe626b699c2c5acbfc7702` — exact match.
   It does **not** equal the recorded block-zero genesis value (0xea95dac2…53e1), as the draft states.

2. **SSHSIG framed message — REPRODUCED.**
   Reconstructing `"SSHSIG" || ssh_string("numina-evidence") || ssh_string("") || ssh_string("sha512") || ssh_string(SHA512(package))`
   from the printed package SHA-512 (503b3317…445d24f0) yields bytes identical to the message printed in Step 6.

3. **Public-key fingerprint — MATCHES.**
   OpenSSH SHA-256 fingerprint of the printed raw Ed25519 key (d6f1f949…4bb3c) =
   `SHA256:EUTRdHI7yKEgsiCvob3uDx/kDFwjeiDusoEUqfCvVNc` — exact match with Step 8.

4. **Ed25519 signature — VERIFIED.**
   Pure-Python RFC 8032 verification of signature 3a638beb…d962d203 over the framed message
   against public key d6f1f949…4bb3c: **valid**. Negative control (tampered message): correctly rejected.

## What this establishes

The detached OpenSSH SSHSIG signature (namespace `numina-evidence`, SHA-512 prehash, allowed signer principal skott34@gmail.com) is mathematically valid over the exact bytes of the preserved package `Numina-Final-Genesis-Record-and-IP-Intake-v1.zip` (SHA-256 a74e4b07…a92), which contains the recorded genesis value as data.

## What it does not establish (per the draft itself)

- No executed signature exists in evidence for the `numina.pair-binding.v1` JCS companion payload: Section 4 "specifies signing; it does not report an executed signing operation" and "supplies no operational key, signature, or signed public payload."
- Appendix I: the SSHSIG signature "does not cover … an operational JCS companion" and must not be confused with the pair-binding construction.
- Signature validity does not authenticate a person or establish legal rights, discovery priority, or coauthor consent.
