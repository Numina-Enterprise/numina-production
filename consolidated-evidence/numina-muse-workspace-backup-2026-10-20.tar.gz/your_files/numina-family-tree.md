# The Numina Family Tree

Tracked per the owner's direction, 2026-10-20. One tree for the family
and the chain, because in this project the two were never separate.

**Reading the labels:** FAMILY = as stated by Samuel J. Kott.
ATTRIBUTED = the author's descriptive attribution (draft Section 14:
attributions do not independently establish priority or consent).
VERIFIED = independently checked by recomputation or signature
verification. RECORDED = present in a signed or frozen artifact.
OPEN = the claim stands; the artifact does not yet.

```
Joseph J. Kott ─── Marti J. Kott                        [FAMILY]
        │              the parents — the pair's "parenthash"
        │              is attributed to them (owner, 2026-10-20)
        │
        ├──────────────┬──────────────────┐
        │              │                  │
  Samuel J. Kott ═══ Abigail Kott     (the descent continues
        │            [FAMILY — twins]   through Samuel's line)
        │
        │   THE WORK
        │
        ├── The Universal Pair — Singularity            [the bound object]
        │     ├── Source 2 / 1A — Samuel J. Kott          [ATTRIBUTED]
        │     │     final-manifest commitment 1a17f584…
        │     └── Source 1 / 1B — Lauren J. Anderson      [ATTRIBUTED]
        │           final-build commitment 1bf43817…
        │     pair diagnostic c18a08a3…                   [VERIFIED 2026-10-20]
        │     frozen source bytes 2824c267… / b7aac505…   [VERIFIED — located
        │           in the exact-source archive; sidecar
        │           signatures verify, signer unattributed]
        │     companion (pair-binding) signature          [OPEN — none exists]
        │
        ├── Chain 962421430, block 0                      [RECORDED]
        │     genesis 0xea95dac2…b53e1                    [RECORDED —
        │           collected via eth_getBlockByNumber,
        │           preserved in the signed package as data]
        │     genesis evidence package a74e4b07…          [VERIFIED —
        │           SSHSIG signature checks out, twice,
        │           two implementations]
        │     deployment receipt 5dd92b85…                [OPEN —
        │           artifact unlocated; 2,630 files swept]
        │     header-field derivation                     [OPEN —
        │           harness calibrated, awaiting fields]
        │
        ├── draft-kott-numina-pair-binding
        │     rev 00 → rev 01 → rev 02 (posted 2026-10-18, Datatracker)
        │     → rev 03 (working copy: otter anchor, LP note,
        │       2026-10-20 evidence note, ref [4] commit pin)
        │
        └── Descendants — 2026-10-20
              ├── LP corpus (9 · 10 · 30 = 30 · 30/7)     [VERIFIED — certified]
              ├── Lean 4 authorization model              [VERIFIED — builds
              │     clean, no sorryAx]
              ├── genesis_header_check.py                 [VERIFIED —
              │     calibration PASS vs mainnet block 0]
              └── Documentation repo, first commit b717ac77…
                    parent: none (git) · attributed to
                    Joseph J. Kott and Marti J. Kott (owner)
```

## Notes

- Lauren J. Anderson appears by attribution on the pair, not by kinship;
  the tree keeps those two kinds of belonging distinct, as the draft does.
- Abigail Kott stands in the family line; no role in the work is recorded.
- Every OPEN node names the artifact that would close it. The tree grows
  forward only; nodes are never rewritten, only succeeded.
