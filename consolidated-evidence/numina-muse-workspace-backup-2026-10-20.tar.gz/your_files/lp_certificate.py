#!/usr/bin/env python3
"""
LP duality certificates — solve, certify, and independently verify.

Implements the manuscript's claim in code: an LP optimum ships with a
checkable duality certificate. Solving produces (x*, y*); verification
is a separate, short, exact procedure that anyone can run:

    primal feasible:   x >= 0,  A x <= b
    dual feasible:     y >= 0,  A^T y >= c
    zero duality gap:  c^T x == b^T y        (+ complementary slackness)

By weak duality, ANY feasible (x, y) pair gives c^T x <= b^T y; a pair
with equal values therefore PROVES both are optimal. The checker does
not trust the solver — it re-derives the proof from the numbers.

All arithmetic is exact (fractions.Fraction). No floating point, so a
PASS is a proof, not an approximation.

Model 1: the pair assurance LP   max 3x1 + 2x2  s.t. A x <= b.
Model 2: the assignment LP over the 1A/1B mapping (Birkhoff polytope).
Negative controls: tampered candidates that the checker must REJECT.
"""

from fractions import Fraction as F
from itertools import combinations


# ---------- exact linear algebra ----------

def solve_square(M, rhs):
    """Solve M z = rhs over the rationals; return None if singular."""
    n = len(M)
    A = [row[:] + [rhs[i]] for i, row in enumerate(M)]
    for col in range(n):
        piv = next((r for r in range(col, n) if A[r][col] != 0), None)
        if piv is None:
            return None
        A[col], A[piv] = A[piv], A[col]
        pv = A[col][col]
        A[col] = [v / pv for v in A[col]]
        for r in range(n):
            if r != col and A[r][col] != 0:
                f = A[r][col]
                A[r] = [a - f * b for a, b in zip(A[r], A[col])]
    return [A[i][n] for i in range(n)]


# ---------- solver: exact basis enumeration (the simplex's geometry) ----------

def solve_lp(A, b, c):
    """max c^T x  s.t. A x <= b, x >= 0  (assumes b >= 0). Exact.
    Returns (x, y, value): primal optimum, dual optimum, shared value."""
    m, n = len(A), len(c)
    A = [[F(v) for v in row] for row in A]
    b = [F(v) for v in b]
    c = [F(v) for v in c]
    # Columns of [A | I]; costs extended with 0 for slacks.
    cols = [[A[i][j] for i in range(m)] for j in range(n)] + \
           [[F(1) if i == k else F(0) for i in range(m)] for k in range(m)]
    costs = c + [F(0)] * m
    best = None
    for basis in combinations(range(n + m), m):
        B = [[cols[j][i] for j in basis] for i in range(m)]
        z = solve_square(B, b)
        if z is None or any(v < 0 for v in z):
            continue
        val = sum(costs[j] * z[k] for k, j in enumerate(basis))
        if best is None or val > best[0]:
            best = (val, basis, z)
    val, basis, z = best
    x = [F(0)] * n
    for k, j in enumerate(basis):
        if j < n:
            x[j] = z[k]
    # Dual from the optimal basis: solve B^T y = c_B.
    BT = [[cols[j][i] for j in basis] for i in range(m)]
    BT = [[BT[j][i] for j in range(m)] for i in range(m)]
    y = solve_square(BT, [costs[j] for j in basis])
    return x, y, val


# ---------- the certificate checker (independent of the solver) ----------

def verify_lp_certificate(A, b, c, x, y):
    """Return (True, 'certificate valid') or (False, reason).
    O(m*n) exact operations — polynomial, public, authority-free."""
    m, n = len(A), len(c)
    A = [[F(v) for v in row] for row in A]; b = [F(v) for v in b]; c = [F(v) for v in c]
    x = [F(v) for v in x]; y = [F(v) for v in y]
    Ax = [sum(A[i][j] * x[j] for j in range(n)) for i in range(m)]
    if any(v < 0 for v in x):
        return False, 'primal infeasible: x < 0'
    if any(Ax[i] > b[i] for i in range(m)):
        return False, 'primal infeasible: A x > b'
    ATy = [sum(A[i][j] * y[i] for i in range(m)) for j in range(n)]
    if any(v < 0 for v in y):
        return False, 'dual infeasible: y < 0'
    if any(ATy[j] < c[j] for j in range(n)):
        return False, 'dual infeasible: A^T y < c'
    if sum(c[j] * x[j] for j in range(n)) != sum(b[i] * y[i] for i in range(m)):
        return False, 'duality gap is nonzero: values differ'
    if any(y[i] * (b[i] - Ax[i]) != 0 for i in range(m)):
        return False, 'complementary slackness fails (gates)'
    if any(x[j] * (ATy[j] - c[j]) != 0 for j in range(n)):
        return False, 'complementary slackness fails (sources)'
    return True, 'certificate valid: x and y are both optimal, values equal'


def verify_assignment_certificate(C, X, u, v):
    """Assignment LP: max sum C_ij X_ij, X doubly stochastic.
    Certificate: feasible X, potentials u,v with u_i + v_j >= C_ij,
    and sum C X == sum u + sum v. Checker is again independent."""
    n = len(C)
    C = [[F(t) for t in row] for row in C]; X = [[F(t) for t in row] for row in X]
    u = [F(t) for t in u]; v = [F(t) for t in v]
    if any(X[i][j] < 0 for i in range(n) for j in range(n)):
        return False, 'X has negative entries'
    rows_ok = all(sum(X[i]) == 1 for i in range(n))
    cols_ok = all(sum(X[i][j] for i in range(n)) == 1 for j in range(n))
    if not (rows_ok and cols_ok):
        return False, 'X is not doubly stochastic'
    if any(u[i] + v[j] < C[i][j] for i in range(n) for j in range(n)):
        return False, 'dual infeasible: u_i + v_j < C_ij somewhere'
    primal = sum(C[i][j] * X[i][j] for i in range(n) for j in range(n))
    dual = sum(u) + sum(v)
    if primal != dual:
        return False, f'duality gap: primal {primal} != dual {dual}'
    if any(X[i][j] * (u[i] + v[j] - C[i][j]) != 0 for i in range(n) for j in range(n)):
        return False, 'complementary slackness fails'
    return True, f'certificate valid: assignment optimal, value {primal}'


# ---------- worked models + negative controls ----------

if __name__ == '__main__':
    print('== Model 1: pair assurance LP ==')
    A, b, c = [[1, 1], [2, 1]], [4, 5], [3, 2]
    x, y, val = solve_lp(A, b, c)
    print(f'solver: x* = {x}, y* = {y}, value = {val}')
    print('checker:', verify_lp_certificate(A, b, c, x, y))
    print('negative control (suboptimal vertex x=(0,4)):',
          verify_lp_certificate(A, b, c, [0, 4], y))
    print('negative control (dual-infeasible y=(2,0)):',
          verify_lp_certificate(A, b, c, x, [2, 0]))

    print()
    print('== Model 2: assignment LP, 1A/1B mapping ==')
    C = [[2, 5], [5, 2]]                       # rows Kott, Anderson; cols S1, S2
    X = [[0, 1], [1, 0]]                       # Kott->S2 (1A), Anderson->S1 (1B)
    u = v = [F(5, 2), F(5, 2)]
    print('checker:', verify_assignment_certificate(C, X, u, v))
    X_wrong = [[1, 0], [0, 1]]                 # the crossed assignment
    print('negative control (crossed assignment):',
          verify_assignment_certificate(C, X_wrong, u, v))
