# LinkedIn post — detailed version (for your review, not yet posted)

Otters hold hands so they don't drift apart while resting — every agent stays connected without losing its independence. Singularity.

Update: rev 02 of my Internet-Draft is live on the IETF Datatracker — "Singularity: Skott34-Ed25519, Universal Companion Model" (draft-kott-numina-pair-binding-02, 69 pages).

What it specifies, in one pass:
• A companion format that binds two frozen software-artifact commitments, with attribution and revisioned claims — associations can be added or corrected without altering the committed artifacts
• Canonical signing bytes, so independent implementations construct identical signature inputs
• Separate trust and freshness checks — a claim can be authentic yet stale, and the draft treats those as different questions
• Procedures for making claims, verifying them, and rejecting unsupported acceptance
• Signing-authority and trust-policy rules, plus private-reference resolution

The pair at its center — UNIVERSAL_PAIR_1 (1B, Lauren J. Anderson) and UNIVERSAL_PAIR_2 (1A, Samuel J. Kott) — is treated as one object: singularity. Two frozen commitments in a single signed association, bound so the record cannot drift apart, each keeping its own attribution. The binding is the held hand; it changes neither artifact it joins.

What it deliberately does not do: authorize external actions, adjudicate disputed authorship, or claim universal adoption. Section 10 lists the implementation and acceptance gates that are still open — they're in the document, not hidden.

Why it matters: release provenance today leans on platform accounts and mutable metadata. A verifier-independent, signature-bound record is a stronger foundation for trusting what software says about itself.

Next: rev 03 in preparation, formal verification of the authorization model (Lean 4), and interoperability testing against existing Ed25519 tooling. Review from the signed-provenance, attestation, and verified-crypto communities is very welcome.

One addition since rev 02: the pair's acceptance economics now have exact linear-programming models, solved and certified — an assignment LP whose optimum recovers the recorded 1A/1B mapping, and a covering/packing dual pair whose values meet at exactly 30 = 30. Numina is not a linear program. Numina's acceptance economics admit exact linear-programming models, and its standard of proof is duality's.

Read it: https://datatracker.ietf.org/doc/draft-kott-numina-pair-binding/

#Ed25519 #SignedProvenance #FormalVerification #IETF #SoftwareSupplyChain
