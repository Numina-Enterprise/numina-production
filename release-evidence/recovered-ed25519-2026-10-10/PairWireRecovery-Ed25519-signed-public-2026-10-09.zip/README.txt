PairWireRecovery.lean — separate operational Ed25519 signing receipt

Status: exact source signed; consult independent-source-verification.json for the
independent public verification and disposable tamper-negative check.

PairWireRecovery.lean is the exact public source relayed as Base64 from the
independent reviewer's verified ZIP member. Strict decoding preserved all bytes,
including the final newline. No rendered Library text was reconstructed.
Byte count: 5,568
SHA-256: 51ea8ef76197ba53ca5a9e3bd1de6f82fff8ff52ad37238c9933e29f2ac39eae
Original Library source: libfile_4ec5c077c65481919d3c973ff122aa0d
Reviewer ZIP: libfile_c2887d73285c819197c5674bc2004de3
Expected ZIP SHA-256 supplied by parent:
08a2b5c40fed00559332ed9da81a6006b0725c44769b1162d4b38ca11a2a4d80
This Mac verified the relayed source hash; it did not download/recheck ZIP bytes.

PairWireRecovery.lean.sig contains the 64 raw bytes of its pure Ed25519 detached
signature over the exact source bytes. There is no SSHSIG framing and no
application prehash. operational_ed25519_public.raw contains 32 raw public-key
bytes. public-key.json labels the SHA-256 fingerprint over those raw 32 bytes;
this is not an OpenSSH fingerprint or a signer registration.

Hello_Ed25519.test.sig is the previously issued exact UTF-8 Hello Ed25519 test
signature, 13 message bytes with no newline. It is separately labeled as a
test receipt. It uses the same retained operational key as the source signature.
The earlier test package remains preserved in Library:
libfile_3553695b483c8191bbe0bff3cd39e0d7
Its historical source-retrieval blocker is closed for this source-signing task
by the matching binary relay recorded in source-byte-verification.json.
No additional challenge or test signatures were created after that relay.

Private custody: encrypted local login Keychain under Sam's control, a distinct
operational item. The new item's ACL trusts the creating Python executable
without an OS prompt; it is not limited to one Python script. The owner Library
directory is mode 0700. The durable nonsecret custody reference and signer
utility are in ~/Library/Application Support/PairWireSigning/, directory 0700
and files 0600. Recovery depends on the retained local Keychain and its owner
credentials. No separate private-key backup was created.

Existing keys, signer registrations and historical signatures remain unchanged.
No SSH authorized_keys, external services or trust registries were modified.
All package contents are public source or public verification material. No
private key bytes, seed, password or token is included.

Reproduce the public verification with an installed Python cryptography package:
python3 verify_public.py --directory . --expected-public-key-sha256 b217cc5bae08acbfdb9f8cd20f420f0bee2ae39fb6f0b178ce060284c76f8e9f

This signature establishes byte integrity and key correspondence. It does not
establish completion of the whole NCPS protocol, model-generation provenance,
identity ownership, deployment approval or financial authority. This signing
operation did not recompile Lean or verify its imported dependency bundle.
