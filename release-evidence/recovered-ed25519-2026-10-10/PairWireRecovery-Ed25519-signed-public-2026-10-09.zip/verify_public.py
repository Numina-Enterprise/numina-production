#!/usr/bin/env python3
"""Verify the public-only PairWireRecovery pure Ed25519 signature package.

Requires Python cryptography. The signature inputs are exact file/message bytes;
SHA-256 is used only for artifact identity and the labeled public fingerprint.
No signing or private-key operation is performed by this script.
"""

import argparse
import base64
import hashlib
import json
import platform
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import cryptography
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


EXPECTED_SOURCE_BYTES = 5568
EXPECTED_SOURCE_SHA256 = (
    "51ea8ef76197ba53ca5a9e3bd1de6f82fff8ff52ad37238c9933e29f2ac39eae"
)
TEST_MESSAGE = b"Hello Ed25519"


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


def read_exact_size(path, size, label):
    data = path.read_bytes()
    if len(data) != size:
        raise ValueError(f"{label}: expected {size} bytes, got {len(data)}")
    return data


def resolve_file(directory, name):
    path = Path(name)
    return path if path.is_absolute() else directory / path


def verify_package(args):
    directory = Path(args.directory).resolve()
    source_path = resolve_file(directory, args.source)
    public_path = resolve_file(directory, args.public_key)
    source_sig_path = resolve_file(directory, args.source_signature)
    test_sig_path = resolve_file(directory, args.test_signature)

    source = read_exact_size(source_path, EXPECTED_SOURCE_BYTES, "Lean source")
    source_digest = sha256_hex(source)
    if source_digest != EXPECTED_SOURCE_SHA256:
        raise ValueError(
            "Lean source SHA-256 differs from the approved exact source: "
            f"{source_digest}"
        )

    public_bytes = read_exact_size(public_path, 32, "raw Ed25519 public key")
    public_digest = sha256_hex(public_bytes)
    if args.expected_public_key_sha256 is not None:
        expected = args.expected_public_key_sha256.lower()
        if len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
            raise ValueError("Expected public-key SHA-256 must be 64 hexadecimal digits")
        if public_digest != expected:
            raise ValueError("Raw public-key SHA-256 differs from the supplied expectation")

    source_signature = read_exact_size(source_sig_path, 64, "Lean detached signature")
    test_signature = read_exact_size(test_sig_path, 64, "test detached signature")
    public_key = Ed25519PublicKey.from_public_bytes(public_bytes)

    # Pure Ed25519 over the exact bytes: no SSHSIG framing or application prehash.
    public_key.verify(source_signature, source)
    public_key.verify(test_signature, TEST_MESSAGE)

    modified = bytearray(source)
    modified[0] ^= 1
    modified = bytes(modified)
    with tempfile.TemporaryDirectory(prefix="pairwire-public-tamper-check-") as tmp:
        modified_path = Path(tmp) / "PairWireRecovery.modified.lean"
        modified_path.write_bytes(modified)
        disposable_copy = modified_path.read_bytes()
        differences = sum(a != b for a, b in zip(source, disposable_copy))
        if len(disposable_copy) != len(source) or differences != 1:
            raise ValueError("Tamper check did not produce exactly one changed byte")
        try:
            public_key.verify(source_signature, disposable_copy)
        except InvalidSignature:
            tamper_rejected = True
        else:
            raise ValueError("Tamper check failed: modified source was accepted")

    source_after = source_path.read_bytes()
    if source_after != source:
        raise ValueError("Original Lean source changed during public verification")

    return {
        "schema": "pairwire-public-ed25519-verification-v1",
        "status": "passed",
        "verification_utc": datetime.now(timezone.utc).isoformat(),
        "algorithm": "Ed25519 (pure), detached 64-byte raw signatures",
        "signing_input": "exact bytes; no SSHSIG framing; no application prehash",
        "public_key": {
            "encoding": "raw 32-byte Ed25519 public key",
            "hex": public_bytes.hex(),
            "base64": base64.b64encode(public_bytes).decode("ascii"),
            "fingerprint_algorithm": "SHA-256 of the raw 32-byte public key",
            "fingerprint_hex": public_digest,
            "expected_fingerprint_checked": args.expected_public_key_sha256 is not None,
        },
        "source": {
            "filename": source_path.name,
            "bytes": len(source),
            "sha256": source_digest,
            "approved_size_and_sha256_match": True,
            "signature_hex": source_signature.hex(),
            "signature_base64": base64.b64encode(source_signature).decode("ascii"),
            "signature_verified": True,
            "original_unchanged": True,
        },
        "test_receipt": {
            "label": "Hello Ed25519 test receipt (separate from Lean source signature)",
            "message_encoding": "UTF-8, no newline",
            "message": TEST_MESSAGE.decode("utf-8"),
            "message_hex": TEST_MESSAGE.hex(),
            "message_bytes": len(TEST_MESSAGE),
            "signature_hex": test_signature.hex(),
            "signature_base64": base64.b64encode(test_signature).decode("ascii"),
            "signature_verified": True,
        },
        "tamper_negative_check": {
            "disposable_copy": True,
            "changed_byte_count": differences,
            "changed_byte_offset": 0,
            "change": "XOR the first byte with 0x01",
            "bytes": len(modified),
            "sha256": sha256_hex(modified),
            "original_signature_rejected": tamper_rejected,
        },
        "versions": {
            "python": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "cryptography": cryptography.__version__,
        },
        "scope": (
            "Verifies byte integrity and correspondence to the supplied public key. "
            "Does not establish identity ownership, durable private-key custody, "
            "Lean compilation, or completion of the whole NCPS protocol."
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", default=str(Path(__file__).resolve().parent))
    parser.add_argument("--source", default="PairWireRecovery.lean")
    parser.add_argument("--public-key", default="operational_ed25519_public.raw")
    parser.add_argument("--source-signature", default="PairWireRecovery.lean.sig")
    parser.add_argument("--test-signature", default="Hello_Ed25519.test.sig")
    parser.add_argument(
        "--expected-public-key-sha256",
        help="Optional SHA-256 hexadecimal digest of the raw 32-byte public key",
    )
    args = parser.parse_args()
    try:
        receipt = verify_package(args)
    except (OSError, ValueError, InvalidSignature) as error:
        print(json.dumps({"status": "failed", "error": str(error) or type(error).__name__}))
        return 1
    print(json.dumps(receipt, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
