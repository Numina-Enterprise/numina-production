import ParserRefinement
import PairExtraction

/-! Recovery from the actual ordered pair extraction adapter, composed with the
proved accepted-wire converse of the actual unchanged pair codec. This candidate
byte format is not adopted NCPS JSON/schema policy or a cryptographic theorem.
-/
namespace NCPSPairWireRecovery
open NCPSByteFraming NCPSPairExtraction

def recoverWire (values : List CoreBytes) : Option Bytes :=
  (recoverOccurrences values).map encodePair

def recoveredWire (wire : Bytes) : Option Bytes :=
  (occurrences wire).bind recoverWire

theorem recovery_pipeline_eq_parser (wire : Bytes) :
    recoveredWire wire = (decodePair wire).map encodePair := by
  cases parsed : decodePair wire with
  | none => simp [recoveredWire, occurrences, parsed]
  | some pair =>
      rcases pair with ⟨left,right⟩
      simp [recoveredWire, occurrences, parsed, recoverWire, recoverOccurrences,
        NCPSByteRepresentationBridge.toList_encode]

theorem recovery_exact_wire (wire : Bytes) :
    recoveredWire wire = (decodePair wire).map (fun _ => wire) := by
  rw [recovery_pipeline_eq_parser]
  cases parsed : decodePair wire with
  | none => rfl
  | some pair =>
      simpa using congrArg some
        (NCPSByteFraming.Canonicality.pair_canonicality wire pair parsed)

theorem accepted_occurrences_recover_wire (wire : Bytes) (values : List CoreBytes)
    (accepted : occurrences wire = some values) : recoverWire values = some wire := by
  have recovered : recoveredWire wire = some wire := by
    rw [recovery_exact_wire]
    cases parsed : decodePair wire with
    | none =>
        have failed := (occurrences_failure_iff wire).mpr parsed
        rw [failed] at accepted
        cases accepted
    | some pair => rfl
  simpa only [recoveredWire, accepted, Option.bind_some] using recovered

theorem recovery_success_iff (wire : Bytes) :
    recoveredWire wire = some wire ↔ ∃ pair, decodePair wire = some pair := by
  rw [recovery_exact_wire]
  cases parsed : decodePair wire <;> simp

theorem recovery_failure_iff (wire : Bytes) :
    recoveredWire wire = none ↔ decodePair wire = none := by
  rw [recovery_exact_wire]
  cases parsed : decodePair wire <;> simp

theorem ordered_occurrences_unique_wire (left right : Bytes) (values : List CoreBytes)
    (leftAccepted : occurrences left = some values)
    (rightAccepted : occurrences right = some values) : left = right := by
  exact Option.some.inj
    ((accepted_occurrences_recover_wire left values leftAccepted).symm.trans
      (accepted_occurrences_recover_wire right values rightAccepted))

theorem encoded_pair_recovery (pair : Bytes × Bytes) :
    recoveredWire (encodePair pair) = some (encodePair pair) := by
  rw [recovery_pipeline_eq_parser, pair_roundtrip]
  rfl

theorem duplicate_occurrences_recover_wire (payload : Bytes) :
    recoverWire [NCPSByteRepresentationBridge.encode payload,
      NCPSByteRepresentationBridge.encode payload] = some (encodePair (payload,payload)) :=
  accepted_occurrences_recover_wire _ _ (duplicate_occurrences_retained payload)

theorem empty_pair_recovery :
    recoverWire [NCPSCore.empty,NCPSCore.empty] = some (encodePair ([],[])) :=
  accepted_occurrences_recover_wire _ _ empty_pair_occurrences

-- The ordered list has a recovery law; the extensional set intentionally does
-- not preserve order. These exact accepted wires give an executable collision.
theorem occurrence_set_swap (left right : CoreBytes) :
    occurrenceSet [left,right] = occurrenceSet [right,left] := by
  apply NCPSCore.finiteSet_ext
  intro value
  simp [NCPSCore.member, occurrenceSet, or_comm]

theorem extraction_swap (left right : Bytes) :
    extract (encodePair (left,right)) = extract (encodePair (right,left)) := by
  rw [extract_on_encoded_pair, extract_on_encoded_pair]
  exact congrArg NCPSCore.success (occurrence_set_swap _ _)

theorem swapped_wires_distinct :
    encodePair ([],[zero]) ≠ encodePair ([zero],[]) := by decide +kernel

theorem set_extraction_not_injective : ¬ Function.Injective extract := by
  intro injective
  exact swapped_wires_distinct (injective (extraction_swap [] [zero]))

-- Success(empty set) is outside this adapter's range. This explains its special
-- empty-erasure/failure equivalence without changing generic Core.erase.
theorem extractor_excludes_success_empty_set (wire : Bytes) :
    extract wire ≠ NCPSCore.success NCPSCore.setEmpty := by
  intro emptySuccess
  have erased : NCPSCore.erase (extract wire) = NCPSCore.setEmpty := by
    rw [emptySuccess]
    rfl
  have failed := (erasure_empty_iff_failure wire).mp erased
  have rejected := (extract_failure_iff wire).mpr failed
  exact NCPSCore.reject_ne_success _ (rejected.symm.trans emptySuccess)

theorem generic_erasure_collision :
    NCPSCore.erase NCPSCore.reject =
      NCPSCore.erase (NCPSCore.success NCPSCore.setEmpty) :=
  NCPSCore.erase_reject_eq_erase_success_empty

#print axioms recoverWire
#print axioms recoveredWire
#print axioms recovery_pipeline_eq_parser
#print axioms recovery_exact_wire
#print axioms accepted_occurrences_recover_wire
#print axioms recovery_success_iff
#print axioms recovery_failure_iff
#print axioms ordered_occurrences_unique_wire
#print axioms encoded_pair_recovery
#print axioms duplicate_occurrences_recover_wire
#print axioms empty_pair_recovery
#print axioms occurrence_set_swap
#print axioms extraction_swap
#print axioms swapped_wires_distinct
#print axioms set_extraction_not_injective
#print axioms extractor_excludes_success_empty_set
#print axioms generic_erasure_collision
end NCPSPairWireRecovery
