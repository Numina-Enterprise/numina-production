Numina v161 owner-requested operational observation binding

Attribution: S. J. Kott <skott34@gmail.com>, as supplied for this signing.
Actual signing: 2026-10-09 22:46:16 UTC on Sam's Mac.

publication-observation.json is the unchanged 6,763-byte GitHub observation.
SHA-256: 949cbb6d637fde547a95b40d6fa8c54b5af510effed38c74f1c9f25c37131733
The original's unsigned classifications and false flags remain historical facts.

v161-observation-binding-manifest.json adds an owner-requested binding of the
complete recorded evidence, identities, provenance, and limitations for v161.
It binds the exact original observation and its new detached signature.
Both payloads have pure Ed25519 signatures over their exact file bytes;
no application prehash and no SSHSIG. Raw signature files contain 64 bytes.

operational-ed25519-public.raw contains the approved 32-byte public key:
f29ec679836c6889ef87d41b842bfd2236004c1a6d84d4bac0814cae45a90c28
Fingerprint algorithm: SHA-256 over that raw 32-byte key.
Fingerprint: b217cc5bae08acbfdb9f8cd20f420f0bee2ae39fb6f0b178ce060284c76f8e9f
This operational key is separate from the preserved historical repository key
ID 3a2fe594a7e10458ae89683f. No signer/pin/registry was replaced.

Verification (Python 3.9+ and cryptography):
    python verify_public.py .
The verifier uses only public material and checks both signatures, altered
payload and signature rejection, and preservation of original record values.
The signing receipt records exact signature hex/base64, file hashes, time
bounds, tool versions, and evidence limits. Independent verification is also
included. SHA256SUMS.txt inventories every included file except itself.

The signatures establish byte integrity and key correspondence. The name/email
are attribution from the authorized request, not legal identity established by
signature verification. This is not a provider-issued attestation, fresh build,
new deployment, or backdated signature. No source/artifact rebuild or inventory
verification was rerun. Provider tar bytes were not independently hashed and
runtime health was not checked. Local gzip-tar and provider tar digests remain
distinct. The retrieval commit is not either recorded build-source commit.

Only public material is included; the ZIP is stored privately for Sam. No
private key, seed, password, token, or credential is included. The existing
operational key stayed in encrypted local Keychain custody. No repository
edit, push, deployment, external publication, financial action, or NCPS
collection signing occurred.
