"""Verify the public v161 bundle without Keychain or private-key access.

Requires Python 3.9+ and cryptography. Run: python verify_public.py [directory]
"""
import base64
import hashlib
import json
from pathlib import Path
import sys
from datetime import datetime, timezone

import cryptography
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

EXPECTED_PUBLIC = 'f29ec679836c6889ef87d41b842bfd2236004c1a6d84d4bac0814cae45a90c28'
EXPECTED_OBSERVATION_HASH = '949cbb6d637fde547a95b40d6fa8c54b5af510effed38c74f1c9f25c37131733'
EXPECTED_OBSERVATION_SIZE = 6763


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def pointer_value(record, pointer):
    value = record
    for part in pointer.strip('/').split('/'):
        part = part.replace('~1', '/').replace('~0', '~')
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value


def main():
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
    raw = (root / 'operational-ed25519-public.raw').read_bytes()
    require(len(raw) == 32 and raw.hex() == EXPECTED_PUBLIC, 'Approved public-key mismatch')
    public = Ed25519PublicKey.from_public_bytes(raw)
    key_info = json.loads((root / 'public-key.json').read_bytes())
    require(key_info['raw_public_key_hex'] == raw.hex(), 'Public-key metadata mismatch')
    require(key_info['fingerprint_hex'] == sha(raw), 'Raw-public-key SHA-256 fingerprint mismatch')
    original = (root / 'publication-observation.json').read_bytes()
    require(len(original) == EXPECTED_OBSERVATION_SIZE and sha(original) == EXPECTED_OBSERVATION_HASH,
            'Exact approved observation mismatch')
    original_record = json.loads(original)
    manifest_bytes = (root / 'v161-observation-binding-manifest.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    receipt = json.loads((root / 'signing-verification-receipt.json').read_bytes())
    require(manifest['target_saved_version_number'] == 161, 'Manifest target mismatch')
    require(manifest['attribution']['name'] == 'S. J. Kott' and manifest['attribution']['email'] == 'skott34@gmail.com',
            'Requested attribution mismatch')
    require(manifest['preserved_recorded_evidence'] == original_record, 'Original recorded values were changed')
    require(manifest['signer'] == key_info == receipt['public_key'], 'Signer metadata mismatch')
    require(manifest['signer']['historical_repository_key_id_preserved'] == original_record['ed25519_key_id'],
            'Historical repository signer identity mismatch')
    require(manifest['signer']['historical_repository_signer_replaced'] is False, 'Unexpected signer replacement claim')
    for entry in manifest['provenance_bindings']:
        require(entry['value'] == pointer_value(original_record, entry['original_record_json_pointer']),
                'Provenance value mismatch: ' + entry['original_record_json_pointer'])
    require(manifest['observation_artifact']['sha256'] == sha(original), 'Observation binding hash mismatch')
    require(manifest['observation_artifact']['bytes'] == len(original), 'Observation binding size mismatch')
    require(original_record['saved_version']['version_number'] == 161 and
            original_record['final_publication_observation']['version']['version_number'] == 161,
            'Original record does not bind v161')
    require(original_record['saved_version']['provider_archive_bytes_independently_hashed'] is False,
            'Expected provider archive evidence limit changed')
    require(original_record['final_publication_observation']['http_runtime_health_checked'] is False,
            'Expected runtime-health evidence limit changed')
    results = []
    expected_files = ['publication-observation.json', 'v161-observation-binding-manifest.json']
    require([p['file'] for p in receipt['payloads']] == expected_files, 'Unexpected signing scope')
    for payload in receipt['payloads']:
        data = (root / payload['file']).read_bytes()
        sig = (root / payload['signature_file']).read_bytes()
        require(len(sig) == 64 and len(data) == payload['bytes'] and sha(data) == payload['sha256'],
                'Payload metadata mismatch')
        require(sig.hex() == payload['signature_hex'] and base64.b64encode(sig).decode() == payload['signature_base64']
                and sha(sig) == payload['signature_sha256'], 'Signature metadata mismatch')
        public.verify(sig, data)
        altered = bytearray(data)
        altered[len(altered) // 2] ^= 1
        try:
            public.verify(sig, bytes(altered))
        except InvalidSignature:
            pass
        else:
            raise ValueError('Altered payload unexpectedly accepted')
        altered_sig = bytearray(sig)
        altered_sig[0] ^= 1
        try:
            public.verify(bytes(altered_sig), data)
        except InvalidSignature:
            pass
        else:
            raise ValueError('Altered signature unexpectedly accepted')
        results.append({'file': payload['file'], 'bytes': len(data), 'sha256': sha(data),
                        'signature_verification': 'passed', 'one_byte_modified_payload': 'rejected',
                        'one_byte_modified_signature': 'rejected'})
    obs_sig = (root / 'publication-observation.json.ed25519.sig').read_bytes()
    require(manifest['observation_artifact']['signature_hex'] == obs_sig.hex() and
            manifest['observation_artifact']['signature_sha256'] == sha(obs_sig), 'Original signature binding mismatch')
    print(json.dumps({'verification': 'passed', 'verified_at_utc': datetime.now(timezone.utc).isoformat(),
        'target_saved_version_number': 161, 'original_record_preserved': True,
        'attribution_preserved': True, 'all_provenance_binding_values_match_original': True,
        'public_key_hex': raw.hex(), 'fingerprint_algorithm': 'SHA-256 over raw 32-byte public key',
        'fingerprint_hex': sha(raw), 'payloads': results, 'python_version': sys.version,
        'cryptography_version': cryptography.__version__, 'private_key_access': False}, indent=2))


if __name__ == '__main__':
    main()
