import NCPSClosure
set_option autoImplicit false

/-!
An NCPS verifier returns independent evidence findings.
Cryptographic validity, trusted authority, correct source hashes,
revision freshness, and private-linkage are not interchangeable.
-/

namespace NCPS.Advanced

inductive Finding where
  | pass | mismatch | unavailable | notApplicable
  deriving DecidableEq, Repr

structure VerificationPolicy where
  requireCurrentSource : Bool
  requirePrivateResolution : Bool

structure VerificationReport where
  schema : Finding
  signature : Finding
  authority : Finding
  sourceCommitments : Finding
  currentSource : Finding
  freshness : Finding
  privateResolution : Finding
  deriving DecidableEq, Repr

def Accepts (policy : VerificationPolicy)
    (r : VerificationReport) : Prop :=
  r.schema = .pass ∧
  r.signature = .pass ∧
  r.authority = .pass ∧
  r.sourceCommitments = .pass ∧
  (policy.requireCurrentSource = true → r.currentSource = .pass) ∧
  r.freshness = .pass ∧
  (policy.requirePrivateResolution = true → r.privateResolution = .pass)

theorem accepted_signature_valid
    (p : VerificationPolicy) (r : VerificationReport)
    (h : Accepts p r) : r.signature = .pass :=
  h.2.1

theorem accepted_authority_valid
    (p : VerificationPolicy) (r : VerificationReport)
    (h : Accepts p r) : r.authority = .pass :=
  h.2.2.1

theorem accepted_sources_valid
    (p : VerificationPolicy) (r : VerificationReport)
    (h : Accepts p r) : r.sourceCommitments = .pass :=
  h.2.2.2.1

theorem accepted_freshness
    (p : VerificationPolicy) (r : VerificationReport)
    (h : Accepts p r) : r.freshness = .pass :=
  h.2.2.2.2.2.1

theorem accepted_private_when_required
    (p : VerificationPolicy) (r : VerificationReport)
    (h : Accepts p r) (hp : p.requirePrivateResolution = true) :
    r.privateResolution = .pass :=
  h.2.2.2.2.2.2 hp

theorem accepted_current_source_when_required
    (p : VerificationPolicy) (r : VerificationReport)
    (h : Accepts p r) (hp : p.requireCurrentSource = true) :
    r.currentSource = .pass :=
  h.2.2.2.2.1 hp

def signatureValidUntrusted : VerificationReport where
  schema := .pass
  signature := .pass
  authority := .unavailable
  sourceCommitments := .pass
  currentSource := .pass
  freshness := .pass
  privateResolution := .pass

theorem signature_alone_not_acceptance
    (p : VerificationPolicy) :
    ¬ Accepts p signatureValidUntrusted := by
  intro h
  have ha := accepted_authority_valid p signatureValidUntrusted h
  cases ha

theorem unavailable_authority_ne_passed :
    Finding.unavailable ≠ .pass := by decide

theorem unverified_private_not_acceptance_when_required
    (p : VerificationPolicy) (r : VerificationReport)
    (hp : p.requirePrivateResolution = true)
    (hu : r.privateResolution = .unavailable) :
    ¬ Accepts p r := by
  intro h
  have hv := accepted_private_when_required p r h hp
  rw [hu] at hv
  cases hv

/-- Executable gate: checking every required finding exactly. -/
def evaluate (policy : VerificationPolicy)
    (r : VerificationReport) : Bool :=
  (r.schema == .pass) &&
  (r.signature == .pass) &&
  (r.authority == .pass) &&
  (r.sourceCommitments == .pass) &&
  ((!policy.requireCurrentSource) || (r.currentSource == .pass)) &&
  (r.freshness == .pass) &&
  ((!policy.requirePrivateResolution) || (r.privateResolution == .pass))

theorem untrusted_signature_rejected (p : VerificationPolicy) :
    evaluate p signatureValidUntrusted = false := by
  simp [evaluate, signatureValidUntrusted]

end NCPS.Advanced
