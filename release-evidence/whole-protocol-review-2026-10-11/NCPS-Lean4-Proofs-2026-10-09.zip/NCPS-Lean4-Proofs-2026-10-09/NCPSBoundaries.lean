import NCPSCore
set_option autoImplicit false

/-!
Zero-based sequence boundary predicates use ordered concatenation.
The empty byte sequence is included in every quantified theorem.
-/

namespace NCPS.Advanced

def IsPrefix (small whole : Bytes) : Prop :=
  ∃ tail, whole = small ++ tail

def IsSuffix (small whole : Bytes) : Prop :=
  ∃ lead, whole = lead ++ small

def IsInfix (small whole : Bytes) : Prop :=
  ∃ lead tail, whole = lead ++ small ++ tail

theorem empty_is_prefix (b : Bytes) :
    IsPrefix emptyBytes b := by
  refine ⟨b, ?_⟩
  simp [emptyBytes]

theorem empty_is_suffix (b : Bytes) :
    IsSuffix emptyBytes b := by
  refine ⟨b, ?_⟩
  simp [emptyBytes]

theorem empty_is_infix (b : Bytes) :
    IsInfix emptyBytes b := by
  refine ⟨[], b, ?_⟩
  simp [emptyBytes]

theorem prefix_reflexive (b : Bytes) :
    IsPrefix b b := by
  refine ⟨[], ?_⟩
  simp

theorem suffix_reflexive (b : Bytes) :
    IsSuffix b b := by
  refine ⟨[], ?_⟩
  simp

theorem infix_reflexive (b : Bytes) :
    IsInfix b b := by
  refine ⟨[], [], ?_⟩
  simp

theorem prefix_transitive (a b c : Bytes)
    (hab : IsPrefix a b) (hbc : IsPrefix b c) :
    IsPrefix a c := by
  rcases hab with ⟨x, hb⟩
  rcases hbc with ⟨y, hc⟩
  refine ⟨x ++ y, ?_⟩
  simp [hc, hb, List.append_assoc]

theorem suffix_transitive (a b c : Bytes)
    (hab : IsSuffix a b) (hbc : IsSuffix b c) :
    IsSuffix a c := by
  rcases hab with ⟨x, hb⟩
  rcases hbc with ⟨y, hc⟩
  refine ⟨y ++ x, ?_⟩
  simp [hc, hb, List.append_assoc]

theorem prefix_length_bound (a b : Bytes)
    (h : IsPrefix a b) : a.length ≤ b.length := by
  rcases h with ⟨tail, hb⟩
  simp [hb]

theorem suffix_length_bound (a b : Bytes)
    (h : IsSuffix a b) : a.length ≤ b.length := by
  rcases h with ⟨lead, hb⟩
  simp [hb]

end NCPS.Advanced
