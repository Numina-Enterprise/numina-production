import NCPSCore
set_option autoImplicit false

/-!
NCPS executable theorem suite. These are proofs about the precisely
specified models below, not a claim of external JCS, UTF-8, Ed25519,
key-custody, or production-system conformance.
-/

namespace NCPS

/-- A record codec carries executable encoder/decoder functions. -/
def InjectiveFn {α β : Type} (f : α → β) : Prop :=
  ∀ a b, f a = f b → a = b

structure Codec (R : Type) where
  encode : R → Bytes
  decode : Bytes → Option R

/-- No round trip is assumed without a proof supplied at the call site. -/
def RoundTrip {R : Type} (c : Codec R) : Prop :=
  ∀ r, c.decode (c.encode r) = some r

theorem codec_injective_of_roundtrip {R : Type}
    (c : Codec R) (h : RoundTrip c) :
    InjectiveFn c.encode := by
  intro a b eq
  have hsome : some a = some b := by
    calc
      some a = c.decode (c.encode a) := (h a).symm
      _ = c.decode (c.encode b) := congrArg c.decode eq
      _ = some b := h b
  exact Option.some.inj hsome

/-- Canonical-by-construction byte values for a supplied record codec. -/
def CanonicalBytes {R : Type} (c : Codec R) :=
  {b : Bytes // ∃ r, c.encode r = b}

def serialize {R : Type} (c : Codec R) (r : R) : CanonicalBytes c :=
  ⟨c.encode r, ⟨r, rfl⟩⟩

def parseCanonical {R : Type} (c : Codec R)
    (b : CanonicalBytes c) : Option R :=
  c.decode b.1

theorem canonical_roundtrip {R : Type}
    (c : Codec R) (h : RoundTrip c) (r : R) :
    parseCanonical c (serialize c r) = some r := h r

theorem canonical_serialization_injective {R : Type}
    (c : Codec R) (h : RoundTrip c) :
    InjectiveFn (serialize c) := by
  intro r s eq
  apply codec_injective_of_roundtrip c h
  exact congrArg Subtype.val eq

/-- Distinct leading tags give a complete, total simple binary codec.
    This sample is deliberately NOT the JSON/JCS codec. -/
def zeroByte : Byte := ⟨0, by decide⟩
def oneByte : Byte := ⟨1, by decide⟩

structure SampleRecord where
  flag : Bool
  payload : Bytes
  deriving DecidableEq, Repr

def sampleEncode (r : SampleRecord) : Bytes :=
  (if r.flag then oneByte else zeroByte) :: r.payload

def sampleDecode : Bytes → Option SampleRecord
  | [] => none
  | b :: rest =>
      if b = zeroByte then some ⟨false, rest⟩
      else if b = oneByte then some ⟨true, rest⟩
      else none

def sampleCodec : Codec SampleRecord :=
  ⟨sampleEncode, sampleDecode⟩

theorem sample_roundtrip (r : SampleRecord) :
    sampleDecode (sampleEncode r) = some r := by
  cases r with
  | mk flag payload =>
      cases flag <;> simp [sampleDecode, sampleEncode,
        zeroByte, oneByte]

theorem sample_codec_roundtrip : RoundTrip sampleCodec :=
  sample_roundtrip

theorem sample_encode_injective :
    InjectiveFn sampleEncode :=
  codec_injective_of_roundtrip sampleCodec sample_codec_roundtrip

theorem sample_rejects_empty :
    sampleDecode [] = none := rfl

/-- Domain-separated message construction for a supplied domainTag.
    This theorem does NOT claim any signature algorithm properties. -/
def frame (domainTag payload : Bytes) : Bytes :=
  domainTag ++ [zeroByte] ++ payload

theorem frame_length (domainTag payload : Bytes) :
    (frame domainTag payload).length = domainTag.length + 1 + payload.length := by
  simp [frame, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]

theorem frame_injective (domainTag : Bytes) :
    InjectiveFn (frame domainTag) := by
  intro a b h
  unfold frame at h
  exact List.append_cancel_left h

/-- Version-indexed relation instances are dependent types, not global casts. -/
structure RelationFamily where
  RelId : Type
  Inst : RelId → Type

def Semantics (F : RelationFamily) :=
  (r : F.RelId) → F.Inst r → Bool

structure Implementation (F : RelationFamily) where
  eval : Semantics F

def Conforms (F : RelationFamily) (spec : Semantics F)
    (k : Implementation F) : Prop :=
  ∀ (r : F.RelId) (q : F.Inst r), k.eval r q = spec r q

theorem conforming_implementations_agree
    (F : RelationFamily) (spec : Semantics F)
    (k₁ k₂ : Implementation F)
    (h₁ : Conforms F spec k₁) (h₂ : Conforms F spec k₂)
    (r : F.RelId) (q : F.Inst r) :
    k₁.eval r q = k₂.eval r q := by
  calc
    k₁.eval r q = spec r q := h₁ r q
    _ = k₂.eval r q := (h₂ r q).symm

/-- Explicit ternary assessment distinguishes unknown from falsified. -/
inductive Assessment where
  | unverified
  | failed
  | proven
  deriving DecidableEq, Repr

def isProven : Assessment → Bool
  | .proven => true
  | _ => false

theorem unknown_not_proven : isProven .unverified = false := rfl
theorem failed_not_proven : isProven .failed = false := rfl
theorem positive_proven : isProven .proven = true := rfl

/-- Abstract states and steps. Reachability requires an actual initial
    state plus zero or more declared transitions. -/
structure TransitionSystem (S : Type) where
  init : S → Prop
  step : S → S → Prop

inductive Reachable {S : Type} (ts : TransitionSystem S) : S → Prop where
  | initial (s : S) : ts.init s → Reachable ts s
  | next (s t : S) : Reachable ts s → ts.step s t → Reachable ts t

/-- A refinement proof is an explicit proof-carrying map. -/
structure Refinement {Op Abs : Type}
    (src : TransitionSystem Op)
    (dst : TransitionSystem Abs) where
  mapState : Op → Abs
  preservesInit : ∀ s, src.init s → dst.init (mapState s)
  preservesStep : ∀ s t, src.step s t →
    dst.step (mapState s) (mapState t)

theorem refinement_preserves_reachability {Op Abs : Type}
    (src : TransitionSystem Op) (dst : TransitionSystem Abs)
    (ρ : Refinement src dst) (s : Op) :
    Reachable src s → Reachable dst (ρ.mapState s) := by
  intro h
  induction h with
  | initial s hs =>
      exact Reachable.initial _ (ρ.preservesInit s hs)
  | next s t _ step ih =>
      exact Reachable.next _ _ ih (ρ.preservesStep s t step)

theorem refinement_preserves_invariant {Op Abs : Type}
    (src : TransitionSystem Op) (dst : TransitionSystem Abs)
    (ρ : Refinement src dst)
    (safe : Abs → Prop)
    (hSafe : ∀ s, Reachable dst s → safe s)
    (s : Op) (h : Reachable src s) :
    safe (ρ.mapState s) :=
  hSafe _ (refinement_preserves_reachability src dst ρ s h)

end NCPS
