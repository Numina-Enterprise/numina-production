import NCPSCodec
set_option autoImplicit false

/-!
Version identity, proposed genesis computation, and bounded collisions.
The original NUSD/chain genesis is not asserted equal to protocol genesis.
A deterministic function is NOT automatically injective.
-/

namespace NCPS.Advanced

structure ArtifactRelease where
  versionLabel : Nat
  governingSource : Bytes
  dependencyManifest : Bytes
  formalArtifact : Bytes
  deriving DecidableEq, Repr

def SameRelease (a b : ArtifactRelease) : Prop :=
  a.versionLabel = b.versionLabel ∧
  a.governingSource = b.governingSource ∧
  a.dependencyManifest = b.dependencyManifest ∧
  a.formalArtifact = b.formalArtifact

theorem same_release_is_equal (a b : ArtifactRelease)
    (h : SameRelease a b) : a = b := by
  cases a with
  | mk va sa ma fa =>
      cases b with
      | mk vb sb mb fb =>
          rcases h with ⟨hv, hs, hm, hf⟩
          cases hv
          cases hs
          cases hm
          cases hf
          rfl

def releaseA : ArtifactRelease :=
  ⟨1, [zeroByte], [], []⟩

def releaseB : ArtifactRelease :=
  ⟨1, [oneByte], [], []⟩

theorem labels_equal_but_releases_differ :
    releaseA.versionLabel = releaseB.versionLabel ∧
    ¬ SameRelease releaseA releaseB := by
  constructor
  · rfl
  · intro h
    have heq := same_release_is_equal releaseA releaseB h
    have hx : [zeroByte] = [oneByte] :=
      congrArg ArtifactRelease.governingSource heq
    have hne : zeroByte ≠ oneByte := by decide
    exact hne (List.cons.inj hx).1

structure SemanticSystem where
  governingRelease : ArtifactRelease
  importedEnvironment : Bytes
  formalization : Bytes

structure SourcePair where
  first : Bytes
  second : Bytes
  deriving DecidableEq, Repr

structure GenesisAlgorithm where
  derive : Nat → SourcePair → Bytes

def protocolGenesis (alg : GenesisAlgorithm)
    (v : Nat) (pair : SourcePair) : Bytes :=
  alg.derive v pair

theorem genesis_congruent (alg : GenesisAlgorithm)
    (v : Nat) (a b : SourcePair)
    (h : a = b) :
    protocolGenesis alg v a = protocolGenesis alg v b := by
  rw [h]

def constantGenesis : GenesisAlgorithm :=
  ⟨fun _ _ => emptyBytes⟩

theorem deterministic_does_not_imply_injective :
    ∃ a b : SourcePair,
      a ≠ b ∧
      protocolGenesis constantGenesis 1 a =
        protocolGenesis constantGenesis 1 b := by
  refine ⟨⟨[zeroByte], []⟩, ⟨[oneByte], []⟩, ?_, rfl⟩
  intro h
  have hs : [zeroByte] = [oneByte] :=
    congrArg SourcePair.first h
  have hne : zeroByte ≠ oneByte := by decide
  exact hne (List.cons.inj hs).1

/-- Search a finite range for a singleton at the earliest depth. -/
def searchWithin (candidateCount : Nat → Nat) : Nat → Option Nat
  | 0 => if candidateCount 0 == 1 then some 0 else none
  | n + 1 =>
      match searchWithin candidateCount n with
      | some d => some d
      | none =>
          if candidateCount (n + 1) == 1 then
            some (n + 1)
          else none

theorem zero_depth_unique :
    searchWithin (fun _ => 1) 0 = some 0 := rfl

theorem no_singleton_at_any_bound (limit : Nat) :
    searchWithin (fun _ => 2) limit = none := by
  induction limit with
  | zero => rfl
  | succ n ih => simp [searchWithin, ih]

theorem bounded_search_may_fail :
    searchWithin (fun _ => 2) 255 = none :=
  no_singleton_at_any_bound 255

end NCPS.Advanced
