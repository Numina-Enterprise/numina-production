import NCPSCore
set_option autoImplicit false

/-!
Typed relation IDs are declaration identities, not extensional sets.
Conformance is observational equality to a supplied specification,
not a claim about arbitrary executable systems.
-/
namespace NCPS.Advanced

structure RelationFamily where
  RelId : Type
  Inst : RelId → Type

def Semantics (F : RelationFamily) : Type :=
  (r : F.RelId) → F.Inst r → Bool

structure Implementation (F : RelationFamily) where
  eval : Semantics F

def realize {F : RelationFamily} (k : Implementation F) : Semantics F :=
  k.eval

def Conforms (F : RelationFamily) (spec : Semantics F)
    (k : Implementation F) : Prop :=
  ∀ (r : F.RelId) (q : F.Inst r), k.eval r q = spec r q

theorem conforms_implies_realize_eq
    (F : RelationFamily) (spec : Semantics F)
    (k : Implementation F) (h : Conforms F spec k) :
    realize k = spec := by
  funext r q
  exact h r q

theorem realize_eq_implies_conforms
    (F : RelationFamily) (spec : Semantics F)
    (k : Implementation F) (h : realize k = spec) :
    Conforms F spec k := by
  intro r q
  exact congrFun (congrFun h r) q

theorem conforms_iff_observational_equality
    (F : RelationFamily) (spec : Semantics F)
    (k : Implementation F) :
    Conforms F spec k ↔ realize k = spec := by
  constructor
  · exact conforms_implies_realize_eq F spec k
  · exact realize_eq_implies_conforms F spec k

theorem conforming_implementations_agree
    (F : RelationFamily) (spec : Semantics F)
    (a b : Implementation F)
    (ha : Conforms F spec a) (hb : Conforms F spec b)
    (r : F.RelId) (q : F.Inst r) :
    a.eval r q = b.eval r q := by
  calc
    a.eval r q = spec r q := ha r q
    _ = b.eval r q := (hb r q).symm

inductive DemoRelId where
  | precedes
  | conflicts
  deriving DecidableEq, Repr

def DemoInstances : DemoRelId → Type
  | .precedes => Nat × Nat
  | .conflicts => Bool × Bool

def demoFamily : RelationFamily :=
  ⟨DemoRelId, DemoInstances⟩

def emptyDemoSemantics : Semantics demoFamily :=
  fun r => match r with
    | .precedes => fun _ => false
    | .conflicts => fun _ => false

theorem declaration_ids_are_distinct :
    DemoRelId.precedes ≠ DemoRelId.conflicts := by
  decide

theorem both_demo_relations_empty_on_any_instances
    (r : DemoRelId) (q : DemoInstances r) :
    emptyDemoSemantics r q = false := by
  cases r <;> rfl

/-- Names must be resolved without local/import shadowing. -/
inductive ResolveError where
  | duplicate
  | absent
  deriving DecidableEq, Repr

structure SymbolRegistry (Name : Type) where
  localDecl : Name → Option Nat
  importDecl : Name → Option Nat

def resolve {Name : Type} (reg : SymbolRegistry Name)
    (name : Name) : Except ResolveError Nat :=
  match reg.localDecl name, reg.importDecl name with
  | some _, some _ => .error .duplicate
  | some v, none => .ok v
  | none, some v => .ok v
  | none, none => .error .absent

theorem duplicate_symbols_rejected {Name : Type}
    (reg : SymbolRegistry Name) (name : Name) (x y : Nat)
    (hl : reg.localDecl name = some x)
    (hi : reg.importDecl name = some y) :
    resolve reg name = .error .duplicate := by
  simp [resolve, hl, hi]

theorem local_only_resolves {Name : Type}
    (reg : SymbolRegistry Name) (name : Name) (x : Nat)
    (hl : reg.localDecl name = some x)
    (hi : reg.importDecl name = none) :
    resolve reg name = .ok x := by
  simp [resolve, hl, hi]

theorem imported_only_resolves {Name : Type}
    (reg : SymbolRegistry Name) (name : Name) (x : Nat)
    (hl : reg.localDecl name = none)
    (hi : reg.importDecl name = some x) :
    resolve reg name = .ok x := by
  simp [resolve, hl, hi]

theorem absent_symbols_rejected {Name : Type}
    (reg : SymbolRegistry Name) (name : Name)
    (hl : reg.localDecl name = none)
    (hi : reg.importDecl name = none) :
    resolve reg name = .error .absent := by
  simp [resolve, hl, hi]

end NCPS.Advanced
