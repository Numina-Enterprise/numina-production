import NCPSCore
set_option autoImplicit false

/-!
Four-valued closure checks prevent "unavailable" from being
misreported as "false" or "success". A pass is a status of a
check, not a theorem that its external assessment was sound.
-/

namespace NCPS.Advanced

inductive ClosureStage where
  | dependency | symbol | type | semantic
  | proof | conformance | mechanization
  deriving DecidableEq, Repr

inductive CheckStatus where
  | pass | fail | blocked | notChecked
  deriving DecidableEq, Repr

structure CheckInput where
  prerequisitesAvailable : Bool
  evaluated : Option Bool
  deriving DecidableEq, Repr

def check (input : CheckInput) : CheckStatus :=
  if input.prerequisitesAvailable then
    match input.evaluated with
    | some true => .pass
    | some false => .fail
    | none => .notChecked
  else .blocked

theorem unavailable_is_blocked (result : Option Bool) :
    check ⟨false, result⟩ = .blocked := rfl

theorem unchecked_is_not_passed :
    check ⟨true, none⟩ = .notChecked := rfl

theorem positive_check_passed :
    check ⟨true, some true⟩ = .pass := rfl

theorem negative_check_failed :
    check ⟨true, some false⟩ = .fail := rfl

theorem blocked_ne_failed : CheckStatus.blocked ≠ .fail := by decide
theorem blocked_ne_passed : CheckStatus.blocked ≠ .pass := by decide
theorem unchecked_ne_passed : CheckStatus.notChecked ≠ .pass := by decide

abbrev ClosureReport := ClosureStage → CheckStatus

def FullyClosed (report : ClosureReport) : Prop :=
  ∀ stage, report stage = .pass

theorem fully_closed_implies_each_pass (report : ClosureReport)
    (hc : FullyClosed report) (stage : ClosureStage) :
    report stage = .pass := hc stage

theorem blocked_stage_prevents_closure (report : ClosureReport)
    (stage : ClosureStage)
    (h : report stage = .blocked) :
    ¬ FullyClosed report := by
  intro hc
  have hp := hc stage
  rw [h] at hp
  cases hp

theorem failed_stage_prevents_closure (report : ClosureReport)
    (stage : ClosureStage)
    (h : report stage = .fail) :
    ¬ FullyClosed report := by
  intro hc
  have hp := hc stage
  rw [h] at hp
  cases hp

theorem unchecked_stage_prevents_closure (report : ClosureReport)
    (stage : ClosureStage)
    (h : report stage = .notChecked) :
    ¬ FullyClosed report := by
  intro hc
  have hp := hc stage
  rw [h] at hp
  cases hp

def allPass : ClosureReport := fun _ => .pass

theorem allPass_fully_closed : FullyClosed allPass := by
  intro s
  rfl

/-- Proof closure requires an actual pass, not evidence merely being mentioned. -/
theorem proof_gate_required (report : ClosureReport)
    (h : FullyClosed report) :
    report .proof = .pass := h .proof

/-- A version label does not manufacture evidence of a completed check. -/
structure EvidenceGate where
  exactVersion : Bytes
  sourceDigest : Bytes
  artifactDigest : Bytes
  checkerVersion : Bytes
  record : CheckInput

def evidenceStatus (ev : EvidenceGate) : CheckStatus :=
  check ev.record

theorem evidence_without_prerequisites_blocked
    (ev : EvidenceGate) (h : ev.record.prerequisitesAvailable = false) :
    evidenceStatus ev = .blocked := by
  simp [evidenceStatus, check, h]

end NCPS.Advanced
