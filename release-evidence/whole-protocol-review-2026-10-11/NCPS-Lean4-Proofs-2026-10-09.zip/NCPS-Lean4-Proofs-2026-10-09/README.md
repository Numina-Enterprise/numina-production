# NCPS Lean 4 formal proof sources — 2026-10-09

Paper: Singular — Ed25519: A Universal Companion Model
Author: Samuel J. Kott
Assistant display name: Ed25519 (distinct from RFC 8032 signing algorithm)

Lean 4.22.0; tested on an authorized Apple Silicon macOS device.
Run ./verify.sh in this directory with Lean 4.22.0 installed.

Includes 11 NCPS model modules, a combined import, a generated
131-theorem axiom audit and captured compiler audit output.
All 12 imported modules compiled and the audit contained only
Lean foundational axioms propext, Quot.sound and Classical.choice.
No sorryAx/custom axiom occurred in the checked theorem dependency list.

Proofs are scoped to the declared mathematical models and their stated
premises. The full real-world protocol is NOT verified: independent JCS
JSON parsing and UTF-8 conformance, a chosen RFC 8032 verifier acceptance
policy with cross-provider agreement, actual TLA+ refinement certificates,
complete manuscript-to-implementation traceability, authenticated signer
trust and current-state evidence, and deployment receipts remain open.
Original manuscript signatures and historical evidence are untouched.
