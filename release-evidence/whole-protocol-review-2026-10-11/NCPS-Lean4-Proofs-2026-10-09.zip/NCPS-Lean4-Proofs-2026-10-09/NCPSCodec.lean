import NCPSCore
set_option autoImplicit false

/-!
NCPS formal serialization and framing.
The concrete Sample codec is an illustrative binary encoding,
NOT a proof of RFC 8785 JCS conformance.
-/

namespace NCPS.Advanced

/-- Injectivity without an external library. -/
def Injective {A B : Type} (f : A → B) : Prop :=
  ∀ ⦃a b⦄, f a = f b → a = b

structure Codec (R : Type) where
  encode : R → Bytes
  decode : Bytes → Option R

def RoundTrip {R : Type} (c : Codec R) : Prop :=
  ∀ r, c.decode (c.encode r) = some r

theorem codec_injective_of_roundtrip {R : Type}
    (c : Codec R) (h : RoundTrip c) :
    Injective c.encode := by
  intro a b eq
  have hsome : some a = some b := by
    calc
      some a = c.decode (c.encode a) := (h a).symm
      _ = c.decode (c.encode b) := congrArg c.decode eq
      _ = some b := h b
  exact Option.some.inj hsome

/-- Canonical bytes are the exact image of the record encoder. -/
def CanonicalBytes {R : Type} (c : Codec R) :=
  {b : Bytes // ∃ r, c.encode r = b}

def serialize {R : Type} (c : Codec R) (r : R) : CanonicalBytes c :=
  ⟨c.encode r, ⟨r, rfl⟩⟩

def parseCanonical {R : Type} (c : Codec R)
    (b : CanonicalBytes c) : Option R :=
  c.decode b.1

theorem canonical_roundtrip {R : Type}
    (c : Codec R) (h : RoundTrip c) (r : R) :
    parseCanonical c (serialize c r) = some r := h r

theorem canonical_serialization_injective {R : Type}
    (c : Codec R) (h : RoundTrip c) :
    Injective (serialize c) := by
  intro r s eq
  apply codec_injective_of_roundtrip c h
  exact congrArg Subtype.val eq

/-- A schema-level semantic mapping can be partial in both directions. -/
structure SemanticMapping (O R : Type) where
  toRecord : O → Option R
  toObject : R → Option O

def encodeObject {O R : Type}
    (m : SemanticMapping O R) (c : Codec R) (o : O) : Option Bytes :=
  (m.toRecord o).map c.encode

def decodeObject {O R : Type}
    (m : SemanticMapping O R) (c : Codec R) (b : Bytes) : Option O :=
  (c.decode b).bind m.toObject

theorem encodeObject_defined {O R : Type}
    (m : SemanticMapping O R) (c : Codec R) (o : O) (r : R)
    (h : m.toRecord o = some r) :
    encodeObject m c o = some (c.encode r) := by
  simp [encodeObject, h]

theorem object_roundtrip {O R : Type}
    (m : SemanticMapping O R) (c : Codec R)
    (h : RoundTrip c) (o : O) (r : R)
    (hto : m.toRecord o = some r)
    (hfrom : m.toObject r = some o) :
    (encodeObject m c o).bind (decodeObject m c) = some o := by
  simp [encodeObject, decodeObject, hto, h r, hfrom]

/-- A simple example of an unambiguous binary record encoding. -/
def zeroByte : Byte := ⟨0, by decide⟩
def oneByte : Byte := ⟨1, by decide⟩

structure SampleRecord where
  flag : Bool
  payload : Bytes
  deriving DecidableEq, Repr

def sampleEncode (r : SampleRecord) : Bytes :=
  (if r.flag then oneByte else zeroByte) :: r.payload

def sampleDecode : Bytes → Option SampleRecord
  | [] => none
  | b :: rest =>
      if b = zeroByte then some ⟨false, rest⟩
      else if b = oneByte then some ⟨true, rest⟩
      else none

def sampleCodec : Codec SampleRecord :=
  ⟨sampleEncode, sampleDecode⟩

theorem sample_roundtrip (r : SampleRecord) :
    sampleDecode (sampleEncode r) = some r := by
  cases r with
  | mk flag payload =>
      cases flag <;> simp [sampleDecode, sampleEncode,
        zeroByte, oneByte]

theorem sample_codec_roundtrip : RoundTrip sampleCodec :=
  sample_roundtrip

theorem sample_encode_injective :
    Injective sampleEncode :=
  codec_injective_of_roundtrip sampleCodec sample_codec_roundtrip

theorem sample_rejects_empty : sampleDecode [] = none := rfl

/-- Domain separation is an exact byte-level tag plus one zero byte. -/
def frame (tag payload : Bytes) : Bytes :=
  tag ++ [zeroByte] ++ payload

theorem frame_length (tag payload : Bytes) :
    (frame tag payload).length = tag.length + 1 + payload.length := by
  simp [frame, Nat.add_assoc, Nat.add_comm, Nat.add_left_comm]

theorem frame_injective (tag : Bytes) :
    Injective (frame tag) := by
  intro a b h
  unfold frame at h
  have h2 : (tag ++ [zeroByte]) ++ a = (tag ++ [zeroByte]) ++ b := by
    simpa only [List.append_assoc] using h
  exact List.append_cancel_left h2

theorem frame_of_equal_payload (tag a b : Bytes) (h : a = b) :
    frame tag a = frame tag b := by
  rw [h]

end NCPS.Advanced
