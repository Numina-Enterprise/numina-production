from pathlib import Path
import re
expected=[line.removeprefix("#print axioms ") for line in Path("NCPSFullAxiomAudit.lean").read_text().splitlines() if line.startswith("#print axioms ")]
actual=Path("NCPSFullAxiomAudit.log").read_text().splitlines()
assert len(expected)==len(actual)==131,(len(expected),len(actual))
allow={"propext","Quot.sound","Classical.choice"}
used_totals={}
for ref,line in zip(expected,actual):
    pattern=r"^'"+re.escape(ref)+r"' (?:does not depend on any axioms|depends on axioms: \[([^]]*)\])$"
    match=re.fullmatch(pattern,line)
    assert match,(ref,line,pattern)
    used={x.strip() for x in (match.group(1) or "").split(",") if x.strip()}
    assert used <= allow,(line,used)
    for x in used: used_totals[x]=used_totals.get(x,0)+1
print("KERNEL_AUDIT_131_PASS CUSTOM_AXIOMS_0 SORRY_AX_0")
print("FOUNDATIONAL_DEPENDENCIES:",used_totals)
