import NCPSCore
set_option autoImplicit false

/-!
Refinement over an explicit reachable-state relation.
An operational transition can simulate one abstract transition or stutter.
No liveness theorem is claimed without fairness/progress premises.
-/

namespace NCPS.Advanced

structure TransitionSystem (S : Type) where
  init : S → Prop
  step : S → S → Prop

inductive Reachable {S : Type} (sys : TransitionSystem S) : S → Prop where
  | start {s : S} (h : sys.init s) : Reachable sys s
  | next {s t : S} (h : Reachable sys s)
      (step : sys.step s t) : Reachable sys t

structure Refinement {C A : Type}
    (concrete : TransitionSystem C)
    (abstract : TransitionSystem A) where
  mapState : C → A
  initial : ∀ c, concrete.init c → abstract.init (mapState c)
  steps : ∀ c d, concrete.step c d →
    (abstract.step (mapState c) (mapState d) ∨
      mapState c = mapState d)

theorem reachable_maps {C A : Type}
    {concrete : TransitionSystem C}
    {abstract : TransitionSystem A}
    (r : Refinement concrete abstract) :
    ∀ {c}, Reachable concrete c →
      Reachable abstract (r.mapState c) := by
  intro c hc
  induction hc with
  | start h =>
      exact Reachable.start (r.initial _ h)
  | next hc hstep ih =>
      cases r.steps _ _ hstep with
      | inl hs =>
          exact Reachable.next ih hs
      | inr heq =>
          exact heq ▸ ih

/-- Any invariant of abstract reachable states transfers to concrete states. -/
theorem safety_preserved {C A : Type}
    {concrete : TransitionSystem C}
    {abstract : TransitionSystem A}
    (r : Refinement concrete abstract)
    (safe : A → Prop)
    (hSafe : ∀ a, Reachable abstract a → safe a)
    (c : C)
    (hc : Reachable concrete c) :
    safe (r.mapState c) := by
  exact hSafe _ (reachable_maps r hc)

/-- Example: a counter system with optional stutters. -/
def counterConcrete : TransitionSystem Nat where
  init := fun n => n = 0
  step := fun n m => m = n ∨ m = n + 1

def counterAbstract : TransitionSystem Nat where
  init := fun n => n = 0
  step := fun n m => m = n + 1

def counterRefinement : Refinement counterConcrete counterAbstract where
  mapState := id
  initial := by
    intro n h
    exact h
  steps := by
    intro n m h
    rcases h with hStutter | hAdvance
    · exact Or.inr hStutter.symm
    · exact Or.inl hAdvance

theorem counter_refinement_preserves_reachability (n : Nat)
    (h : Reachable counterConcrete n) :
    Reachable counterAbstract n := by
  exact reachable_maps counterRefinement h

/-- Every concrete successor still has a corresponding abstract reachability proof. -/
theorem counter_concrete_next (n m : Nat)
    (h : Reachable counterConcrete n)
    (step : counterConcrete.step n m) :
    Reachable counterAbstract m := by
  apply counter_refinement_preserves_reachability
  exact Reachable.next h step

end NCPS.Advanced
