import NCPSCore
set_option autoImplicit false

/-!
NCPS UTF-8 input boundary model.

This validates whole-document byte decoding and a prohibited UTF-8 BOM.
JSON escapes and RFC 8785 canonical output require a SEPARATE,
fully specified JSON parser / canonicalizer; none is assumed here.
-/

namespace NCPS.Utf8

def asByteArray (b : NCPS.Bytes) : ByteArray :=
  ByteArray.mk ((b.map (fun x => UInt8.ofNat x.val)).toArray)

def byte (n : Nat) (h : n < 256) : NCPS.Byte := ⟨n, h⟩
def bom : NCPS.Bytes :=
  [byte 239 (by decide), byte 187 (by decide), byte 191 (by decide)]

def hasBom (b : NCPS.Bytes) : Bool := b.take 3 == bom
def decodeWholeDocument (b : NCPS.Bytes) : Option String :=
  if hasBom b then none else String.fromUTF8? (asByteArray b)

theorem bom_is_detected : hasBom bom = true := by decide

theorem bom_is_rejected : decodeWholeDocument bom = none := by
  simp [decodeWholeDocument, bom_is_detected]

theorem reject_any_bom_prefixed (tail : NCPS.Bytes) :
    decodeWholeDocument (bom ++ tail) = none := by
  have h : hasBom (bom ++ tail) = true := by
    simp [hasBom, bom]
  simp [decodeWholeDocument, h]

theorem decode_success_implies_no_bom
    (b : NCPS.Bytes) (s : String)
    (h : decodeWholeDocument b = some s) :
    hasBom b = false := by
  unfold decodeWholeDocument at h
  cases hb : hasBom b with
  | false => rfl
  | true => simp [hb] at h

theorem decode_success_implies_valid_utf8
    (b : NCPS.Bytes) (s : String)
    (h : decodeWholeDocument b = some s) :
    String.fromUTF8? (asByteArray b) = some s := by
  unfold decodeWholeDocument at h
  cases hb : hasBom b with
  | false => simpa [hb] using h
  | true => simp [hb] at h

def isNoncharacter (cp : Nat) : Bool :=
  (cp >= 0xFDD0 && cp <= 0xFDEF) ||
  (cp <= 0x10FFFF &&
    (cp % 0x10000 == 0xFFFE || cp % 0x10000 == 0xFFFF))

def allowedScalar (cp : Nat) : Bool :=
  (cp <= 0x10FFFF) &&
  !(cp >= 0xD800 && cp <= 0xDFFF) &&
  !(isNoncharacter cp)

theorem fdd0_is_noncharacter : isNoncharacter 0xFDD0 = true := by decide
theorem fdef_is_noncharacter : isNoncharacter 0xFDEF = true := by decide
theorem plane_zero_fffe_is_noncharacter :
    isNoncharacter 0xFFFE = true := by decide
theorem last_unicode_noncharacter :
    isNoncharacter 0x10FFFF = true := by decide
theorem ascii_is_allowed : allowedScalar 0x41 = true := by decide
theorem surrogate_is_rejected : allowedScalar 0xD800 = false := by decide
theorem noncharacter_is_rejected : allowedScalar 0xFDD0 = false := by decide

theorem allowed_scalar_no_noncharacter (cp : Nat)
    (h : allowedScalar cp = true) : isNoncharacter cp = false := by
  unfold allowedScalar at h
  simp only [Bool.and_eq_true, Bool.not_eq_true'] at h
  exact h.2

/- Escaped JSON names/values must be validated *after* JSON decoding.
   A byte-level UTF-8 decoder alone cannot reject escaped U+FDD0. -/

end NCPS.Utf8
