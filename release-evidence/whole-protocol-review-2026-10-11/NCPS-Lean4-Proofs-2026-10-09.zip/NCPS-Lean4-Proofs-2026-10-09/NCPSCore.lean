import Std
set_option autoImplicit false

/-!
NCPS formal core. All named theorems below have Lean proof terms.
All declared theorems have proof terms; no custom axioms.
Concrete byte sequences use List (Fin 256). The length-indexed
coproduct view is given separately by ByteTuple and TaggedBytes.
-/

namespace NCPS

abbrev Byte := Fin 256
abbrev Bytes := List Byte
abbrev ByteTuple (n : Nat) := Fin n → Byte
abbrev TaggedBytes := (n : Nat) × ByteTuple n

def emptyBytes : Bytes := []
def byteAt (b : Bytes) (i : Nat) : Option Byte := b[i]?
def concat (a b : Bytes) : Bytes := a ++ b

theorem byte_lt_256 (x : Byte) : x.val < 256 := x.isLt
theorem empty_length : emptyBytes.length = 0 := rfl
theorem length_zero_iff (b : Bytes) :
    b.length = 0 ↔ b = emptyBytes := by
  cases b with
  | nil => simp [emptyBytes]
  | cons x xs => simp [emptyBytes]

theorem concat_length (a b : Bytes) :
    (concat a b).length = a.length + b.length := by
  simp [concat]

theorem concat_empty_left (b : Bytes) :
    concat emptyBytes b = b := by
  simp [concat, emptyBytes]

theorem concat_empty_right (b : Bytes) :
    concat b emptyBytes = b := by
  simp [concat, emptyBytes]

theorem concat_assoc (a b c : Bytes) :
    concat (concat a b) c = concat a (concat b c) := by
  simp [concat, List.append_assoc]

theorem byteAt_out_of_bounds (b : Bytes) (i : Nat)
    (h : b.length ≤ i) : byteAt b i = none := by
  exact List.getElem?_eq_none h

theorem byteAt_in_bounds (b : Bytes) (i : Nat)
    (h : i < b.length) : byteAt b i = some b[i] := by
  exact List.getElem?_eq_getElem h

theorem bytes_ext (a b : Bytes)
    (h : ∀ i : Nat, byteAt a i = byteAt b i) : a = b := by
  apply List.ext_getElem?
  exact h

def toTagged (b : Bytes) : TaggedBytes :=
  ⟨b.length, fun i => b[i.val]⟩

def fromTagged (s : TaggedBytes) : Bytes := List.ofFn s.2

theorem fromTagged_length (s : TaggedBytes) :
    (fromTagged s).length = s.1 := by
  cases s with
  | mk n f => exact List.length_ofFn

theorem fromTagged_toTagged (b : Bytes) :
    fromTagged (toTagged b) = b := by
  apply List.ext_getElem?
  intro i
  simp only [fromTagged, toTagged, List.getElem?_ofFn]
  split
  · rename_i h
    simp only [List.getElem?_eq_getElem h]
  · rename_i h
    exact (List.getElem?_eq_none (Nat.le_of_not_gt h)).symm

def emptyTagged : TaggedBytes := ⟨0, fun i => Fin.elim0 i⟩

theorem emptyTagged_length : (fromTagged emptyTagged).length = 0 := by
  exact fromTagged_length emptyTagged

/-- Ordered extraction occurrences may contain duplicates. -/
abbrev Occurrences := List Bytes

/-- A finite extraction set is an extensional predicate with a list witness. -/
structure ExtractionSet where
  contains : Bytes → Prop
  finite : ∃ xs : List Bytes, ∀ b, contains b ↔ b ∈ xs

def ExtractionSet.empty : ExtractionSet :=
  ⟨fun _ => False, ⟨[], by simp⟩⟩

def ExtractionSet.fromList (xs : Occurrences) : ExtractionSet :=
  ⟨fun b => b ∈ xs, ⟨xs, by simp⟩⟩

def ExtractionSet.mem (s : ExtractionSet) (b : Bytes) : Prop := s.contains b

theorem ExtractionSet.empty_no_mem (b : Bytes) :
    ¬ ExtractionSet.mem ExtractionSet.empty b := by
  simp [ExtractionSet.mem, ExtractionSet.empty]

theorem ExtractionSet.fromList_mem (xs : Occurrences) (b : Bytes) :
    ExtractionSet.mem (ExtractionSet.fromList xs) b ↔ b ∈ xs := by
  rfl

theorem ExtractionSet.fromList_duplicate (b : Bytes) :
    (ExtractionSet.fromList [b, b]).contains =
      (ExtractionSet.fromList [b]).contains := by
  funext x
  apply propext
  simp [ExtractionSet.fromList]

theorem ExtractionSet.fromList_swap (a b : Bytes) :
    (ExtractionSet.fromList [a, b]).contains =
      (ExtractionSet.fromList [b, a]).contains := by
  funext x
  apply propext
  simp [ExtractionSet.fromList, or_comm]

inductive ExtractionResult where
  | rejected
  | accepted (values : ExtractionSet)

def erase : ExtractionResult → ExtractionSet
  | .rejected => ExtractionSet.empty
  | .accepted s => s

structure ParserProfile where
  parses : Bytes → Bool
  occurrences : Bytes → Occurrences

def extract (p : ParserProfile) (b : Bytes) : ExtractionResult :=
  if p.parses b then
    .accepted (ExtractionSet.fromList (p.occurrences b))
  else
    .rejected

def slices (p : ParserProfile) (b : Bytes) : ExtractionSet :=
  erase (extract p b)

theorem rejection_ne_empty_success :
    ExtractionResult.rejected ≠
      ExtractionResult.accepted ExtractionSet.empty := by
  intro h
  cases h

theorem erasure_collision :
    (erase .rejected).contains =
      (erase (.accepted ExtractionSet.empty)).contains := rfl

theorem extract_rejected_iff (p : ParserProfile) (b : Bytes) :
    extract p b = .rejected ↔ p.parses b = false := by
  unfold extract
  cases h : p.parses b <;> simp

theorem extract_accepted_iff (p : ParserProfile) (b : Bytes)
    (s : ExtractionSet) :
    extract p b = .accepted s ↔
      p.parses b = true ∧
      ExtractionSet.fromList (p.occurrences b) = s := by
  unfold extract
  cases h : p.parses b <;> simp

theorem nonempty_slices_implies_success (p : ParserProfile)
    (b : Bytes) (w : Bytes)
    (h : (slices p b).contains w) : p.parses b = true := by
  cases hp : p.parses b with
  | false =>
      have hn : ¬ (slices p b).contains w := by
        simp [slices, extract, hp, erase, ExtractionSet.empty]
      exact False.elim (hn h)
  | true => rfl

theorem accepted_empty_distinct_from_rejected :
    ExtractionResult.accepted (ExtractionSet.fromList []) ≠
      ExtractionResult.rejected := by
  intro h
  cases h

theorem extracted_empty_sequence_is_nonempty :
    (ExtractionSet.fromList [emptyBytes]).contains emptyBytes := by
  simp [ExtractionSet.fromList]


theorem ofFn_injective {n : Nat} (f g : Fin n → Byte)
    (h : List.ofFn f = List.ofFn g) : f = g := by
  funext i
  have hi := congrArg (fun l : List Byte => l[i.val]?) h
  simpa [List.getElem?_ofFn, i.isLt] using hi

theorem fromTagged_injective :
    ∀ s t : TaggedBytes, fromTagged s = fromTagged t → s = t := by
  intro s t he
  rcases s with ⟨n, f⟩
  rcases t with ⟨m, g⟩
  have hn : n = m := by
    have h := congrArg List.length he
    simpa [fromTagged] using h
  cases hn
  have hf : f = g := ofFn_injective f g he
  cases hf
  rfl

theorem toTagged_fromTagged (s : TaggedBytes) :
    toTagged (fromTagged s) = s := by
  apply fromTagged_injective
  exact fromTagged_toTagged (fromTagged s)

theorem tagged_equivalence_left (b : Bytes) :
    fromTagged (toTagged b) = b := fromTagged_toTagged b

theorem tagged_equivalence_right (s : TaggedBytes) :
    toTagged (fromTagged s) = s := toTagged_fromTagged s

end NCPS
