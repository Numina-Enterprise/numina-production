import NCPSCore
import NCPSCodec
import NCPSRelations
import NCPSState
import NCPSClosure
import NCPSVerification
import NCPSVersion

set_option autoImplicit false

/-!
Whole-protocol acceptance is a conjunction of separately checked gates.
This file intentionally does not manufacture empirical evidence from a
mathematical model. CurrentEvidence is an illustrative *status snapshot*
based on the explicitly identified open checks; it is not a cryptographic
attestation of live infrastructure or a universal finding of impossibility.
-/

namespace NCPS.Advanced

structure ProtocolEvidence where
  closure : ClosureReport
  policy : VerificationPolicy
  verifier : VerificationReport
  jcsInteroperability : CheckStatus
  signatureInteroperability : CheckStatus
  independentTrust : CheckStatus
  fieldDeployment : CheckStatus

def FullProtocolPass (ev : ProtocolEvidence) : Prop :=
  FullyClosed ev.closure ∧
  Accepts ev.policy ev.verifier ∧
  ev.jcsInteroperability = .pass ∧
  ev.signatureInteroperability = .pass ∧
  ev.independentTrust = .pass ∧
  ev.fieldDeployment = .pass

theorem full_pass_requires_jcs (ev : ProtocolEvidence)
    (h : FullProtocolPass ev) :
    ev.jcsInteroperability = .pass :=
  h.2.2.1

theorem full_pass_requires_signatures (ev : ProtocolEvidence)
    (h : FullProtocolPass ev) :
    ev.signatureInteroperability = .pass :=
  h.2.2.2.1

theorem full_pass_requires_trust (ev : ProtocolEvidence)
    (h : FullProtocolPass ev) :
    ev.independentTrust = .pass :=
  h.2.2.2.2.1

theorem full_pass_requires_field (ev : ProtocolEvidence)
    (h : FullProtocolPass ev) :
    ev.fieldDeployment = .pass :=
  h.2.2.2.2.2

theorem blocked_field_prevents_full_pass (ev : ProtocolEvidence)
    (hb : ev.fieldDeployment = .blocked) :
    ¬ FullProtocolPass ev := by
  intro hp
  have hf := full_pass_requires_field ev hp
  rw [hb] at hf
  cases hf

theorem incomplete_jcs_prevents_full_pass (ev : ProtocolEvidence)
    (hb : ev.jcsInteroperability = .notChecked) :
    ¬ FullProtocolPass ev := by
  intro hp
  have hj := full_pass_requires_jcs ev hp
  rw [hb] at hj
  cases hj

def unverifiedVerifier : VerificationReport where
  schema := .pass
  signature := .unavailable
  authority := .unavailable
  sourceCommitments := .pass
  currentSource := .unavailable
  freshness := .unavailable
  privateResolution := .unavailable

/--
A conservative evidence gate snapshot, *not* a source of new evidence.
The formal modules prove their local theorems; the complete manuscript,
independent JCS/Ed25519 interoperability, operational trust, and field
deployment are not established by those local proofs.
-/
def currentEvidence : ProtocolEvidence where
  closure := fun s =>
    match s with
    | .dependency => .notChecked
    | .symbol => .notChecked
    | .type => .notChecked
    | .semantic => .notChecked
    | .proof => .notChecked
    | .conformance => .blocked
    | .mechanization => .notChecked
  policy := ⟨true, true⟩
  verifier := unverifiedVerifier
  jcsInteroperability := .notChecked
  signatureInteroperability := .blocked
  independentTrust := .blocked
  fieldDeployment := .blocked

theorem current_evidence_not_full_pass :
    ¬ FullProtocolPass currentEvidence := by
  exact blocked_field_prevents_full_pass currentEvidence rfl

end NCPS.Advanced
