#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export LEAN_PATH="$PWD"
lean --version
for module in NCPSCore NCPSProtocol NCPSCodec NCPSRelations NCPSState NCPSClosure NCPSVerification NCPSVersion NCPSBoundaries NCPSAudit NCPSUtf8 NCPSAll; do
  lean -o "$module.olean" "$module.lean"
done
lean NCPSFullAxiomAudit.lean > NCPSFullAxiomAudit.recheck.log
cp NCPSFullAxiomAudit.recheck.log NCPSFullAxiomAudit.log
python3 check_axioms.py
