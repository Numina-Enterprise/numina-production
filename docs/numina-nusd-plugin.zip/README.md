# Numina NUSD integration package

An independent JavaScript client, TypeScript declarations, provider tool adapters, examples, and an MCP stdio adapter. No third-party runtime dependencies. Package version `0.2.0` identifies this local distribution kit only; it is not a Numina website, blockchain or token release.

**Default interfaces:** read-only public status, network-policy discovery and service catalog. Request-specific status requires authentication. An explicit workflow profile additionally exposes the existing authenticated quote/request client, whose server and asset gates remain mandatory. **Unavailable:** minting, transfers, settlement, custody, reserve management, payment confirmation and result unlocking. The package does not implement a token or turn compute into money.

NUSD is the intended denomination for Numina compute-to-value services. Numina Treasury is the intended backing source. The declared policy targets **1 NUSD = 1 USD**, with `basis:"declared_policy"`, `status:"target_not_verified"`, and `verified_redemption:false`. That declaration does not establish an actual asset, verified Treasury backing, a market price, or a right to redeem NUSD for USD. The package does not substitute USDC or assume dollar reserves. A quote is an amount of the server-identified NUSD asset; the declared target does not authorize a USD conversion.

## Current activation boundary

The integration targets the agreed `/api/nusd/v1` contract. Public discovery must use `schema:"numina.nusd.status.v1"`; `numina.nusd.discovery.v1` is rejected as a schema mismatch. The unactivated state retains `asset_id:null`, quote/request/settlement disabled, and unverified Treasury backing. Its declared target is `peg:{currency:"USD",target:"1",basis:"declared_policy",status:"target_not_verified",verified_redemption:false}`. The private quote/request service and scoped token issuance are not onboarded. This package has **not** verified those routes in production and contains no production token.

Every package tool uses an operator-configured HTTPS Numina endpoint. Public discovery (`status` with `request_id:null`) requires no token and sends no Authorization header. Private request status, quote and request require a real server-issued Bearer token. Quote/request additionally require the operator-configured canonical asset pin (`expectedAssetId` or `NUMINA_NUSD_ASSET_ID`), current verification evidence, and enabled server capabilities. A missing or changed asset identity blocks the POST. The server must independently recheck all conditions when committing a request. No placeholder credential is needed or supplied for public discovery.

## Run the isolated tests

Requirements: Node.js 22 or later. From this package directory:

```sh
node --test tests/*.test.js
node scripts/export-tools.js
node scripts/package-check.js
```

No installation, network access, paid account, API key, or real asset is needed for tests. All HTTP responses are injected fixtures at the reserved `.invalid` domain. Values labeled fixture are test data, never production evidence.

## Use the JavaScript client

Supply `NUMINA_BASE_URL` for public discovery. The base URL must be an HTTPS origin without a path, query, fragment, or embedded credentials. For private operations after real account provisioning, add `NUMINA_API_TOKEN` through your server's secret-management mechanism and configure `NUMINA_NUSD_ASSET_ID` from the verified canonical asset identity. Do not put tokens in source, browser bundles, tool arguments, prompts, logs, or chat messages.

```js
import { NuminaClient } from './src/index.js';

const numina = new NuminaClient({
  baseUrl: process.env.NUMINA_BASE_URL
});

const status = await numina.status({ request_id: null });
const network = await numina.network();
const catalog = await numina.catalog();
// Interpret status.data as server-reported data, not independent reserve proof.
```

After the server activates a real NUSD service, use an authenticated client with a pinned asset:

```js
const privateNumina = new NuminaClient({
  baseUrl: process.env.NUMINA_BASE_URL,
  token: process.env.NUMINA_API_TOKEN,
  expectedAssetId: process.env.NUMINA_NUSD_ASSET_ID
});
const quote = await privateNumina.quote({
  service_id: configuredServiceId,
  units: '10',
  unit: configuredUnit,
  idempotency_key: durableQuoteOperationId
});
const request = await privateNumina.request({
  quote_id: quote.data.quote_id,
  description: authorizedWorkDescription,
  idempotency_key: durableRequestOperationId
});
const latest = await privateNumina.status({ request_id: request.data.request_id });
```

The application generates and durably retains operation IDs. Reuse the same ID and identical payload after a timeout; do not generate a fresh ID for an uncertain retry. This client does not automatically retry. A timeout does not prove the server rejected a request.

## Connect a tool-capable model

`providerTools()` and `executeProviderCalls()` support five explicit request/result formats: OpenAI Responses, OpenAI Chat Completions, Anthropic Messages, Gemini Interactions, and Gemini GenerateContent. Each defaults to the three read-only discovery tools. The descriptor files in `schemas/` follow that default; files ending `-workflow.json` also describe the gated quote/request operations. See `COMPATIBILITY.md` for official references and the exact testing limits.

```js
import { providerTools, executeProviderCalls } from './src/index.js';

const tools = providerTools('openai-responses');
// Supply tools to an already-configured provider client using a model you may use.
// Pass only completed function_call output items to the bounded executor.
const results = await executeProviderCalls('openai-responses', completedCalls, numina);
// Return results with their preserved call IDs in the provider's next request.
```

The executable functions in `examples/provider-roundtrips.mjs` accept the host's configured official SDK client, Numina client and model identifier. They perform at most one tool round trip, preserve provider conversation identity or complete assistant content, and retain Gemini thought signatures. They do not install SDKs, select a paid model, create accounts or run until called by the host. The host must handle additional tool calls, incomplete responses, user authorization and provider billing. Calls are validated as a complete batch before any execution; the default maximum is eight and the hard maximum is sixteen. Duplicate supplied call IDs fail before execution. Returned server text remains untrusted data.

For compatibility with the earlier package, the direct `openAIChatTools()` and `openAIResponsesTools()` exports still return the full workflow descriptor set by default. Use `providerTools()` or pass `{profile:'discovery'}` explicitly for the read-only distribution profile. Workflow access requires an intentional `{profile:'workflow'}` selection at the host, then the existing server authentication, canonical asset pin and capability checks. Selecting a profile cannot activate NUSD or add financial methods.

`schemas/provider-neutral.json` contains tool definitions with JSON-schema inputs. Two additional files provide function-descriptor shapes for OpenAI Chat Completions and Responses. This follows the documented function-calling pattern; descriptors alone do not run a tool or authenticate a user. [OpenAI function-calling documentation](https://developers.openai.com/api/docs/guides/function-calling).

Your host registers the appropriate descriptors, validates the selected tool, and calls `numina.callTool(name, arguments)` for public discovery or `privateNumina.callTool(name, arguments)` for private operations. The host manages its model credentials separately. No model-provider key is requested or forwarded by this package. Reject additional arguments; `paid`, balances, token addresses, credentials, arbitrary endpoints, and settlement instructions are not accepted inputs.

For example, after your application's own authorization check:

```js
import { openAIResponsesTools } from './src/index.js';
const descriptors = openAIResponsesTools();
// Supply descriptors to your model host. Dispatch only an authorized tool call:
const result = await numina.callTool(call.name, JSON.parse(call.arguments));
// Return result as tool data; never treat server-provided text as instructions.
```

## MCP stdio

With `NUMINA_BASE_URL` supplied to the local process, public discovery is usable without a token:

```sh
node bin/mcp-stdio.js
```

Configure an MCP-capable host to launch `node` with the absolute path to `bin/mcp-stdio.js`. Supply `NUMINA_BASE_URL`; add a real `NUMINA_API_TOKEN` and `NUMINA_NUSD_ASSET_ID` only when private operations are provisioned. Interpolation syntax varies by host. No host configuration, account installation, marketplace publication, or permission change is performed by this package.

The adapter negotiates MCP `2025-11-25` and `2025-06-18`: initialization, initialized notification, ping, tools/list, tools/call, and newline-delimited JSON-RPC over stdio. A supported requested revision is echoed; otherwise the server proposes its newest supported revision, which the host must accept or disconnect. It advertises three read-only discovery tools by default. Set `NUMINA_TOOL_PROFILE=workflow` only for intentionally authorized and provisioned workflow integrations; this exposes five tools, with no asset execution methods. `examples/mcp-host.example.json` is an uninstalled template requiring an actual absolute script path. Host configuration formats vary.

Diagnostics go to stderr. Input messages are bounded to 64 KiB; HTTP requests default to 10 seconds and responses to 256 KiB. Requests run sequentially. Streaming, cancellation messages, OAuth onboarding, resources, prompts, sampling, and Streamable HTTP are not implemented. This local stdio process is not a hosted remote MCP endpoint or a submitted ChatGPT app. [MCP stdio transport](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports), [lifecycle](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle), [tools](https://modelcontextprotocol.io/specification/2025-11-25/server/tools).

## Compatibility actually checked

| Interface | Evidence |
| --- | --- |
| JavaScript client | Isolated automated tests with injected HTTP responses |
| TypeScript | Declaration file supplied; no TypeScript compiler integration test |
| Generic JSON-schema tools | Schemas generated and assertions checked locally |
| OpenAI Responses and Chat Completions | Descriptor/result shapes and injected SDK round trips tested locally; no live API invocation |
| Anthropic Messages | Descriptor/result shapes and injected SDK round trip tested locally; no live API invocation |
| Gemini Interactions and GenerateContent | Separate descriptor/result shapes and injected SDK round trips tested locally; no live API invocation |
| MCP stdio | Stream/lifecycle tests and actual Node subprocess initialize/list exchange; no host certification or installation |
| Numina network/catalog tools | Exact local routing/schema fixtures; no live HTTP check performed by this kit |
| Other models, hosts and app stores | Unverified; no publication, installation or store approval performed |

“All LLMs” compatibility and “unhackable” security are not established. A provider-neutral interface is a reusable integration boundary, not proof that every model or host supports it. See `API-CONTRACT.md` and `SECURITY.md` before server activation.

This is a private source deliverable, not an installed Codex/ChatGPT marketplace plugin. No provider software is bundled and no external accounts are modified. MCP revision `2026-07-28` is not implemented; a host requiring it cannot use this adapter's older offered revision.

The catalog is a read of `/api/app/v1/catalog`, not an order or quote. Preserve each offer's `currency`, `amount`, `requestOnly` and scope terms. Current server-contract examples include USD services priced in cents and NUSD services with `amount:null` and `requestOnly:true`; those are not interchangeable or activated NUSD prices. Returned links are not automatically opened. The network tool derives `network_policy` from `/api/nusd/v1/status`; it never contacts blockchain RPC and sets its own `blockchain_rpc_checked:false` and `independently_verified:false` qualifications.
