# Provider integration compatibility

Documentation checked on 2026-09-12. These adapters are locally validated formats, not provider certifications, live API acceptance tests, published listings or universal installation.

| Interface | Export | Tool result returned by executor |
| --- | --- | --- |
| OpenAI Responses | `providerTools('openai-responses')` | `function_call_output` with matching `call_id` |
| OpenAI Chat Completions | `providerTools('openai-chat-completions')` | `role:tool` with matching `tool_call_id` |
| Anthropic Messages | `providerTools('anthropic-messages')` | `tool_result` with matching `tool_use_id` |
| Gemini Interactions | `providerTools('gemini-interactions')` | `function_result` with `name`, `call_id` and text content |
| Gemini GenerateContent | `providerTools('gemini-generate-content')` | `functionResponse` retaining name and supplied call ID |
| MCP local stdio | `node bin/mcp-stdio.js` | MCP tool result with text and structured content |

OpenAI Responses uses top-level function fields; Chat Completions nests them inside `function`. Both exports set strict schemas. The host executes returned calls and supplies their corresponding results. [Official OpenAI Node tool guide](https://github.com/openai/openai-node/blob/main/docs/tools.md), [OpenAI function calling guide](https://developers.openai.com/api/docs/guides/function-calling).

Anthropic definitions use `input_schema`, with `strict:true` by default. The lower-level `anthropicTools({strict:false})` option omits strict mode when a chosen supported provider configuration requires that. Preserve the complete assistant content and return all result blocks together in the following user message. [Claude strict tool use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/strict-tool-use), [Claude tool-use operation](https://platform.claude.com/docs/en/agents-and-tools/tool-use/how-tool-use-works), [parallel result ordering](https://platform.claude.com/docs/en/agents-and-tools/tool-use/parallel-tool-use).

Gemini has distinct interfaces. Interactions uses top-level function declarations and conversation identity via `previous_interaction_id`. GenerateContent uses `functionDeclarations` and its documented `parametersJsonSchema` field, which must not be combined with `parameters`. Its model content must retain thought signatures. Model availability and actual supported schema subsets require live account-specific testing; none was performed here. [Gemini function calling](https://ai.google.dev/gemini-api/docs/function-calling), [GenerateContent FunctionDeclaration](https://ai.google.dev/api/generate-content#FunctionDeclaration).

MCP clients request a protocol revision; the server echoes supported revisions or proposes its latest supported version. The adapter implements the bounded tools subset for `2025-11-25` and `2025-06-18`. **The `2026-07-28` revision is not implemented or advertised.** A host requiring that revision must reject the older offered version. It provides no Streamable HTTP endpoint, remote OAuth flow, registry registration or managed-host installation. [MCP lifecycle](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle), [MCP transports](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports).

Tests cover schema shapes, nullable arguments, strict argument validation, read-only defaults, complete-batch validation, result correlation, error redaction, provider-specific history preservation, and local MCP process framing. TypeScript declarations are supplied but have not been checked by a TypeScript compiler. No external SDK dependencies are bundled or version-certified. Models without compatible tool interfaces, hosted marketplaces, mobile app stores and other providers remain unverified.

To make a provider installation claim, an authorized operator must configure that real host/account, select a model that supports the chosen interface, run its integration against permitted Numina endpoints, inspect actual responses, and record the result. Publishing a ZIP or generating tool JSON alone does not perform those actions.
