import test from 'node:test';
import assert from 'node:assert/strict';
import {NuminaClient} from '../src/client.js';
const TOKEN='offline-fixture-token-not-a-credential';
const catalog=()=>({offers:{diagnostic:{name:'Fixture diagnostic',amount:150000,currency:'usd',url:'https://checkout.invalid/fixture',description:'Fixture scope.'},
 result_access:{name:'Fixture result access',amount:null,currency:'nusd',requestOnly:true,description:'Request only; no active price or entitlement.'}},operator:'Fixture operator',scopeTerms:'Fixture scope terms.'});
const status=()=>({schema:'numina.nusd.status.v1',network_policy:{name:'Fixture chain',chain_id:null,rpc_url:null,status:'unverified'},
 asset:{symbol:'NUSD',asset_id:null},asset_verification:{status:'unconfigured',evidence:[]},capabilities:{quote:false,request:false,settlement:false}});
function fixture(data){const calls=[];const client=new NuminaClient({baseUrl:'https://numina.invalid',token:TOKEN,
 fetch:async(url,init)=>{calls.push({url,init});return new Response(JSON.stringify(data),{headers:{'Content-Type':'application/json'}});}});return {client,calls};}
test('catalog uses one credential-free GET and preserves currency, amount and request-only qualifications',async()=>{
 const data=catalog(),{client,calls}=fixture(data),result=await client.callTool('numina_service_catalog',{});
 assert.deepEqual(result.data,data);assert.equal(result.asset_execution_available,false);
 assert.equal(calls.length,1);assert.equal(calls[0].url,'https://numina.invalid/api/app/v1/catalog');
 assert.equal(calls[0].init.method,'GET');assert.equal(calls[0].init.headers.Authorization,undefined);
 assert.equal(calls[0].init.body,undefined);assert.equal(result.data.offers.diagnostic.amount,150000);
 assert.equal(result.data.offers.result_access.amount,null);assert.equal(result.data.offers.result_access.requestOnly,true);
});
test('catalog rejects malformed prices, lost request-only state, unsupported currencies and incomplete bodies',async()=>{
 for(const patch of [{amount:1.2},{amount:9007199254740992},{currency:'unknown'},{amount:null},{name:''}]){
  const data=catalog();Object.assign(data.offers.diagnostic,patch);
  await assert.rejects(fixture(data).client.catalog(),e=>e.code==='INVALID_SERVER_RESPONSE');
 }
 for(const data of [{},{offers:[]},{...catalog(),scopeTerms:null}])await assert.rejects(fixture(data).client.catalog(),e=>e.code==='INVALID_SERVER_RESPONSE');
});
test('network tool derives status without creating RPC verification, a contract identity or settlement',async()=>{
 const data=status(),{client,calls}=fixture(data),result=await client.network();
 assert.equal(calls.length,1);assert.equal(calls[0].url,'https://numina.invalid/api/nusd/v1/status');
 assert.equal(calls[0].init.headers.Authorization,undefined);assert.deepEqual(result.data.network_policy,data.network_policy);
 assert.equal(result.data.asset.asset_id,null);assert.equal(result.data.blockchain_rpc_checked,false);
 assert.equal(result.data.independently_verified,false);assert.equal(result.data.capabilities.settlement,false);
});
test('network missing policy remains unknown and malformed policy fails',async()=>{
 const absent=status();delete absent.network_policy;
 assert.equal((await fixture(absent).client.network()).data.network_policy,null);
 await assert.rejects(fixture({...status(),network_policy:'invented'}).client.network(),e=>e.code==='INVALID_SERVER_RESPONSE');
});
test('discovery rejects model-supplied URLs, credentials, paid claims and arguments before fetching',async()=>{
 const {client,calls}=fixture(catalog());
 for(const name of ['numina_nusd_network','numina_service_catalog'])for(const args of [{url:'https://attacker.invalid'},{paid:true},{token:TOKEN},{chain_id:'1'}])
  await assert.rejects(client.callTool(name,args),e=>e.code==='INVALID_ARGUMENTS');
 assert.equal(calls.length,0);
});
test('catalog redacts echoed credentials and treats returned links as data only',async()=>{
 const data=catalog();data.offers.diagnostic.description+=TOKEN;data.api_key='not-for-output';
 const {client,calls}=fixture(data),result=await client.catalog();
 assert.equal(JSON.stringify(result).includes(TOKEN),false);assert.equal(JSON.stringify(result).includes('not-for-output'),false);
 assert.equal(calls.length,1);
});
