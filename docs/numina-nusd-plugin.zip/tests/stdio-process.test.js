import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
test('actual stdio subprocess initializes and lists discovery tools without any HTTP operation',()=>{
 const messages=[{jsonrpc:'2.0',id:1,method:'initialize',params:{protocolVersion:'2025-11-25',capabilities:{},clientInfo:{name:'offline-process-fixture',version:'0'}}},
  {jsonrpc:'2.0',method:'notifications/initialized'},{jsonrpc:'2.0',id:2,method:'tools/list'},
  {jsonrpc:'2.0',id:3,method:'tools/call',params:{name:'mint',arguments:{}}}];
 const env={...process.env,NUMINA_BASE_URL:'https://numina.invalid',NUMINA_TOOL_PROFILE:'discovery'};
 delete env.NUMINA_API_TOKEN;delete env.NUMINA_NUSD_ASSET_ID;
 const processResult=spawnSync(process.execPath,[fileURLToPath(new URL('../bin/mcp-stdio.js',import.meta.url))],{
  input:messages.map(message=>JSON.stringify(message)).join('\n')+'\n',encoding:'utf8',timeout:5000,maxBuffer:1024*1024,
  env});
 assert.equal(processResult.status,0);assert.equal(processResult.stderr,'');
 const output=processResult.stdout.trim().split('\n').map(JSON.parse);
 assert.equal(output.length,3);assert.equal(output[0].result.protocolVersion,'2025-11-25');
 assert.equal(output[0].result.serverInfo.version,'0.2.0');
 assert.deepEqual(output[1].result.tools.map(tool=>tool.name),['numina_nusd_status','numina_nusd_network','numina_service_catalog']);
 assert.equal(output[2].error.code,-32602);
});
