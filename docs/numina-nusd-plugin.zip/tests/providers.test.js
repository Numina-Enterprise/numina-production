import test from 'node:test';
import assert from 'node:assert/strict';
import {NuminaError,providerTools,executeProviderCall,executeProviderCalls,NUMINA_TOOLS,anthropicTools} from '../src/index.js';
import {openAIResponsesRoundTrip,openAIChatRoundTrip,anthropicRoundTrip,geminiInteractionsRoundTrip,geminiGenerateContentRoundTrip} from '../examples/provider-roundtrips.mjs';
const NAME='numina_nusd_status',ID='fixture_call_1',ARGS={request_id:null};
const OUTPUT={source:'fixture-only',verification:'server_reported_not_independently_verified',asset_execution_available:false,data:{asset_id:null}};
const providers=['openai-responses','openai-chat-completions','anthropic-messages','gemini-interactions','gemini-generate-content'];
function call(provider,name=NAME,args=ARGS,id=ID){
 if(provider==='openai-responses')return {type:'function_call',call_id:id,name,arguments:JSON.stringify(args)};
 if(provider==='openai-chat-completions')return {type:'function',id,function:{name,arguments:JSON.stringify(args)}};
 if(provider==='anthropic-messages')return {type:'tool_use',id,name,input:args};
 if(provider==='gemini-interactions')return {type:'function_call',id,name,arguments:args};
 return {id,name,args};
}
function client(error){const calls=[];return {calls,async callTool(name,args){calls.push({name,args});if(error)throw error;return structuredClone(OUTPUT);}};}
function definitions(provider,tools){return provider==='gemini-generate-content'?tools[0].functionDeclarations:provider==='openai-chat-completions'?tools.map(t=>t.function):tools;}
test('five provider descriptor formats expose only three discovery tools by default',()=>{
 for(const provider of providers){
  const tools=providerTools(provider),defs=definitions(provider,tools);
  assert.deepEqual(defs.map(t=>t.name),['numina_nusd_status','numina_nusd_network','numina_service_catalog']);
  for(const definition of defs){
   const schema=definition.input_schema??definition.parametersJsonSchema??definition.parameters;
   assert.equal(schema.additionalProperties,false);assert.deepEqual(schema.required,Object.keys(schema.properties));
   if(provider.startsWith('openai')||provider==='anthropic-messages')assert.equal(definition.strict,true);
   if(provider==='gemini-generate-content')assert.equal(Object.hasOwn(definition,'parameters'),false);
  }
  assert.equal(definitions(provider,providerTools(provider,{profile:'workflow'})).length,5);
 }
 assert.equal(Object.hasOwn(anthropicTools({strict:false})[0],'strict'),false);
});
test('schema exports are independent copies and preserve nullable request IDs',()=>{
 for(const provider of providers){const defs=definitions(provider,providerTools(provider));
  const schema=defs[0].input_schema??defs[0].parametersJsonSchema??defs[0].parameters;
  assert.deepEqual(schema.properties.request_id.anyOf[1],{type:'null'});schema.properties.request_id.anyOf[1].type='string';
 }
 assert.equal(NUMINA_TOOLS.find(t=>t.name===NAME).inputSchema.properties.request_id.anyOf[1].type,'null');
});
test('each provider preserves call identity and returns its documented result envelope',async()=>{
 for(const provider of providers){const c=client(),out=await executeProviderCall(provider,call(provider),c);
  assert.deepEqual(c.calls,[{name:NAME,args:ARGS}]);
  if(provider==='openai-responses'){assert.equal(out.type,'function_call_output');assert.equal(out.call_id,ID);assert.deepEqual(JSON.parse(out.output),OUTPUT);}
  if(provider==='openai-chat-completions'){assert.equal(out.role,'tool');assert.equal(out.tool_call_id,ID);assert.deepEqual(JSON.parse(out.content),OUTPUT);}
  if(provider==='anthropic-messages'){assert.equal(out.type,'tool_result');assert.equal(out.tool_use_id,ID);assert.equal(out.is_error,false);assert.deepEqual(JSON.parse(out.content),OUTPUT);}
  if(provider==='gemini-interactions'){assert.equal(out.type,'function_result');assert.equal(out.call_id,ID);assert.equal(out.name,NAME);assert.deepEqual(JSON.parse(out.result[0].text),OUTPUT);}
  if(provider==='gemini-generate-content'){assert.equal(out.functionResponse.id,ID);assert.equal(out.functionResponse.name,NAME);assert.deepEqual(out.functionResponse.response,OUTPUT);}
 }
});
test('legacy Gemini call IDs remain optional and no identifier is invented',async()=>{
 const incoming=call('gemini-generate-content');delete incoming.id;
 const result=await executeProviderCall('gemini-generate-content',incoming,client());
 assert.equal(Object.hasOwn(result.functionResponse,'id'),false);
});
test('discovery rejects workflow and asset-execution proposals before calling the client',async()=>{
 for(const provider of providers){const c=client();
  for(const name of ['numina_nusd_quote','numina_nusd_request','mint','transfer','activate_nusd'])
   await assert.rejects(executeProviderCall(provider,call(provider,name,{}),c),e=>e.code==='TOOL_NOT_ALLOWED');
  assert.equal(c.calls.length,0);
 }
});
test('workflow opt-in preserves validation and does not permit arbitrary execution tools',async()=>{
 const c=client(),args={service_id:'fixture',units:'1',unit:'result',idempotency_key:'fixture_operation_0001'};
 await executeProviderCall('openai-responses',call('openai-responses','numina_nusd_quote',args),c,{profile:'workflow'});
 assert.deepEqual(c.calls,[{name:'numina_nusd_quote',args}]);
 await assert.rejects(executeProviderCall('openai-responses',call('openai-responses','mint',{}),c,{profile:'workflow'}),e=>e.code==='TOOL_NOT_ALLOWED');
});
test('invalid, truncated or extra arguments cannot execute even if a provider emitted a call',async()=>{
 for(const provider of providers){const c=client();
  await assert.rejects(executeProviderCall(provider,call(provider,NAME,{request_id:null,paid:true}),c),e=>e.code==='INVALID_ARGUMENTS');
  await assert.rejects(executeProviderCall(provider,call(provider,NAME,{request_id:'../other'}),c),e=>e.code==='INVALID_ARGUMENTS');
  assert.equal(c.calls.length,0);
 }
 for(const argumentsValue of ['{','x'.repeat(65537),{}]){
  const c=client();await assert.rejects(executeProviderCall('openai-responses',{...call('openai-responses'),arguments:argumentsValue},c),e=>e.code==='INVALID_PROVIDER_CALL');assert.equal(c.calls.length,0);
 }
});
test('batches validate before execution, reject repeated IDs and impose an explicit bound',async()=>{
 const c=client(),good=call('anthropic-messages');
 await assert.rejects(executeProviderCalls('anthropic-messages',[good,good],c),e=>e.code==='DUPLICATE_PROVIDER_CALL');
 await assert.rejects(executeProviderCalls('anthropic-messages',[good,call('anthropic-messages','mint',{},'fixture_call_2')],c),e=>e.code==='TOOL_NOT_ALLOWED');
 await assert.rejects(executeProviderCalls('anthropic-messages',Array(9).fill(good),c),e=>e.code==='INVALID_PROVIDER_BATCH');
 assert.equal(c.calls.length,0);
 const output=await executeProviderCalls('anthropic-messages',[good,call('anthropic-messages','numina_nusd_network',{},'fixture_call_2')],c);
 assert.deepEqual(output.map(o=>o.tool_use_id),[ID,'fixture_call_2']);
});
test('known client errors are framed safely while arbitrary exception text and codes are suppressed',async()=>{
 const canary='SECRET_CANARY_NEVER_EXPOSE';
 for(const provider of providers){
  const known=await executeProviderCall(provider,call(provider),client(new NuminaError('NUSD_NOT_VERIFIED')));
  assert.ok(JSON.stringify(known).includes('NUSD_NOT_VERIFIED'));
  for(const error of [new Error(canary),new NuminaError(canary)]){
   const result=await executeProviderCall(provider,call(provider),client(error));
   assert.equal(JSON.stringify(result).includes(canary),false);assert.ok(JSON.stringify(result).includes('TOOL_EXECUTION_FAILED'));
  }
 }
});
test('invalid providers, profiles, client objects and call IDs fail without execution',async()=>{
 const c=client();assert.throws(()=>providerTools('all-llms'),e=>e.code==='UNSUPPORTED_PROVIDER');
 assert.throws(()=>providerTools('openai-responses',{profile:'payments'}),e=>e.code==='INVALID_TOOL_PROFILE');
 await assert.rejects(executeProviderCall('openai-responses',call('openai-responses'),{}),e=>e.code==='INVALID_CLIENT');
 await assert.rejects(executeProviderCall('openai-responses',call('openai-responses',NAME,ARGS,''),c),e=>e.code==='INVALID_PROVIDER_CALL');
 assert.equal(c.calls.length,0);
});

test('OpenAI Responses example retains server conversation identity in one bounded round trip',async()=>{
 const requests=[],c=client(),first={id:'fixture_response',output:[{type:'reasoning',summary:[]},call('openai-responses')]};
 const provider={responses:{async create(input){requests.push(input);return requests.length===1?first:{done:true};}}};
 assert.deepEqual(await openAIResponsesRoundTrip({provider,numina:c,model:'fixture-model',input:'Fixture prompt'}),{done:true});
 assert.equal(requests.length,2);assert.equal(requests[1].previous_response_id,first.id);assert.equal(requests[1].input[0].call_id,ID);
});
test('OpenAI Chat example preserves the assistant tool-call message and matching tool response',async()=>{
 const requests=[],c=client(),assistant={role:'assistant',content:null,tool_calls:[call('openai-chat-completions')]};
 const provider={chat:{completions:{async create(input){requests.push(input);return requests.length===1?{choices:[{message:assistant}]}:{done:true};}}}};
 await openAIChatRoundTrip({provider,numina:c,model:'fixture-model',messages:[{role:'user',content:'Fixture prompt'}]});
 assert.deepEqual(requests[1].messages[1],assistant);assert.equal(requests[1].messages[2].tool_call_id,ID);
});
test('Anthropic example preserves full assistant blocks and places all results in the next user message',async()=>{
 const requests=[],c=client(),content=[{type:'thinking',thinking:'fixture',signature:'fixture-signature'},call('anthropic-messages')];
 const provider={messages:{async create(input){requests.push(input);return requests.length===1?{stop_reason:'tool_use',content}:{done:true};}}};
 await anthropicRoundTrip({provider,numina:c,model:'fixture-model',messages:[{role:'user',content:'Fixture prompt'}]});
 assert.deepEqual(requests[1].messages[1],{role:'assistant',content});assert.equal(requests[1].messages[2].role,'user');
 assert.equal(requests[1].messages[2].content[0].tool_use_id,ID);
});
test('Gemini Interactions example retains interaction identity and the function-result envelope',async()=>{
 const requests=[],c=client(),provider={interactions:{async create(input){requests.push(input);return requests.length===1?{id:'fixture_interaction',steps:[call('gemini-interactions')]}:{done:true};}}};
 await geminiInteractionsRoundTrip({provider,numina:c,model:'fixture-model',input:'Fixture prompt'});
 assert.equal(requests[1].previous_interaction_id,'fixture_interaction');assert.equal(requests[1].input[0].type,'function_result');
});
test('Gemini GenerateContent example preserves thought signatures and function response identity',async()=>{
 const requests=[],c=client(),modelContent={role:'model',parts:[{functionCall:call('gemini-generate-content'),thoughtSignature:'fixture-signature'}]};
 const provider={models:{async generateContent(input){requests.push(input);return requests.length===1?{candidates:[{content:modelContent}]}:{done:true};}}};
 await geminiGenerateContentRoundTrip({provider,numina:c,model:'fixture-model',contents:[{role:'user',parts:[{text:'Fixture prompt'}]}]});
 assert.deepEqual(requests[1].contents[1],modelContent);assert.equal(requests[1].contents[2].parts[0].functionResponse.id,ID);
});
