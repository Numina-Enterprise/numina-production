import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {providerTools} from '../src/provider-adapters.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const schemaRun=spawnSync(process.execPath,['scripts/export-tools.js'],{cwd:root,encoding:'utf8',timeout:10000});
if(schemaRun.status!==0)throw new Error('Schema generation failed');
for(const provider of ['openai-responses','openai-chat-completions','anthropic-messages','gemini-interactions','gemini-generate-content']){
 for(const profile of ['discovery','workflow']){
  const name=provider+(profile==='workflow'?'-workflow':'')+'.json';
  const actual=JSON.parse(fs.readFileSync(path.join(root,'schemas',name),'utf8'));
  if(JSON.stringify(actual)!==JSON.stringify(providerTools(provider,{profile})))throw new Error('Exported schema mismatch');
 }
}
const files=fs.readdirSync(path.join(root,'tests')).filter(name=>name.endsWith('.test.js')).sort().map(name=>'tests/'+name);
const tests=spawnSync(process.execPath,['--test','--test-concurrency=1','--test-reporter=tap',...files],{cwd:root,encoding:'utf8',timeout:30000,maxBuffer:2*1024*1024});
if(tests.status!==0)throw new Error('Local validation failed: '+tests.stdout+'\n'+tests.stderr);
const count=key=>Number(tests.stdout.match(new RegExp('^# '+key+' (\\d+)$','m'))?.[1]??-1);
if(count('tests')<1||count('pass')!==count('tests')||count('fail')!==0)throw new Error('Incomplete test evidence');
const metadata=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if(Object.keys(metadata.dependencies??{}).length||Object.keys(metadata.devDependencies??{}).length)throw new Error('Unexpected dependencies');
const verification={schema:'numina.integration.validation.v1',checkedAtUtc:new Date().toISOString(),
 package:{name:metadata.name,version:metadata.version,private:metadata.private},node:process.version,platform:process.platform,
 baselineTests:26,tests:{total:count('tests'),pass:count('pass'),fail:count('fail'),skipped:count('skipped')},
 testScope:'Injected HTTP and SDK fixtures plus an actual local stdio subprocess initialize/list exchange; no live provider, Numina HTTP or blockchain calls',
 providerFormats:['openai-responses','openai-chat-completions','anthropic-messages','gemini-interactions','gemini-generate-content'],
 schemaExportsChecked:10,mcpProtocolsImplemented:['2025-11-25','2025-06-18'],mcp20260728Implemented:false,
 defaultProfile:'discovery',defaultTools:['numina_nusd_status','numina_nusd_network','numina_service_catalog'],
 dependenciesAdded:0,typeScriptCompilerChecked:false,liveProviderAcceptanceVerified:false,remoteMcpHosted:false,
 providerInstallationPerformed:false,registryPublicationPerformed:false,appStoreSubmissionPerformed:false,
 nusdActivated:false,mintPerformed:false,transferPerformed:false,settlementConnected:false};
fs.writeFileSync(path.join(root,'verification.json'),JSON.stringify(verification,null,2)+'\n');
fs.writeFileSync(path.join(root,'VALIDATION.md'),`# Local validation\n\nChecked ${verification.checkedAtUtc} with ${verification.node} on ${verification.platform}.\n\n${count('pass')} of ${count('tests')} tests passed; ${count('fail')} failed. The copied baseline passed 26 tests before changes.\n\nCoverage: existing client gates, public network/catalog routing, currency and request-only preservation, five provider descriptor/result shapes, fixture SDK history preservation, strict argument validation, batch bounds and duplicate IDs, credential/error redaction, MCP negotiation and framing, and actual local stdio subprocess initialization/listing. Ten generated provider/profile JSON files match their exported definitions.\n\nAll HTTP and SDK responses are fixtures. No live provider API, Numina endpoint or blockchain was called in validation. TypeScript declarations were not compiler-checked. MCP 2026-07-28 is not implemented. This is not a provider certification, deployment, universal installation, publication, app-store submission, NUSD activation or independent security audit.\n`);
const top=['package.json','.gitignore','README.md','API-CONTRACT.md','SECURITY.md','COMPATIBILITY.md','VALIDATION.md','verification.json'];
const gather=(directory)=>fs.readdirSync(path.join(root,directory),{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name)).flatMap(entry=>{
 const relative=directory+'/'+entry.name;
 if(entry.isSymbolicLink())throw new Error('Symlinks are not package inputs');
 return entry.isDirectory()?gather(relative):[relative];
});
const packaged=[...top,...['src','bin','schemas','examples','tests','scripts'].flatMap(gather)].sort();
const manifest={schema:'numina.integration.files.v1',scope:'Local source distribution kit, not a production release or publication record',files:packaged.map(relative=>{
 if(/(?:^|\/)\.env|\.private\.|\.(?:pem|key|tgz|zip)$/.test(relative))throw new Error('Private or generated archive file cannot be packaged');
 const bytes=fs.readFileSync(path.join(root,relative));return {path:relative,bytes:bytes.length,sha256:sha(bytes)};
})};
fs.writeFileSync(path.join(root,'file-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify({tests:verification.tests,files:manifest.files.length+1,packageVersion:metadata.version,dependenciesAdded:0,liveProviderAcceptanceVerified:false,nusdActivated:false}));
