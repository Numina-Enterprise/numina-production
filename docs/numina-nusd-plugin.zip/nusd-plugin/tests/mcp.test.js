import test from 'node:test';
import assert from 'node:assert/strict';
import {Readable,Writable} from 'node:stream';
import {createMcpHandler,runStdio,MCP_PROTOCOL} from '../src/mcp.js';
import {NuminaClient} from '../src/client.js';
const init={jsonrpc:'2.0',id:1,method:'initialize',params:{protocolVersion:MCP_PROTOCOL,capabilities:{},clientInfo:{name:'isolated-fixture',version:'0'}}};
const initialized={jsonrpc:'2.0',method:'notifications/initialized'};
function client(token='local-fixture-token-only'){return new NuminaClient({baseUrl:'https://numina.invalid',token,expectedAssetId:'fixture:asset',fetch:async()=>new Response(JSON.stringify({schema:'numina.nusd.status.v1',asset:{symbol:'NUSD',asset_id:null},asset_verification:{status:'unconfigured',evidence:[]},capabilities:{quote:false,request:false,status:true,settlement:false}}),{headers:{'Content-Type':'application/json'}})});}
test('MCP requires initialization and initialized notification, lists exact capabilities',async()=>{
  const handle=createMcpHandler(client());assert.equal((await handle({jsonrpc:'2.0',id:0,method:'tools/list'})).error.code,-32002);
  assert.equal((await handle(init)).result.protocolVersion,MCP_PROTOCOL);
  assert.equal((await handle({jsonrpc:'2.0',id:2,method:'tools/list'})).error.code,-32002);
  assert.equal(await handle(initialized),null);
  const list=await handle({jsonrpc:'2.0',id:3,method:'tools/list'});assert.equal(list.result.tools.length,3);
  assert.equal((await handle(init)).error.code,-32600);
});
test('MCP returns server data and fail-closed tool errors',async()=>{
  const handle=createMcpHandler(client());await handle(init);await handle(initialized);
  const status=await handle({jsonrpc:'2.0',id:2,method:'tools/call',params:{name:'numina_nusd_status',arguments:{request_id:null}}});assert.equal(status.result.isError,false);assert.equal(status.result.structuredContent.data.asset.asset_id,null);
  const blocked=await handle({jsonrpc:'2.0',id:3,method:'tools/call',params:{name:'numina_nusd_quote',arguments:{service_id:'example',units:'1',unit:'record',idempotency_key:'fixture_idempotency_001'}}});assert.equal(blocked.result.isError,true);assert.match(blocked.result.content[0].text,/NUSD_NOT_VERIFIED/);
  assert.equal((await handle({jsonrpc:'2.0',id:4,method:'tools/call',params:{name:'transfer',arguments:{}}})).error.code,-32602);
});
test('tokenless MCP status works while private tools return auth errors',async()=>{
  const handle=createMcpHandler(client(''));await handle(init);await handle(initialized);
  const status=await handle({jsonrpc:'2.0',id:2,method:'tools/call',params:{name:'numina_nusd_status',arguments:{request_id:null}}});assert.equal(status.result.isError,false);assert.equal(status.result.structuredContent.data.asset.symbol,'NUSD');
  const quote=await handle({jsonrpc:'2.0',id:3,method:'tools/call',params:{name:'numina_nusd_quote',arguments:{service_id:'example',units:'1',unit:'record',idempotency_key:'fixture_idempotency_001'}}});assert.equal(quote.result.isError,true);assert.match(quote.result.content[0].text,/SERVER_AUTH_REQUIRED/);
});
test('stdio uses newline JSON only and tolerates parse errors without executing them',async()=>{
  let stdout='',stderr='';const out=new Writable({write(chunk,encoding,done){stdout+=chunk.toString();done();}});const err={write:s=>stderr+=s};
  const lines=[init,initialized,{jsonrpc:'2.0',id:2,method:'tools/list'}].map(v=>JSON.stringify(v)+'\n');
  const ok=await runStdio(client(),{input:Readable.from([lines[0].slice(0,12),lines[0].slice(12),lines[1],'{bad}\n',lines[2]]),output:out,errorOutput:err});assert.equal(ok,true);assert.equal(stderr,'');
  const messages=stdout.trim().split('\n').map(JSON.parse);assert.equal(messages.length,3);assert.equal(messages[1].error.code,-32700);assert.equal(messages[2].result.tools.length,3);
});
test('stdio rejects oversized and unterminated messages',async()=>{
  let stdout='',stderr='';const output=new Writable({write(chunk,encoding,done){stdout+=chunk.toString();done();}});
  assert.equal(await runStdio(client(),{input:Readable.from(['a'.repeat(80)]),output,errorOutput:{write:s=>stderr+=s},maxLineBytes:64}),false);assert.match(stderr,/limit/);assert.equal(stdout,'');
  assert.equal(await runStdio(client(),{input:Readable.from(['{']),output,errorOutput:{write:s=>stderr+=s}}),true);assert.equal(JSON.parse(stdout).error.code,-32700);
});
