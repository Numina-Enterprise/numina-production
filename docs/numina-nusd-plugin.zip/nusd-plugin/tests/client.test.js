import test from 'node:test';
import assert from 'node:assert/strict';
import {NuminaClient,NuminaError,NUMINA_TOOLS,openAIChatTools,openAIResponsesTools} from '../src/index.js';

// Isolated fixtures: no real endpoint, token, NUSD contract, balances or reserve evidence.
const TOKEN='isolated-fixture-token-not-a-real-credential';
const quoteInput={service_id:'fixture_service',units:'3',unit:'accepted_records',idempotency_key:'fixture_quote_request_001'};
const requestInput={quote_id:'fixture_quote',description:'Fixture request only',idempotency_key:'fixture_order_request_001'};
const active=()=>({schema:'numina.nusd.status.v1',asset:{symbol:'NUSD',asset_id:'fixture:asset'},asset_verification:{status:'verified',evidence:['fixture-only']},treasury_backing:{status:'unverified',evidence:[]},peg:null,capabilities:{quote:true,request:true,status:true,settlement:false}});
const quote=()=>({schema:'numina.nusd.quote.v1',quote_id:'fixture_quote',asset_id:'fixture:asset',symbol:'NUSD',amount_base_units:'300',decimals:2,expires_at:Math.floor(Date.now()/1000)+60});
const order=()=>({schema:'numina.nusd.request.v1',request_id:'fixture_request',quote_id:'fixture_quote',asset_id:'fixture:asset',status:'submitted'});
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});
function fixture(handler=()=>json(active()),options={}){const calls=[];const client=new NuminaClient({baseUrl:'https://numina.invalid',token:TOKEN,expectedAssetId:'fixture:asset',fetch:async(url,init)=>{calls.push({url,init});return handler(url,init,calls.length);},...options});return {client,calls};}
const rejects=(promise,code)=>assert.rejects(promise,e=>e instanceof NuminaError&&e.code===code);

test('configuration requires HTTPS origin; a token is optional but validated when supplied',()=>{
  for(const baseUrl of ['http://numina.invalid','https://user:pass@numina.invalid','https://numina.invalid/other','https://numina.invalid/?token=x'])assert.throws(()=>new NuminaClient({baseUrl,token:TOKEN}),/INVALID_ENDPOINT/);
  assert.doesNotThrow(()=>new NuminaClient({baseUrl:'https://numina.invalid'}));
  assert.throws(()=>new NuminaClient({baseUrl:'https://numina.invalid',token:'bad'}),/INVALID_SERVER_AUTH/);
});
test('public status omits credentials even when configured and makes no asset execution claim',async()=>{
  const {client,calls}=fixture();const result=await client.status();
  assert.equal(calls[0].url,'https://numina.invalid/api/nusd/v1/status');
  assert.equal(calls[0].init.headers.Authorization,undefined);assert.equal(calls[0].init.redirect,'error');
  assert.equal(calls[0].init.credentials,'omit');assert.equal(result.asset_execution_available,false);
  assert.equal(result.verification,'server_reported_not_independently_verified');assert.equal(result.data.peg,null);
});
test('tokenless public status succeeds and does not corrupt response strings',async()=>{
  for(const token of [undefined,'',null]){const {client,calls}=fixture(()=>json(active()),{token});const result=await client.callTool('numina_nusd_status',{request_id:null});assert.equal(result.data.asset.symbol,'NUSD');assert.equal(result.data.asset.asset_id,'fixture:asset');assert.equal(calls[0].init.headers.Authorization,undefined);}
});
test('tokenless quote, request, and private status fail before network access',async()=>{
  const {client,calls}=fixture(undefined,{token:undefined});
  await rejects(client.quote(quoteInput),'SERVER_AUTH_REQUIRED');await rejects(client.request(requestInput),'SERVER_AUTH_REQUIRED');await rejects(client.status({request_id:'fixture_request'}),'SERVER_AUTH_REQUIRED');assert.equal(calls.length,0);
});
test('private request status sends configured Bearer authentication',async()=>{
  const {client,calls}=fixture(()=>json(order()));await client.status({request_id:'fixture_request'});assert.equal(calls[0].init.headers.Authorization,'Bearer '+TOKEN);
});
test('mutations require a configured asset pin and reject changed discovery identity',async()=>{
  const {client,calls}=fixture(undefined,{expectedAssetId:undefined});await rejects(client.quote(quoteInput),'NUSD_ASSET_PIN_REQUIRED');assert.equal(calls.length,0);
  const {client:mismatch,calls:mismatchCalls}=fixture(undefined,{expectedAssetId:'fixture:different'});await rejects(mismatch.request(requestInput),'NUSD_ASSET_MISMATCH');assert.equal(mismatchCalls.length,1);assert.equal(mismatchCalls[0].init.method,'GET');
});
test('unconfigured NUSD blocks quotes and requests before any POST',async()=>{
  const unavailable={...active(),asset:{symbol:'NUSD',asset_id:null},asset_verification:{status:'unconfigured',evidence:[]},capabilities:{quote:false,request:false,status:true,settlement:false}};
  const {client,calls}=fixture(()=>json(unavailable));
  await rejects(client.quote(quoteInput),'NUSD_NOT_VERIFIED');await rejects(client.request(requestInput),'NUSD_NOT_VERIFIED');
  assert.equal(calls.length,2);assert.ok(calls.every(c=>c.init.method==='GET'));
});
test('asset label alone and empty verification evidence are insufficient',async()=>{
  const {client}=fixture(()=>json({...active(),asset_verification:{status:'verified',evidence:[]}}));
  await rejects(client.quote(quoteInput),'NUSD_NOT_VERIFIED');
});
test('disabled capability blocks POST even with configured asset',async()=>{
  const {client,calls}=fixture(()=>json({...active(),capabilities:{quote:false}}));
  await rejects(client.quote(quoteInput),'CAPABILITY_UNAVAILABLE');assert.equal(calls.length,1);
});
test('quote and request preserve integer quantities and idempotency keys',async()=>{
  const {client,calls}=fixture(url=>json(url.endsWith('/status')?active():url.endsWith('/quotes')?quote():order()));
  assert.equal((await client.quote(quoteInput)).data.amount_base_units,'300');
  assert.equal((await client.request(requestInput)).data.request_id,'fixture_request');
  for(const [input,index]of [[quoteInput,1],[requestInput,3]]){assert.deepEqual(JSON.parse(calls[index].init.body),input);assert.equal(calls[index].init.headers['Idempotency-Key'],input.idempotency_key);assert.equal(calls[index].init.headers.Authorization,'Bearer '+TOKEN);}
});
test('caller mutation during preflight cannot change submitted payload',async()=>{
  const input={...quoteInput};const {client,calls}=fixture((url)=>{if(url.endsWith('/status')){input.paid=true;input.units='999';return json(active());}return json(quote());});
  await client.quote(input);assert.deepEqual(JSON.parse(calls[1].init.body),quoteInput);
});
test('paid claims, URLs, credentials and execution tools are rejected before fetch',async()=>{
  const {client,calls}=fixture();
  for(const extra of [{paid:true},{payment_status:'paid'},{api_key:'provider_secret'},{url:'https://attacker.invalid'},{token:TOKEN},{amount:'10'}])await rejects(client.quote({...quoteInput,...extra}),'INVALID_ARGUMENTS');
  await rejects(client.callTool('mint',{}),'UNKNOWN_TOOL');await rejects(client.status({request_id:'../private'}),'INVALID_ARGUMENTS');assert.equal(calls.length,0);
});
test('status does not substitute another request',async()=>{
  const {client}=fixture(()=>json(order()));await rejects(client.status({request_id:'different_request'}),'REQUEST_ID_MISMATCH');
});
test('quote rejects another asset, expired quote and floating-point money',async()=>{
  for(const broken of [{asset_id:'other'},{symbol:'USD'},{expires_at:1},{amount_base_units:300},{amount_base_units:'3.5'}]){
    const {client}=fixture(url=>json(url.endsWith('/status')?active():{...quote(),...broken}));await rejects(client.quote(quoteInput),'INVALID_SERVER_QUOTE');
  }
});
test('response failures do not leak tokens or upstream errors',async()=>{
  const {client}=fixture(()=>{throw Error(TOKEN);});await rejects(client.status(),'CONNECTION_FAILED');
  const {client:unauth}=fixture(()=>json({secret:TOKEN},401));await rejects(unauth.status(),'SERVER_AUTH_REJECTED');
});
test('redacts echoed credential values, keys and secret fields',async()=>{
  const {client}=fixture(()=>json({...active(),note:'echo '+TOKEN,[TOKEN]:'redacted key',authorization:'never',nested:{api_key:'provider-secret'}}));
  const result=JSON.stringify(await client.status());assert.ok(!result.includes(TOKEN));assert.ok(!result.includes('provider-secret'));assert.ok(result.includes('[redacted]'));
});
test('rejects redirects, non-JSON, invalid JSON and oversized response streams',async()=>{
  const responses=[new Response(null,{status:302,headers:{Location:'https://attacker.invalid'}}),new Response('html'),new Response('{',{headers:{'Content-Type':'application/json'}}),json({text:'a'.repeat(1000)})];
  const codes=['REDIRECT_REFUSED','INVALID_SERVER_RESPONSE','INVALID_SERVER_RESPONSE','RESPONSE_TOO_LARGE'];
  for(let i=0;i<responses.length;i++){const {client}=fixture(()=>responses[i],{maxResponseBytes:256});await rejects(client.status(),codes[i]);}
});
test('timeout bounds an uncooperative fetch and a stalled body',async()=>{
  const {client}=fixture(()=>new Promise(()=>{}),{timeoutMs:15});await rejects(client.status(),'REQUEST_TIMEOUT');
  let cancelled=false;const stream=new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('{'));},cancel(){cancelled=true;}});
  const {client:stalled}=fixture(()=>new Response(stream,{headers:{'Content-Type':'application/json'}}),{timeoutMs:15});await rejects(stalled.status(),'REQUEST_TIMEOUT');assert.equal(cancelled,true);
});
test('tool schemas only expose three capabilities and no monetary assertions',()=>{
  assert.deepEqual(NUMINA_TOOLS.map(t=>t.name),['numina_nusd_quote','numina_nusd_request','numina_nusd_status']);
  for(const tool of NUMINA_TOOLS){assert.equal(tool.inputSchema.additionalProperties,false);assert.deepEqual(tool.inputSchema.required,Object.keys(tool.inputSchema.properties));}
  assert.equal(openAIChatTools()[0].function.strict,true);assert.equal(openAIResponsesTools()[0].strict,true);
});
