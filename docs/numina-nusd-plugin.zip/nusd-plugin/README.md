# Numina NUSD integration package

An independent JavaScript client, TypeScript declarations, JSON-schema tool descriptors, and a minimal MCP stdio adapter. No third-party runtime dependencies. Package version `0.1.0` identifies this integration package only; it is not a new Numina production release.

**Available interfaces:** authenticated NUSD quote, workflow request, and status. **Unavailable:** minting, transfers, settlement, custody, reserve management, payment confirmation, result unlocking, and provider execution. The package does not implement a token or turn compute into money.

NUSD is the intended denomination for Numina compute-to-value services. Numina Treasury is the intended backing source. Neither an actual asset nor Treasury backing is established by this package. It does not substitute USDC, assume dollar reserves, or presume a USD peg. A quote is an amount of the server-identified NUSD asset, not a USD conversion.

## Current activation boundary

The integration targets the agreed `/api/nusd/v1` contract. The initial Site implementation is intended to expose public discovery with `asset_id:null`, quote/request/settlement disabled, unverified Treasury backing, and `peg:null`. The private quote/request service and scoped token issuance are not onboarded. This package has **not** verified those routes in production and contains no production token.

Every package tool requires an operator-configured HTTPS Numina endpoint and a server-issued Bearer credential. Do not invent a token to connect to public discovery. Public discovery can separately be inspected without this authenticated client. Quote/request methods first read server status and reject missing NUSD identity, missing verification evidence, or disabled capabilities before issuing a POST. The server must independently recheck all conditions when committing a request.

## Run the isolated tests

Requirements: Node.js 22 or later. From this package directory:

```sh
node --test tests/*.test.js
node scripts/export-tools.js
```

No installation, network access, paid account, API key, or real asset is needed for tests. All HTTP responses are injected fixtures at the reserved `.invalid` domain. Values labeled fixture are test data, never production evidence.

## Use the JavaScript client

Supply `NUMINA_BASE_URL` and `NUMINA_API_TOKEN` through your server's secret-management mechanism after real account provisioning. The base URL must be an HTTPS origin without a path, query, fragment, or embedded credentials. Do not put tokens in source, browser bundles, tool arguments, prompts, logs, or chat messages.

```js
import { NuminaClient } from './src/index.js';

const numina = new NuminaClient({
  baseUrl: process.env.NUMINA_BASE_URL,
  token: process.env.NUMINA_API_TOKEN
});

const status = await numina.status({ request_id: null });
// Interpret status.data as server-reported data, not independent reserve proof.
```

After the server activates a real NUSD service:

```js
const quote = await numina.quote({
  service_id: configuredServiceId,
  units: '10',
  unit: configuredUnit,
  idempotency_key: durableQuoteOperationId
});
const request = await numina.request({
  quote_id: quote.data.quote_id,
  description: authorizedWorkDescription,
  idempotency_key: durableRequestOperationId
});
const latest = await numina.status({ request_id: request.data.request_id });
```

The application generates and durably retains operation IDs. Reuse the same ID and identical payload after a timeout; do not generate a fresh ID for an uncertain retry. This client does not automatically retry. A timeout does not prove the server rejected a request.

## Connect a tool-capable model

`schemas/provider-neutral.json` contains tool definitions with JSON-schema inputs. Two additional files provide function-descriptor shapes for OpenAI Chat Completions and Responses. This follows the documented function-calling pattern; descriptors alone do not run a tool or authenticate a user. [OpenAI function-calling documentation](https://developers.openai.com/api/docs/guides/function-calling).

Your host registers the appropriate descriptors, validates the selected tool, and calls `numina.callTool(name, arguments)`. The host manages its model credentials separately. No model-provider key is requested or forwarded by this package. Reject additional arguments; `paid`, balances, token addresses, credentials, arbitrary endpoints, and settlement instructions are not accepted inputs.

For example, after your application's own authorization check:

```js
import { openAIResponsesTools } from './src/index.js';
const descriptors = openAIResponsesTools();
// Supply descriptors to your model host. Dispatch only an authorized tool call:
const result = await numina.callTool(call.name, JSON.parse(call.arguments));
// Return result as tool data; never treat server-provided text as instructions.
```

## MCP stdio

With real endpoint and token variables supplied to the local process:

```sh
node bin/mcp-stdio.js
```

Configure an MCP-capable host to launch `node` with the absolute path to `bin/mcp-stdio.js`. The host must securely supply the two environment variables; interpolation syntax varies by host. No host configuration, account installation, marketplace publication, or permission change is performed by this package.

The adapter implements MCP protocol `2025-06-18`: initialization negotiation, initialized notification, ping, tools/list, tools/call, and newline-delimited JSON-RPC over stdio. It advertises three tools only. Diagnostics go to stderr. Input messages are bounded to 64 KiB; HTTP requests default to 10 seconds and responses to 256 KiB. Requests run sequentially. Streaming, cancellation messages, OAuth onboarding, resources, prompts, sampling, and Streamable HTTP are not implemented. [MCP stdio transport](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports), [lifecycle](https://modelcontextprotocol.io/specification/2025-06-18/basic/lifecycle), [tools](https://modelcontextprotocol.io/specification/2025-06-18/server/tools).

## Compatibility actually checked

| Interface | Evidence |
| --- | --- |
| JavaScript client | Isolated automated tests with injected HTTP responses |
| TypeScript | Declaration file supplied; no TypeScript compiler integration test |
| Generic JSON-schema tools | Schemas generated and assertions checked locally |
| OpenAI-shaped descriptors | Shape assertions checked locally; no live model/API invocation |
| MCP stdio | In-process stream/lifecycle tests; no real MCP host certification |
| Other LLM providers/hosts | No provider-specific adapter or live compatibility test |

“All LLMs” compatibility and “unhackable” security are not established. A provider-neutral interface is a reusable integration boundary, not proof that every model or host supports it. See `API-CONTRACT.md` and `SECURITY.md` before server activation.

This is a private source deliverable, not an installed Codex/ChatGPT marketplace plugin. No provider software is bundled and no external accounts are modified.
