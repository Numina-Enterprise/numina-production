const ID=/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;
const KEY=/^[A-Za-z0-9][A-Za-z0-9_-]{15,127}$/;
const FORBIDDEN=/^(authorization|api[_-]?key|access[_-]?token|secret|password|private[_-]?key)$/i;

export class NuminaError extends Error {
  constructor(code,status){super(code);this.name='NuminaError';this.code=code;if(status)this.status=status;}
}
function fail(code,status){throw new NuminaError(code,status);}
function object(value){return value!==null&&typeof value==='object'&&!Array.isArray(value);}
function exact(value,keys){if(!object(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))fail('INVALID_ARGUMENTS');}
function text(value,min,max){return typeof value==='string'&&value.length>=min&&value.length<=max&&!/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value);}
export function validateArguments(name,input){
  if(name==='numina_nusd_quote'){
    exact(input,['service_id','units','unit','idempotency_key']);
    if(!ID.test(input.service_id)||typeof input.service_id!=='string'||typeof input.units!=='string'||!/^[1-9][0-9]{0,29}$/.test(input.units)||!text(input.unit,1,64)||typeof input.idempotency_key!=='string'||!KEY.test(input.idempotency_key))fail('INVALID_ARGUMENTS');
  }else if(name==='numina_nusd_request'){
    exact(input,['quote_id','description','idempotency_key']);
    if(typeof input.quote_id!=='string'||!ID.test(input.quote_id)||!text(input.description,1,4000)||typeof input.idempotency_key!=='string'||!KEY.test(input.idempotency_key))fail('INVALID_ARGUMENTS');
  }else if(name==='numina_nusd_status'){
    exact(input,['request_id']);if(input.request_id!==null&&(typeof input.request_id!=='string'||!ID.test(input.request_id)))fail('INVALID_ARGUMENTS');
  }else fail('UNKNOWN_TOOL');
  return input;
}
function sanitize(value,token,depth=0){
  if(depth>25)fail('INVALID_SERVER_RESPONSE');
  if(typeof value==='string')return value.split(token).join('[redacted]');
  if(Array.isArray(value))return value.map(v=>sanitize(v,token,depth+1));
  if(object(value))return Object.fromEntries(Object.entries(value).filter(([k])=>!FORBIDDEN.test(k)).map(([k,v])=>[k.split(token).join('[redacted]'),sanitize(v,token,depth+1)]));
  return value;
}

export class NuminaClient {
  #origin;#token;#fetch;#timeout;#maxBytes;
  constructor({baseUrl,token,fetch:fetchImpl=globalThis.fetch,timeoutMs=10000,maxResponseBytes=262144}={}){
    let url;try{url=new URL(baseUrl);}catch{fail('INVALID_ENDPOINT');}
    if(url.protocol!=='https:'||url.username||url.password||url.pathname!=='/'||url.search||url.hash)fail('INVALID_ENDPOINT');
    if(typeof token!=='string'||token.length<16||token.length>4096||/[^\x21-\x7e]/.test(token))fail('SERVER_AUTH_REQUIRED');
    if(typeof fetchImpl!=='function'||!Number.isInteger(timeoutMs)||timeoutMs<1||timeoutMs>60000||!Number.isInteger(maxResponseBytes)||maxResponseBytes<256||maxResponseBytes>1048576)fail('INVALID_CONFIGURATION');
    this.#origin=url.origin;this.#token=token;this.#fetch=fetchImpl;this.#timeout=timeoutMs;this.#maxBytes=maxResponseBytes;
  }
  async #send(path,body){
    const controller=new AbortController();let timer,reader;
    const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(new NuminaError('REQUEST_TIMEOUT'));},this.#timeout);});
    try{
      const headers={Accept:'application/json',Authorization:'Bearer '+this.#token};
      if(body){headers['Content-Type']='application/json';headers['Idempotency-Key']=body.idempotency_key;}
      const response=await Promise.race([this.#fetch(this.#origin+'/api/nusd/v1'+path,{method:body?'POST':'GET',headers,body:body?JSON.stringify(body):undefined,signal:controller.signal,redirect:'error',credentials:'omit',cache:'no-store'}),timeout]);
      if(response.redirected||response.status>=300&&response.status<400)fail('REDIRECT_REFUSED');
      if(!response.ok)fail(response.status===401||response.status===403?'SERVER_AUTH_REJECTED':'SERVER_REQUEST_REJECTED',response.status);
      if((response.headers.get('content-type')||'').split(';')[0].trim()!=='application/json')fail('INVALID_SERVER_RESPONSE');
      if(Number(response.headers.get('content-length'))>this.#maxBytes)fail('RESPONSE_TOO_LARGE');
      reader=response.body?.getReader();if(!reader)fail('INVALID_SERVER_RESPONSE');
      const chunks=[];let size=0;
      for(;;){const {done,value}=await Promise.race([reader.read(),timeout]);if(done)break;size+=value.byteLength;if(size>this.#maxBytes)fail('RESPONSE_TOO_LARGE');chunks.push(value);}
      const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
      let data;try{data=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{fail('INVALID_SERVER_RESPONSE');}
      if(!object(data))fail('INVALID_SERVER_RESPONSE');
      // Server output is data, never instructions or independent reserve evidence.
      return sanitize(data,this.#token);
    }catch(error){if(error instanceof NuminaError)throw error;fail(controller.signal.aborted?'REQUEST_TIMEOUT':'CONNECTION_FAILED');}
    finally{clearTimeout(timer);controller.abort();if(reader)void reader.cancel().catch(()=>{});}
  }
  #wrap(data){return {source:'configured_numina_server',verification:'server_reported_not_independently_verified',client_capabilities:['quote','request','status'],asset_execution_available:false,data};}
  async status(input={request_id:null}){
    validateArguments('numina_nusd_status',input);
    const data=await this.#send(input.request_id===null?'/status':'/requests/'+encodeURIComponent(input.request_id));
    if(data.schema!==(input.request_id===null?'numina.nusd.status.v1':'numina.nusd.request.v1'))fail('INVALID_SERVER_RESPONSE');
    if(input.request_id!==null&&data.request_id!==input.request_id)fail('REQUEST_ID_MISMATCH');
    return this.#wrap(data);
  }
  async #available(capability){
    const {data}=await this.status();
    if(data.asset?.symbol!=='NUSD'||!text(data.asset.asset_id,1,256)||data.asset_verification?.status!=='verified'||!Array.isArray(data.asset_verification.evidence)||!data.asset_verification.evidence.length)fail('NUSD_NOT_VERIFIED');
    if(data.capabilities?.[capability]!==true)fail('CAPABILITY_UNAVAILABLE');
    return data.asset.asset_id;
  }
  async quote(input){
    input=structuredClone(validateArguments('numina_nusd_quote',input));const assetId=await this.#available('quote');
    const data=await this.#send('/quotes',input);
    if(data.schema!=='numina.nusd.quote.v1'||typeof data.quote_id!=='string'||!ID.test(data.quote_id)||data.asset_id!==assetId||data.symbol!=='NUSD'||typeof data.amount_base_units!=='string'||!/^[1-9][0-9]{0,59}$/.test(data.amount_base_units)||!Number.isInteger(data.decimals)||data.decimals<0||data.decimals>30||!Number.isSafeInteger(data.expires_at)||data.expires_at<=Math.floor(Date.now()/1000))fail('INVALID_SERVER_QUOTE');
    return this.#wrap(data);
  }
  async request(input){
    input=structuredClone(validateArguments('numina_nusd_request',input));const assetId=await this.#available('request');
    const data=await this.#send('/requests',input);
    if(data.schema!=='numina.nusd.request.v1'||typeof data.request_id!=='string'||!ID.test(data.request_id)||data.quote_id!==input.quote_id||data.asset_id!==assetId)fail('INVALID_SERVER_RESPONSE');
    return this.#wrap(data);
  }
  async callTool(name,input){
    validateArguments(name,input);
    if(name==='numina_nusd_quote')return this.quote(input);
    if(name==='numina_nusd_request')return this.request(input);
    return this.status(input);
  }
}
