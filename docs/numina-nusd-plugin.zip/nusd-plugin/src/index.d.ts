export interface ClientOptions {
  baseUrl: string;
  token?: string;
  expectedAssetId?: string;
  fetch?: typeof globalThis.fetch;
  timeoutMs?: number;
  maxResponseBytes?: number;
}
export interface QuoteInput {service_id:string;units:string;unit:string;idempotency_key:string}
export interface RequestInput {quote_id:string;description:string;idempotency_key:string}
export interface StatusInput {request_id:string|null}
export interface ServerResult {
  source:'configured_numina_server';
  verification:'server_reported_not_independently_verified';
  client_capabilities:Array<'quote'|'request'|'status'>;
  asset_execution_available:false;
  data:Record<string,unknown>;
}
export class NuminaError extends Error {code:string;status?:number;constructor(code:string,status?:number)}
export class NuminaClient {
  constructor(options:ClientOptions);
  status(input?:StatusInput):Promise<ServerResult>;
  quote(input:QuoteInput):Promise<ServerResult>;
  request(input:RequestInput):Promise<ServerResult>;
  callTool(name:'numina_nusd_quote',input:QuoteInput):Promise<ServerResult>;
  callTool(name:'numina_nusd_request',input:RequestInput):Promise<ServerResult>;
  callTool(name:'numina_nusd_status',input:StatusInput):Promise<ServerResult>;
}
export function validateArguments(name:string,input:unknown):unknown;
export const NUMINA_TOOLS:Array<{name:string;description:string;inputSchema:Record<string,unknown>;annotations:Record<string,boolean>}>;
export function openAIChatTools():Array<Record<string,unknown>>;
export function openAIResponsesTools():Array<Record<string,unknown>>;
