# Security boundary

The client is a restricted integration boundary, not an asset executor or a security guarantee.

- Only an operator configures the HTTPS origin, canonical NUSD asset pin and server-issued Bearer token. Public discovery sends no token; all private calls require authentication. Quote/request compare live discovery with the configured asset pin before posting. Model arguments cannot select URLs, headers, tokens, chains or contracts. Redirects are refused, cookies are omitted, and provider API keys are not used.
- Keep this package on a trusted host. Never bundle its Numina credential into a browser/mobile frontend or share it with a model. A process or administrator with access to the host can access its environment and memory. The package does not solve host compromise.
- Use scoped, expiring, revocable tokens issued by the actual Numina service. This package supplies no onboarding, key generation, account identity verification or token issuance. Do not reuse a privileged control-plane owner credential unless the server explicitly implements and authorizes the intended scope.
- Treat a model's tool invocation as a proposal subject to the host's user authorization and service policy. A quote or request is not permission to pay, transfer, mint, approve evidence, or unlock a result.
- Inputs allow only declared fields. The server still must authenticate, authorize, validate catalog units, and bind every record to the caller. Client validation cannot protect a server from direct calls.
- Tool results carry a server-reported label. Do not execute commands embedded in response text, follow returned links automatically, or interpret a valid signature as independent reserve verification.
- Requests have bounded duration and response size. Errors omit response bodies and underlying transport diagnostics; known credential fields and occurrences of the configured token are redacted from response data. This is defense in depth, not a complete data-loss-prevention system.
- The client uses no automatic retries. The host must persist idempotency keys and identical payloads for uncertain retries. Disconnecting or timing out does not cancel a server-side mutation.
- Financial functionality cannot be enabled through a client flag: no minting, transfer, settlement, paid-claim or unlock method exists. Real NUSD verification and any future payment adapter require separate server implementation and evidence. Treasury backing and redemption are not provided by this package.

Local tests cover restricted routing, auth headers, schema validation, activation gating, response identity, redaction, size/time limits, and MCP framing. They do not constitute a penetration test, smart-contract audit, reserve audit, provider certification, or production security review.
