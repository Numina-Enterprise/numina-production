# Proposed Numina NUSD API contract

This contract describes the integration target, not evidence of deployed mutation endpoints. All private operations require a server-issued, scoped Bearer token. Public discovery status sends no credentials. A request-specific status call remains authenticated. The initial Site exposes non-sensitive discovery while private capabilities stay disabled.

| Method/path | Input | Purpose |
| --- | --- | --- |
| GET `/api/nusd/v1/status` | None | Identity, backing evidence, capability discovery |
| POST `/api/nusd/v1/quotes` | `service_id`, `units`, `unit`, `idempotency_key` | Server-priced, expiring NUSD quote |
| POST `/api/nusd/v1/requests` | `quote_id`, `description`, `idempotency_key` | Create an authenticated workflow request only |
| GET `/api/nusd/v1/requests/:request_id` | Server-issued ID | Return only the caller's authorized request |

There are no mint, transfer, settlement, payment-claim, or result-unlock routes in this client. All JSON tool inputs reject extra fields. POSTs also carry `Idempotency-Key` matching the body. `units` is a positive integer string; its meaning and allowed maximum belong to the service definition. Neither tool may submit a price, paid flag, reserve balance, or arbitrary destination.

## Initial discovery response

The following is a proposed **unactivated state**, not a production observation or an asset balance:

```json
{
  "schema": "numina.nusd.status.v1",
  "asset": {"symbol": "NUSD", "asset_id": null},
  "asset_verification": {"status": "unconfigured", "evidence": []},
  "treasury_backing": {"status": "unverified", "intended_source": "Numina Treasury", "evidence": []},
  "peg": {"currency": "USD", "target": "1", "basis": "declared_policy", "status": "target_not_verified", "verified_redemption": false},
  "capabilities": {"quote": false, "request": false, "status": true, "settlement": false}
}
```

The response schema must be `numina.nusd.status.v1`. The client rejects `numina.nusd.discovery.v1` with `INVALID_SERVER_RESPONSE`; the endpoint path does not imply acceptance of a differently named schema. Use JSON errors and non-success HTTP status codes. Initially, private mutations should return HTTP 503 with `{"error":"NUSD_NOT_ACTIVATED"}`. Unsupported payment/execution endpoints must remain absent or denied. No configured secret or declared peg alone should enable settlement.

## Activation requirements and response fields

Before enabling quote/request, the server must establish canonical `asset_id`, issuer and asset mechanism, units/decimals, supported service catalog, eligible customers, and evidence supporting any claims. A symbol alone is not an asset identity. For an on-chain asset, publish the verified chain and contract information; for another mechanism, identify its actual ledger and legal/operational terms. Treasury backing must have its own verification state, coverage, methodology, observation date, and evidence references. Do not infer backing from a software ledger, a signed assertion, intended collateral, or the name NUSD. The declared policy targets 1 NUSD = 1 USD, but `status:"target_not_verified"` and `verified_redemption:false` explicitly leave peg achievement and redemption unverified. Preserve those qualifications; the target is not a verified conversion rate, redeemable balance, or instruction to substitute USDC.

For quote/request, the client requires a real token and an operator-configured canonical asset pin, then checks status `asset.symbol === "NUSD"`, matching `asset.asset_id`, `asset_verification.status === "verified"`, nonempty evidence, and the requested capability enabled. A server identity differing from the pin is rejected before POST. These are **server-reported assertions**, not independent proof. Treasury backing is distinct and must not be labeled verified by the client simply because the token identity is verified. This package never enables settlement, including when a future server advertises it.

Successful quote responses use `schema:"numina.nusd.quote.v1"`, server-generated `quote_id`, matching `asset_id`, `symbol:"NUSD"`, positive integer-string `amount_base_units`, integer `decimals` (0–30), and future Unix-seconds `expires_at`. Amounts are NUSD units without assumed exchange rates.

Successful create/status responses use `schema:"numina.nusd.request.v1"`, `request_id`, `quote_id`, `asset_id`, and a server-derived workflow status. Status may include independently sourced evidence references and timestamps with provenance labels; it must not copy a caller-paid claim into a confirmed field.

Server controls remain authoritative: bind quotes and requests to the authenticated principal; atomically validate quote ownership/expiry, current asset state and service availability; scope idempotency to principal plus operation; return the original result for exact retries and HTTP 409 for changed payloads. Recheck permissions and current payment/entitlement evidence for any future paid result delivery. Never use workflow submission as proof of payment. Apply quotas, retention, audit logging, credential rotation, and revocation independently of this client.
