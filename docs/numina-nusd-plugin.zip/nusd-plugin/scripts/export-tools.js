import {mkdirSync,writeFileSync} from 'node:fs';
import {NUMINA_TOOLS,openAIChatTools,openAIResponsesTools} from '../src/tools.js';
const out=new URL('../schemas/',import.meta.url);mkdirSync(out,{recursive:true});
for(const [name,data]of [['provider-neutral',NUMINA_TOOLS],['openai-chat-completions',openAIChatTools()],['openai-responses',openAIResponsesTools()]])writeFileSync(new URL(name+'.json',out),JSON.stringify(data,null,2)+'\n');
