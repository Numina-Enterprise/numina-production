# Validation record

On September 11, 2026, `node --test tests/*.test.js` completed with **26 tests passed, 0 failed, 0 skipped** in the local workspace using Node.js **v24.19.0**. The declared minimum Node.js 22 runtime was not separately tested.

Coverage includes tokenless public discovery, absence of Authorization on public calls even when configured, rejection of tokenless quote/request/private status before network access, authenticated private status, missing or mismatched canonical asset pins, and tokenless MCP discovery with denied private tools.

The declared-target regression test preserves `peg:{currency:'USD',target:'1',basis:'declared_policy',status:'target_not_verified',verified_redemption:false}` as server-reported, unverified data and confirms it cannot enable quotes or requests while NUSD is unconfigured. A separate regression test rejects the incorrect `numina.nusd.discovery.v1` schema; the agreed schema is `numina.nusd.status.v1`.

Tests used injected fake HTTP responses and local streams only. No production tokens, provider API calls, blockchain operations, customer records, purchases, token issuance, reserve checks, or asset transfers were used. The passing result verifies the tested package behavior, not live NUSD availability or deployment.

The package contains TypeScript declarations, but a TypeScript compiler test and live LLM/MCP-host integration tests have not been run. Re-run the included tests after changes.
