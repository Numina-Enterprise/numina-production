# Standalone uncapped NUSD candidate

This directory is isolated from the published application and its Git checkouts. It contains an unpublished contract candidate, an offline compiler and tests that run entirely inside an in-process Ganache chain. It includes no signer configuration, wallet-vault content, production deployment command, or provider payment code.

## Supply behavior

The token has no configurable policy cap. Amounts, balances and aggregate supply remain finite `uint256` values. The constructor accepts one explicit initial recipient and one initial amount; it mints that amount, when positive, before pausing. It does not distribute to multiple destinations or infer an initial recipient. The local tests use 1,500,000,000,000,000 NUSD (1,500,000,000,000,000,000,000 base units).

Later issuance requires an unpaused token, an issuer authorization and execution by a distinct minter role. Outstanding authorizations reserve numeric headroom so their sum plus total supply cannot exceed the `uint256` maximum. Cancellation, expiry and burn behavior is retained. The contract name, symbol, six decimals, role checks and delayed administrator transfer are retained.

The constructor ABI has eight parameters: initial supply, initial recipient, administrator, issuer, minter, pauser, administrator delay, and issuer-policy hash. The historical capped constructor had nine parameters. Its `cap()` function is absent from this candidate. Do not use historical creation data or immutable bindings with this artifact.

## Offline development

The pinned packages are OpenZeppelin Contracts 5.4.0, Solidity 0.8.37, ethers 6.15.0 and Ganache 7.9.2. The lockfile retains integrity hashes from the existing installed dependency lock. Dependencies are resolved from this package first. Alternatively, set `NUSD_DEVELOPMENT_DEPENDENCIES` to an existing development package directory that already contains these installed versions. Neither script installs dependencies or contacts a registry.

- `node scripts/compile.mjs` regenerates the candidate artifact using optimizer 200 and London EVM settings.
- `node scripts/test.mjs` runs the deterministic local tests and writes a sanitized report to `verification/local-test-report.json`.

The artifact records the compiler build, exact source SHA-256, ABI, creation bytecode, unbound runtime bytecode, Solidity immutable-reference IDs and resolved variable identities. Resolve the `issuerPolicyHash` immutable before comparing runtime bytes. The compile process does not create deployment transaction data with a recipient or amount.

The local tests check artifact reproducibility, 1500T constructor issuance and event ordering, initial pause, policy-hash runtime binding, later issuance above the historical cap, finite numeric boundaries, cancellation and expiry, replay prevention, unauthorized actions, role separation and administrator-delay behavior. These tests are not an independent security audit or evidence of reserves, external token issuance, provider acceptance or completed payments.

`reference/NuminaUSD.capped-v2.sol` preserves the prior source for comparison. Historical release archives and their receipts have not been changed.
