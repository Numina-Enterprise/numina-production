import { run } from 'node:test';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const testPath = fileURLToPath(new URL('../tests/uncapped-token.test.mjs', import.meta.url));
const artifactBytes = fs.readFileSync(new URL('../artifacts/NuminaUSD.json', import.meta.url));
const artifact = JSON.parse(artifactBytes);
const results = [];
const notes = new Set();
for await (const event of run({ files: [testPath], isolation: 'process' })) {
  if (event.type === 'test:pass' || event.type === 'test:fail') {
    results.push({ name: event.data.name.replace(testPath, 'tests/uncapped-token.test.mjs'),
      result: event.type === 'test:pass' ? 'PASS' : 'FAIL', durationMs: event.data.details?.duration_ms ?? null });
  }
  if (event.type === 'test:stderr' && /Falling back to a NodeJS implementation/.test(event.data.message || '')) {
    notes.add('Ganache used its JavaScript fallback because the optional native uWS binary was unavailable.');
  }
}
const counts = { tests: results.length, passed: results.filter(test => test.result === 'PASS').length,
  failed: results.filter(test => test.result === 'FAIL').length };
const report = {
  schema: 'numina.nusd.local-candidate-test-report.v1', observedAt: new Date().toISOString(),
  status: counts.tests === 9 && counts.failed === 0 ? 'PASS' : 'FAIL',
  scope: 'Deterministic in-process Ganache tests only; no remote chain or production wallet.',
  compiler: artifact.compiler, dependencyVersions: artifact.developmentDependencyVersions,
  sourceSha256: artifact.sourceSha256,
  artifactSha256: createHash('sha256').update(artifactBytes).digest('hex'),
  testsSha256: createHash('sha256').update(fs.readFileSync(testPath)).digest('hex'),
  counts, tests: results, notes: [...notes],
  externalExecution: { signed: false, broadcast: false, deployed: false, minted: false, deposited: false }
};
const output = new URL('../verification/local-test-report.json', import.meta.url);
fs.mkdirSync(new URL('../verification/', import.meta.url), { recursive: true });
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, ...counts, report: 'verification/local-test-report.json', notes: report.notes }));
if (report.status !== 'PASS') process.exitCode = 1;
