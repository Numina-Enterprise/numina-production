import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { requireDependency, verifyDependencies, expectedVersions } from './dependencies.mjs';

export const root = fileURLToPath(new URL('../', import.meta.url));
const sourceName = 'contracts/NuminaUSD.sol';
const compilerVersion = '0.8.37+commit.f401782d.Emscripten.clang';
const digest = bytes => createHash('sha256').update(bytes).digest('hex');

export function compileCandidate() {
  verifyDependencies();
  const solc = requireDependency('solc');
  if (solc.version() !== compilerVersion) throw new Error('Compiler build mismatch');
  const sourceBytes = fs.readFileSync(path.join(root, sourceName));
  const source = sourceBytes.toString('utf8');
  const settings = {
    optimizer: { enabled: true, runs: 200 }, evmVersion: 'london', metadata: { bytecodeHash: 'ipfs' },
    outputSelection: { '*': { '*': ['abi', 'evm.bytecode.object', 'evm.deployedBytecode.object', 'evm.deployedBytecode.immutableReferences', 'metadata'], '': ['ast'] } }
  };
  const input = { language: 'Solidity', sources: { [sourceName]: { content: source } }, settings };
  const output = JSON.parse(solc.compile(JSON.stringify(input), {
    import: name => {
      if (!name.startsWith('@openzeppelin/contracts/') || name.split('/').includes('..')) return { error: 'Unsupported import' };
      try { return { contents: fs.readFileSync(requireDependency.resolve(name), 'utf8') }; }
      catch { return { error: 'Installed dependency import missing' }; }
    }
  }));
  const errors = (output.errors || []).filter(error => error.severity === 'error');
  if (errors.length) throw new Error(errors.map(error => error.formattedMessage).join('\n'));
  const compiled = output.contracts[sourceName].NuminaUSD;
  const declarations = new Map();
  function collect(node, origin, contractName = null) {
    if (!node || typeof node !== 'object') return;
    const contract = node.nodeType === 'ContractDefinition' ? node.name : contractName;
    if (node.nodeType === 'VariableDeclaration' && node.mutability === 'immutable') {
      declarations.set(String(node.id), { astId: node.id, sourceName: origin, contractName: contract, variableName: node.name });
    }
    for (const value of Object.values(node)) {
      if (Array.isArray(value)) value.forEach(item => collect(item, origin, contract));
      else if (value && typeof value === 'object') collect(value, origin, contract);
    }
  }
  for (const [origin, data] of Object.entries(output.sources)) collect(data.ast, origin);
  const immutableReferences = compiled.evm.deployedBytecode.immutableReferences;
  const runtimeImmutables = Object.entries(immutableReferences).map(([id, references]) => {
    if (!declarations.has(id)) throw new Error(`Unidentified immutable ${id}`);
    return { ...declarations.get(id), references };
  });
  if (runtimeImmutables.length !== 1 || runtimeImmutables[0].variableName !== 'issuerPolicyHash') {
    throw new Error('Unexpected immutable bindings');
  }
  return {
    schema: 'numina.nusd.contract-candidate.v3', contractName: 'NuminaUSD', sourceName,
    status: 'standalone_unpublished_not_deployed',
    supplyPolicy: { kind: 'uncapped', configurableCap: false, numericRepresentation: 'uint256', decimals: 6 },
    compiler: compilerVersion, compilerSettings: settings, sourceSha256: digest(sourceBytes),
    abi: compiled.abi, bytecode: '0x' + compiled.evm.bytecode.object,
    deployedBytecode: '0x' + compiled.evm.deployedBytecode.object,
    deployedBytecodeNote: 'Unbound runtime template: resolve issuerPolicyHash at the listed immutable offsets before comparing on-chain code.',
    immutableReferences, runtimeImmutables, metadata: JSON.parse(compiled.metadata),
    dependencies: { '@openzeppelin/contracts': expectedVersions['@openzeppelin/contracts'] },
    developmentDependencyVersions: expectedVersions,
    warning: 'Unpublished, unaudited candidate. Compilation and local tests do not deploy, mint externally, prove reserves or authorize a bank/provider deposit.'
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const artifact = compileCandidate();
  const bytes = JSON.stringify(artifact, null, 2) + '\n';
  fs.mkdirSync(path.join(root, 'artifacts'), { recursive: true });
  fs.writeFileSync(path.join(root, 'artifacts/NuminaUSD.json'), bytes);
  console.log(JSON.stringify({ status: artifact.status, sourceSha256: artifact.sourceSha256,
    artifactSha256: digest(bytes), constructorInputs: artifact.abi.find(item => item.type === 'constructor').inputs,
    runtimeImmutables: artifact.runtimeImmutables, signed: false, broadcast: false }));
}
