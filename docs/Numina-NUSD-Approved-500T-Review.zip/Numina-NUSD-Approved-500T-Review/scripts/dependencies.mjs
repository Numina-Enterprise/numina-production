import { createRequire } from 'node:module';
import path from 'node:path';
import fs from 'node:fs';

// Reuse installed local dependencies; this module does not install or contact a registry.
const localRequire = createRequire(new URL('../package.json', import.meta.url));
let selectedRequire;
try {
  for (const name of ['solc', 'ethers', 'ganache', '@openzeppelin/contracts/package.json']) localRequire.resolve(name);
  selectedRequire = localRequire;
} catch {
  const external = process.env.NUSD_DEVELOPMENT_DEPENDENCIES;
  if (!external) throw new Error('Install the pinned candidate development dependencies or set NUSD_DEVELOPMENT_DEPENDENCIES to an existing development package directory.');
  selectedRequire = createRequire(path.resolve(external, 'package.json'));
}
export const requireDependency = selectedRequire;
export const expectedVersions = Object.freeze({
  '@openzeppelin/contracts': '5.4.0', solc: '0.8.37', ethers: '6.15.0', ganache: '7.9.2'
});
export function dependencyPackage(name) {
  if (name === 'ethers') {
    return JSON.parse(fs.readFileSync(path.resolve(path.dirname(requireDependency.resolve('ethers')), '../package.json'), 'utf8'));
  }
  return requireDependency(`${name}/package.json`);
}
export function verifyDependencies() {
  for (const [name, version] of Object.entries(expectedVersions)) {
    const actual = dependencyPackage(name).version;
    if (actual !== version) throw new Error(`${name} version mismatch: expected ${version}, found ${actual}`);
  }
}
