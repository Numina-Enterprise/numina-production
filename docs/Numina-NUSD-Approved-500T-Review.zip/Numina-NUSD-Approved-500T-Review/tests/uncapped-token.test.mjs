import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { compileCandidate } from '../scripts/compile.mjs';
import { requireDependency, verifyDependencies } from '../scripts/dependencies.mjs';

verifyDependencies();
const ganache = requireDependency('ganache');
const { BrowserProvider, ContractFactory, ZeroAddress, ZeroHash, id } = requireDependency('ethers');
const artifact = JSON.parse(fs.readFileSync(new URL('../artifacts/NuminaUSD.json', import.meta.url)));
const MAX = (1n << 256n) - 1n;
const INITIAL = 1_500_000_000_000_000n * 1_000_000n;
const tx = async promise => (await promise).wait();

async function fixture(t, { supply = 0n, delay = 0 } = {}) {
  // This provider is in-process only. No HTTP/WebSocket listener or remote chain is used.
  const engine = ganache.provider({ logging: { quiet: true },
    chain: { chainId: 31337, hardfork: 'london', time: new Date('2026-01-01T00:00:00Z') },
    miner: { timestampIncrement: 1 }, wallet: { deterministic: true, totalAccounts: 8 } });
  t.after(() => engine.disconnect());
  const provider = new BrowserProvider(engine, undefined, { cacheTimeout: -1 });
  provider.pollingInterval = 10;
  const signers = await Promise.all(Array.from({ length: 8 }, (_, index) => provider.getSigner(index)));
  const addresses = await Promise.all(signers.map(signer => signer.getAddress()));
  const [admin, issuer, minter, pauser, treasury, recipient, outsider] = signers;
  const args = [supply, addresses[4], ...addresses.slice(0, 4), delay, id('LOCAL TEST ISSUER POLICY')];
  const factory = new ContractFactory(artifact.abi, artifact.bytecode, admin);
  const coin = await factory.deploy(...args);
  await coin.waitForDeployment();
  const receipt = await coin.deploymentTransaction().wait();
  const now = async () => (await provider.getBlock('latest')).timestamp;
  const approve = async (label, amount, life = 3600) => {
    await tx(coin.connect(issuer).authorizeIssuance(id(label), addresses[4], amount, (await now()) + life));
  };
  const mint = async (label, amount) => {
    await approve(label, amount);
    await tx(coin.connect(minter).mintAuthorized(id(label)));
  };
  const reject = (promise, expected) => assert.rejects(promise, error => {
    const data = typeof error.data === 'string' ? error.data : error.info?.error?.data?.result;
    return data && coin.interface.parseError(data)?.name === expected;
  });
  return { engine, provider, signers, addresses, admin, issuer, minter, pauser, treasury, recipient, outsider,
    coin, factory, args, receipt, now, approve, mint, reject };
}

test('artifact reproduces exactly, has eight constructor inputs and no configurable cap ABI', () => {
  assert.deepEqual(compileCandidate(), artifact);
  assert.equal(artifact.schema, 'numina.nusd.contract-candidate.v3');
  const constructor = artifact.abi.find(entry => entry.type === 'constructor');
  assert.deepEqual(constructor.inputs.map(entry => [entry.name, entry.type]), [
    ['initialSupplyBaseUnits', 'uint256'], ['initialRecipient', 'address'], ['admin', 'address'],
    ['issuer', 'address'], ['minter', 'address'], ['pauser', 'address'],
    ['adminDelaySeconds', 'uint48'], ['approvedIssuerPolicyHash', 'bytes32']
  ]);
  assert.equal(artifact.abi.some(entry => entry.name === 'cap'), false);
  assert.equal(artifact.abi.some(entry => entry.name === 'SupplyReservationExceedsCap'), false);
  assert.equal(artifact.runtimeImmutables.length, 1);
  assert.equal(artifact.runtimeImmutables[0].variableName, 'issuerPolicyHash');
  assert.ok(Number.isSafeInteger(artifact.runtimeImmutables[0].astId));
  assert.ok((artifact.deployedBytecode.length - 2) / 2 < 24576);
  assert.equal(createHash('sha256').update(fs.readFileSync(new URL('../contracts/NuminaUSD.sol', import.meta.url))).digest('hex'), artifact.sourceSha256);
});

test('exact 500T constructor issuance and 1500T regression each mint once to one recipient before pausing', async t => {
  // The current owner review uses one 500T amount. The larger historical value
  // remains a regression case; neither local case allocates provider balances.
  const cases = [
    { label: 'current 500T', supply: 500_000_000_000_000n * 1_000_000n },
    { label: '1500T regression', supply: INITIAL }
  ];
  for (const { label, supply } of cases) {
    const f = await fixture(t, { supply, delay: 86400 });
    assert.equal(await f.coin.name(), 'Numina USD', label);
    assert.equal(await f.coin.symbol(), 'NUSD', label);
    assert.equal(await f.coin.decimals(), 6n, label);
    assert.equal(await f.coin.totalSupply(), supply, label);
    assert.equal(await f.coin.balanceOf(f.addresses[4]), supply, label);
    const accountBalances = await Promise.all(f.addresses.map(address => f.coin.balanceOf(address)));
    assert.deepEqual(accountBalances, f.addresses.map((_, index) => index === 4 ? supply : 0n), label);
    assert.equal(accountBalances.reduce((sum, balance) => sum + balance, 0n), supply, label);
    assert.equal(await f.coin.balanceOf(await f.coin.getAddress()), 0n, label);
    assert.equal(await f.coin.authorizedSupply(), 0n, label);
    assert.equal(await f.coin.paused(), true, label);
    assert.equal(await f.coin.defaultAdminDelay(), 86400n, label);
    const events = f.receipt.logs.map(log => f.coin.interface.parseLog(log));
    const mintEvents = events.filter(event => event.name === 'Transfer');
    assert.equal(mintEvents.length, 1, label);
    assert.deepEqual([...mintEvents[0].args], [ZeroAddress, f.addresses[4], supply], label);
    assert.equal(events.filter(event => event.name === 'Paused').length, 1, label);
    assert.ok(events.findIndex(event => event.name === 'Transfer') < events.findIndex(event => event.name === 'Paused'), label);
    await f.reject(f.coin.connect(f.treasury).transfer.staticCall(f.addresses[5], 1n), 'EnforcedPause');
    const runtime = Buffer.from(artifact.deployedBytecode.slice(2), 'hex');
    for (const reference of artifact.runtimeImmutables[0].references) {
      assert.equal(reference.length, 32, label);
      assert.ok(runtime.subarray(reference.start, reference.start + 32).every(byte => byte === 0), label);
      Buffer.from(id('LOCAL TEST ISSUER POLICY').slice(2), 'hex').copy(runtime, reference.start);
    }
    assert.equal(await f.provider.getCode(await f.coin.getAddress()), '0x' + runtime.toString('hex'), label);
  }
});

test('distinct issuer and minter can issue beyond the former cap after admin unpause, once only', async t => {
  const f = await fixture(t, { supply: INITIAL });
  await f.reject(f.coin.connect(f.issuer).unpause.staticCall(), 'AccessControlUnauthorizedAccount');
  await tx(f.coin.unpause());
  await f.approve('additional-1500T', INITIAL);
  await f.reject(f.coin.connect(f.issuer).mintAuthorized.staticCall(id('additional-1500T')), 'AccessControlUnauthorizedAccount');
  await tx(f.coin.connect(f.minter).mintAuthorized(id('additional-1500T')));
  assert.equal(await f.coin.totalSupply(), 2n * INITIAL);
  assert.equal(await f.coin.balanceOf(f.addresses[4]), 2n * INITIAL);
  assert.equal(await f.coin.authorizedSupply(), 0n);
  await f.reject(f.coin.connect(f.minter).mintAuthorized.staticCall(id('additional-1500T')), 'IssuanceNotAuthorized');
  await f.reject(f.coin.connect(f.issuer).authorizeIssuance.staticCall(id('additional-1500T'), f.addresses[4], 1n, (await f.now()) + 3600), 'IssuanceReferenceAlreadyUsed');
});

test('uint256 headroom reserves concurrent issuance exactly and burns release numeric capacity', async t => {
  const f = await fixture(t, { supply: MAX - 10n });
  await tx(f.coin.unpause());
  await f.approve('seven', 7n);
  await f.reject(f.coin.connect(f.issuer).authorizeIssuance.staticCall(id('four'), f.addresses[4], 4n, (await f.now()) + 3600), 'SupplyReservationExceedsUint256');
  assert.equal(await f.coin.authorizedSupply(), 7n);
  assert.equal((await f.coin.issuances(id('four'))).status, 0n);
  await f.approve('three', 3n);
  await tx(f.coin.connect(f.minter).mintAuthorized(id('three')));
  await tx(f.coin.connect(f.minter).mintAuthorized(id('seven')));
  assert.equal(await f.coin.totalSupply(), MAX);
  assert.equal(await f.coin.authorizedSupply(), 0n);
  await f.reject(f.coin.connect(f.issuer).authorizeIssuance.staticCall(id('one-more'), f.addresses[4], 1n, (await f.now()) + 3600), 'SupplyReservationExceedsUint256');
  await tx(f.coin.connect(f.treasury).burn(5n));
  await f.mint('after-burn', 5n);
  assert.equal(await f.coin.totalSupply(), MAX);
});

test('cancel and expiry release reserved headroom during pause without reusing issuance IDs', async t => {
  const f = await fixture(t, { supply: MAX - 12n });
  await tx(f.coin.unpause());
  await f.approve('cancel', 7n);
  await f.approve('expire', 5n, 100);
  await tx(f.coin.connect(f.pauser).pause());
  await f.reject(f.coin.connect(f.outsider).cancelIssuance.staticCall(id('cancel')), 'NotAuthorizedToCancel');
  await tx(f.coin.connect(f.pauser).cancelIssuance(id('cancel')));
  assert.equal(await f.coin.authorizedSupply(), 5n);
  await f.reject(f.coin.connect(f.outsider).expireIssuance.staticCall(id('expire')), 'IssuanceNotExpired');
  await f.engine.request({ method: 'evm_increaseTime', params: [101] });
  await f.engine.request({ method: 'evm_mine', params: [] });
  await tx(f.coin.connect(f.outsider).expireIssuance(id('expire')));
  assert.equal(await f.coin.authorizedSupply(), 0n);
  assert.equal(await f.coin.totalSupply(), MAX - 12n);
  await tx(f.coin.unpause());
  for (const reference of ['cancel', 'expire']) {
    await f.reject(f.coin.connect(f.minter).mintAuthorized.staticCall(id(reference)), 'IssuanceNotAuthorized');
    await f.reject(f.coin.connect(f.issuer).authorizeIssuance.staticCall(id(reference), f.addresses[4], 1n, (await f.now()) + 3600), 'IssuanceReferenceAlreadyUsed');
  }
  await f.mint('released-capacity', 12n);
  assert.equal(await f.coin.totalSupply(), MAX);
});

test('pause contains issuance, transfers and burns while only admin can resume', async t => {
  const f = await fixture(t, { supply: 1000n });
  await tx(f.coin.unpause());
  await f.approve('pending', 1n);
  await tx(f.coin.connect(f.treasury).approve(f.addresses[5], 10n));
  await tx(f.coin.connect(f.pauser).pause());
  const expires = (await f.now()) + 3600;
  for (const operation of [
    () => f.coin.connect(f.issuer).authorizeIssuance.staticCall(id('paused'), f.addresses[4], 1n, expires),
    () => f.coin.connect(f.minter).mintAuthorized.staticCall(id('pending')),
    () => f.coin.connect(f.treasury).transfer.staticCall(f.addresses[5], 1n),
    () => f.coin.connect(f.recipient).transferFrom.staticCall(f.addresses[4], f.addresses[5], 1n),
    () => f.coin.connect(f.treasury).burn.staticCall(1n),
    () => f.coin.connect(f.recipient).burnFrom.staticCall(f.addresses[4], 1n)
  ]) await f.reject(operation(), 'EnforcedPause');
  for (const signer of f.signers.slice(1)) {
    await f.reject(f.coin.connect(signer).unpause.staticCall(), 'AccessControlUnauthorizedAccount');
  }
  assert.equal(await f.coin.totalSupply(), 1000n);
  assert.equal(await f.coin.authorizedSupply(), 1n);
  assert.equal(await f.coin.allowance(f.addresses[4], f.addresses[5]), 10n);
  await tx(f.coin.unpause());
  await tx(f.coin.connect(f.minter).mintAuthorized(id('pending')));
  assert.equal(await f.coin.totalSupply(), 1001n);
});

test('configuration rejects zero identities, role overlap and unsupported role grants', async t => {
  const f = await fixture(t);
  for (const index of [1, 2, 3, 4, 5]) {
    const args = [...f.args]; args[index] = ZeroAddress;
    await assert.rejects(f.factory.deploy(...args));
  }
  for (const [first, second] of [[2, 3], [2, 4], [2, 5], [3, 4], [3, 5], [4, 5]]) {
    const args = [...f.args]; args[second] = args[first];
    await assert.rejects(f.factory.deploy(...args));
  }
  const noPolicy = [...f.args]; noPolicy[7] = ZeroHash;
  await assert.rejects(f.factory.deploy(...noPolicy));
  await f.reject(f.coin.grantRole.staticCall(await f.coin.MINTER_ROLE(), f.addresses[1]), 'PrivilegedRoleConflict');
  await f.reject(f.coin.grantRole.staticCall(id('UNSUPPORTED_ROLE'), f.addresses[6]), 'UnsupportedRole');
  await f.reject(f.coin.connect(f.outsider).grantRole.staticCall(await f.coin.MINTER_ROLE(), f.addresses[7]), 'AccessControlUnauthorizedAccount');
});

test('authorization validates recipient, amount, reference and bounded lifetime; expired mint stays reserved until cleanup', async t => {
  const f = await fixture(t); await tx(f.coin.unpause());
  const now = await f.now();
  for (const args of [
    [ZeroHash, f.addresses[4], 1n, now + 3600], [id('zero-address'), ZeroAddress, 1n, now + 3600],
    [id('zero-amount'), f.addresses[4], 0n, now + 3600], [id('past'), f.addresses[4], 1n, now],
    [id('far'), f.addresses[4], 1n, now + 7 * 86400 + 100]
  ]) await f.reject(f.coin.connect(f.issuer).authorizeIssuance.staticCall(...args), 'InvalidIssuance');
  await f.reject(f.coin.connect(f.outsider).authorizeIssuance.staticCall(id('not-issuer'), f.addresses[4], 1n, now + 3600), 'AccessControlUnauthorizedAccount');
  await f.approve('expires', 2n, 100);
  await f.engine.request({ method: 'evm_increaseTime', params: [101] });
  await f.engine.request({ method: 'evm_mine', params: [] });
  await f.reject(f.coin.connect(f.minter).mintAuthorized.staticCall(id('expires')), 'IssuanceExpired');
  assert.equal(await f.coin.authorizedSupply(), 2n);
  assert.equal(await f.coin.totalSupply(), 0n);
  await tx(f.coin.connect(f.outsider).expireIssuance(id('expires')));
  assert.equal(await f.coin.authorizedSupply(), 0n);
});

test('delayed administrator rotation preserves distinct roles and removes prior admin authority', async t => {
  const f = await fixture(t, { delay: 86400 });
  await tx(f.coin.beginDefaultAdminTransfer(f.addresses[6]));
  await f.reject(f.coin.connect(f.outsider).acceptDefaultAdminTransfer.staticCall(), 'AccessControlEnforcedDefaultAdminDelay');
  await f.engine.request({ method: 'evm_increaseTime', params: [86401] });
  await f.engine.request({ method: 'evm_mine', params: [] });
  await tx(f.coin.connect(f.outsider).acceptDefaultAdminTransfer());
  assert.equal(await f.coin.defaultAdmin(), f.addresses[6]);
  await f.reject(f.coin.unpause.staticCall(), 'AccessControlUnauthorizedAccount');
  await tx(f.coin.connect(f.outsider).unpause());
  assert.equal(await f.coin.paused(), false);
});
