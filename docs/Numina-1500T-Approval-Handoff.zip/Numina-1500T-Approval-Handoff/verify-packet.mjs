import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const root=path.dirname(fileURLToPath(import.meta.url));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const load=p=>JSON.parse(fs.readFileSync(path.join(root,p),'utf8'));
const manifest=load('packet-manifest.json');
const checks=[];
function check(label,fn){fn();checks.push(label);}
check('Inventory paths and exact file bytes',()=>{
 const seen=new Set();
 for(const f of manifest.files){
  assert(!path.isAbsolute(f.path)&&!f.path.split(/[\\/]/).includes('..'));
  assert(!seen.has(f.path));seen.add(f.path);
  const b=fs.readFileSync(path.join(root,f.path));assert.equal(b.length,f.bytes);assert.equal(sha(b),f.sha256);
 }
});
const policy=load('candidate/issuance-preparation-policy.json');
const request=load('candidate/NuminaUSD.constructor-review.json');
const artifact=load('candidate/NuminaUSD.json');
const encoded=load('candidate/Numina-1500T-Unsigned-Constructor-Review.json');
const pins=manifest.candidateBinding;
const candidateFiles={policySha256:'issuance-preparation-policy.json',requestSha256:'NuminaUSD.constructor-review.json',artifactSha256:'NuminaUSD.json',sourceSha256:'NuminaUSD.sol',encodedReviewSha256:'Numina-1500T-Unsigned-Constructor-Review.json'};
check('Five exact candidate hashes',()=>{for(const [key,f] of Object.entries(candidateFiles))assert.equal(sha(fs.readFileSync(path.join(root,'candidate',f))),pins[key]);});
check('Policy, source, artifact and request binding',()=>{
 assert.equal(request.preparationPolicy.sha256,pins.policySha256);
 assert.equal(request.artifact.sha256,pins.artifactSha256);
 assert.equal(request.source.sha256,pins.sourceSha256);
 assert.equal(artifact.sourceSha256,pins.sourceSha256);
 for(const [a,b] of [['requestSha256','requestSha256'],['artifactSha256','artifactSha256'],['sourceSha256','sourceSha256'],['issuerPolicySha256','policySha256']])assert.equal(encoded[a],pins[b]);
});
const abi=artifact.abi.find(v=>v.type==='constructor');
check('Exact eight-argument v3 constructor ABI',()=>{
 assert.equal(abi.inputs.length,8);assert.equal(request.constructor.length,8);
 for(let i=0;i<8;i++){assert.equal(abi.inputs[i].name,request.constructor[i].name);assert.equal(abi.inputs[i].type,request.constructor[i].type);}
});
check('Eight constructor words decoded against request',()=>{
 assert.match(encoded.constructorArguments,/^0x[0-9a-fA-F]{512}$/);
 for(let i=0;i<8;i++){
  const field=request.constructor[i],word=encoded.constructorArguments.slice(2+i*64,2+(i+1)*64);
  if(field.type==='address'){assert.equal(word.slice(0,24),'0'.repeat(24));assert.equal('0x'+word.slice(24),field.value.toLowerCase());}
  else if(field.type==='bytes32')assert.equal('0x'+word,field.value.toLowerCase());
  else assert.equal(BigInt('0x'+word).toString(),field.value);
  assert.equal(String(encoded.constructor[field.name]).toLowerCase(),String(field.value).toLowerCase());
 }
 assert.equal(encoded.constructor.approvedIssuerPolicyHash,'0x'+pins.policySha256);
});
check('Creation bytes match artifact plus arguments',()=>{
 assert.equal(encoded.constructorData,artifact.bytecode+encoded.constructorArguments.slice(2));
 const data=Buffer.from(encoded.constructorData.slice(2),'hex');
 assert.equal(data.length,10746);assert.equal(data.length,pins.creationBytes);
 assert.equal(sha(data),pins.creationDataSha256);assert.equal(encoded.constructorDataSha256,pins.creationDataSha256);
});
check('1,500T total supply and selected addresses',()=>{
 assert.equal(policy.token.initialSupplyNusd,'1500000000000000');
 assert.equal(BigInt(policy.token.initialSupplyNusd)*10n**6n,BigInt(policy.token.initialSupplyBaseUnits));
 assert.equal(policy.token.initialSupplyBaseUnits,encoded.constructor.initialSupplyBaseUnits);
 assert.equal(policy.token.initialRecipient,encoded.constructor.initialRecipient);
 assert.equal(request.walletTransaction.from,encoded.constructor.initialRecipient);
 assert.equal(policy.token.supplyPolicy,'uncapped');assert.equal(policy.token.initiallyPaused,true);
});
check('Signature and execution remain absent',()=>{
 assert.equal(policy.signature,null);assert.equal(policy.approvals.policySigned,false);
 for(const k of ['signed','broadcast','minted','deposited','productionReady','reviewEvidenceVerified','fundsVerified'])assert.equal(encoded[k],false);
 assert.equal(encoded.receipt,null);assert.equal(encoded.transactionHash,null);
 assert.equal(load('gate-status.json').submissionAllowed,false);
});
check('Eight review records bind the current candidate without false approval',()=>{
 const gate=load('gate-status.json');assert.equal(gate.reviews.length,8);
 assert.equal(new Set(gate.reviews.map(r=>r.id)).size,8);
 for(const r of gate.reviews){const v=load(r.path);assert.equal(v.id,r.id);assert.deepEqual(v.candidateBinding,pins);assert.equal(v.verified,false);assert.equal(v.signature,null);assert.equal(v.conclusion,null);assert.equal(v.submittedEvidence.length,0);assert(v.requiredSupportingEvidence.length>=3);}
});
check('Recorded publication and software evidence match',()=>{
 const pub=load('evidence/Numina-Owner-Execution-Publication.json');
 assert.equal(pub.source.tree,pins.softwareTree);assert.equal(pub.source.githubCommit,pins.githubCommit);
 const tests=load('evidence/Numina-Owner-Execution-Validation.json');assert.equal(tests.tests.passed,286);assert.equal(tests.tests.failed,0);
 assert.equal(pub.verification.rootManifestChecks,6);
 const live=load('evidence/Numina-Owner-Execution-Live-Verification.json');assert.equal(live.success,true);assert.equal(live.checks.length,20);
 for(const c of live.checks.filter(c=>c.sha256&&/^\/wallet-execution-[\w-]+\.js$/.test(c.route)))assert.equal(sha(fs.readFileSync(path.join(root,'software/public',c.route.slice(1)))),c.sha256);
});
const result={schema:'numina.approval-packet.integrity.v1',verifiedAt:new Date().toISOString(),status:'INTEGRITY_PASS_APPROVAL_BLOCKED',checks,filesVerified:manifest.files.length,independentReview:false,signaturesVerified:false,fundsVerified:false,networkCalls:false,submissionPerformed:false};
console.log(JSON.stringify(result,null,2));
