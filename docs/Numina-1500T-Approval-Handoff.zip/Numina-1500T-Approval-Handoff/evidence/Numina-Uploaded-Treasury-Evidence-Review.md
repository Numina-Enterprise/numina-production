# Uploaded treasury evidence review

Reviewed September 15, 2026. The authenticated production control panel lists three supporting files. Local copies of all three match the stored SHA-256 receipts exactly. Both screenshots were visually inspected; both PDF pages were extracted and visually inspected.

| File | What the supplied file shows | Verification limit |
| --- | --- | --- |
| Screenshot 2026-09-15 162246.png | Masked bank account and routing instructions. | No balance, reserve allocation or settled transaction appears. |
| stripe numina treasury.png | Stripe Add funds instructions for USDC on Base, a masked destination and a $1 minimum. The instructions restrict the destination to USDC. | No credited balance or completed transfer appears. A deposit destination does not establish acceptance of NUSD. |
| numina-nusd-runtime-verification-review.pdf | A two-page review of retained builder-signed runtime source/image/inventory from run 34725802271. | The document explicitly says it does not establish contract deployment, reserves, custody, issuance or settlement. This task did not repeat its historical attestation verification. |

## File identity

- Screenshot receipt: `a5be4cb8b4d276126e49254d1eedfe45a5fe694732347b24687161bf53356e83`
- Stripe screenshot receipt: `dcf098da861bfd8b6a796a292a6a0ee1f720a734689d71c624da5a14f4e2b40a`
- Runtime PDF receipt: `fd87a59d643411a82f2697d598a6f2d21ac379f7e6df0d32453f26fe9f0989bb`

## Current records

At 21:51 UTC the authenticated Numina control panel showed one native projection of **500,000,000,000,000 NUSD**, revision **138**, head `863491b6526278e037880d0594464e8ffa9fcde1a33239c7fd43c5fc8bb3acdf`. The live Stripe reader reported **USD 0.00** and **USDC 0.000000** across available and pending buckets; NUSD was not reported by Stripe.

The native amount and declared 1:1 valuation remain the canonical Numina reference. They do not replace provider-origin balance observations. The uploaded files support destination context and historical software-build evidence; they do not support relabeling 500T as provider-reported reserves.

The separate financial-services register returned zero registered evidence entries on refresh. The three uploaded files remain in the private treasury supporting-document store.

## Supplied status record

The pasted `numina.nusd.status.v1` JSON reports compiled, undeployed token and settlement contracts; no contract addresses or chain receipts; unverified treasury backing; and inactive mint, transfer, settlement, redemption and exchange capabilities. It adds no provider funding confirmation. Its meaning is preserved in the reconciliation update.

No financial transfer, mint, currency conversion or provider-balance modification was performed during this review. The public source contains no private account numbers or file contents from these documents.
