# Numina 1,500T approval handoff

Prepared from existing evidence on September 16, 2026. **The handoff is complete; the approval gate remains BLOCKED.**

## Exact candidate

- Total proposed initial issuance: **1,500,000,000,000,000 NUSD**, six decimals; **1500000000000000000000 base units**.
- Recipient and proposed sender: **0x1a45671AE2ee3E52264116151924FAAcb80Fc02E**.
- Uncapped v3 contract, bounded by uint256; eight constructor arguments; initially paused. Positive initial supply mints during deployment.
- Policy SHA-256: `1d24f311a34a28d9560db1f32eb3efc4241701c5ae7233b97c2527006623b13d`.
- Request SHA-256: `0af2b7e72cd18f9676f85356da95f8deee8788eac0dee3d587a1278342a401ca`.
- Creation bytes SHA-256: `bdaf4313f68b97d504ef3796096814d41b3002bffcf9ed75b78a939de6049401` (10,746 bytes).
- Published GitHub commit: `039a38cfb8f727b1670580c5fb8820063f592ea1`; source tree: `b6f588cac0eef99d048509d2031c10910d261684`.

The candidate files are exact copies. The request snapshot predates its separate encoding review and therefore still says unencoded. The later unsigned constructor review and two checks establish constructor encoding only. No complete fresh transaction or successful deployment is supplied.

## What is finished

The packet includes the current policy/request/artifact/source, exact constructor encoding, source excerpts and tests, publication evidence, eight topic-specific review records, issuer-signature intake, execution-observation intake and separate operation-receipt records. Recorded validation comprises 286 wallet/control/runtime tests, six manifest tests and 20 live read-only checks. These records are dated observations; they were not rerun as financial execution for this packet.

## Complete the three evidence gates

1. **Issuer:** use `intake/issuer-policy-approval.json` to supply the actual final approved policy, authorized signatory evidence, signature and verification result. The bundled candidate remains unsigned. If final policy bytes change, regenerate the policy hash, request, constructor, expected runtime and all dependent review pins. Reviewers must approve the final hashes. Do not edit booleans to represent a signature.
2. **Reviewers and providers:** complete the eight records in `reviews/`, attaching actual reports with raw-file SHA-256, issuer/reviewer identity, scope, date, findings, remediation and conclusion. Existing software observations are prefilled and clearly limited. No independent reviewer or provider conclusion has been fabricated. A review report should distinguish a rejected finding, an unresolved finding and accepted remediation.
3. **Owner at execution:** after the evidence-reviewed source release, use [the owner wallet workspace](https://numinalabs.xyz/wallet-signing) to obtain fresh network and fee observations and make the final wallet decision. The snapshot's chain/genesis are expected pins, not fresh authenticated observations. Complete each actual operation's own receipt record and verify it. Conversion and deposits additionally need a supported funded route and provider acceptance.

## How to return evidence

Retain this original packet. Supply completed intake copies and the actual signed reports through the existing restricted evidence channel. For each attachment provide its relative filename or controlled link, raw-byte SHA-256, origin, date, covered request/policy/artifact hashes, and any exclusions. Never include passwords, keys or recovery phrases. Redact unnecessary customer and full account details. No evidence is automatically published or accepted by this packet.

## Integrity check

With Node installed, run `node verify-packet.mjs` from this directory. The offline checker verifies packaged file hashes, all eight constructor words and current-request consistency. It reports **INTEGRITY PASS / APPROVAL BLOCKED**. That result does not authenticate signatories, establish reserves, authorize a release or perform any network action. The ZIP's external SHA-256 record identifies this exact original handoff.

## Financial state and limits

No signature, broadcast, mint, conversion or deposit was performed while preparing this packet. Last recorded journal observation was revision 141, head `8800c49a227ca8adeeb79081dfdd09892389920abcac9bce930d271a82c0c81c`; publication did not change it. PREPARED treasury requests remain prepared. A 1:1 display declaration and a native journal projection do not establish external USD/USDC funding or provider acceptance. Historical 500T approvals are not substituted for this current 1,500T request.

See `gate-status.json` for the machine-readable handoff, `evidence/Numina-Signing-Blocker-Evidence-Review.md` for search scope and `software/docs/Numina-Wallet-Signing-Controls.md` for the implemented workflow. These records support review; production acceptance requires the actual missing evidence.
