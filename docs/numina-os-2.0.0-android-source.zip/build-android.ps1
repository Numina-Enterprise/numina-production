[CmdletBinding()]
param([switch]$BuildOnly)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$mobileRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$mobilePrefix = $mobileRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
function Resolve-MobilePath([string]$Relative) {
    $candidate = [IO.Path]::GetFullPath((Join-Path $mobileRoot $Relative))
    if (-not $candidate.StartsWith($mobilePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Path escaped the mobile workspace.' }
    return $candidate
}
function Ensure-MobileDirectory([string]$Relative) {
    $candidate = Resolve-MobilePath $Relative
    [IO.Directory]::CreateDirectory($candidate) | Out-Null
    return $candidate
}
$downloads = Ensure-MobileDirectory 'tool-downloads'
$toolRoot = Ensure-MobileDirectory 'tools'
$logs = Ensure-MobileDirectory 'logs'
$sdkRoot = Ensure-MobileDirectory 'android-sdk'
$projectRoot = Resolve-MobilePath 'android'
$toolchainPath = Resolve-MobilePath 'toolchain.json'
$downloadHelper = Resolve-MobilePath 'download-tool.mjs'

function Get-VerifiedArchive([string]$Url, [string]$ExpectedSha256, [string]$Name) {
    $uri = [Uri]$Url
    if ($uri.Scheme -ne 'https' -or $uri.UserInfo -or $uri.Fragment -or $ExpectedSha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Invalid official archive metadata.' }
    $destination = Resolve-MobilePath ('tool-downloads/' + $Name)
    Write-Host ('Downloading or checking ' + $Name)
    $downloadResult = & node $downloadHelper archive $Url $ExpectedSha256 $destination
    if ($LASTEXITCODE -ne 0) { throw ('Official archive download failed: ' + $Name + ' ' + $downloadResult) }
    return ($downloadResult | ConvertFrom-Json)
}

if (-not $BuildOnly) {
    $jdkMetadata = & node $downloadHelper jdk-metadata
    if ($LASTEXITCODE -ne 0) { throw ('Official JDK metadata download failed: ' + $jdkMetadata) }
    $jdkPackage = $jdkMetadata | ConvertFrom-Json
    if (-not $jdkPackage -or ([Uri]$jdkPackage.link).Host -ne 'github.com' -or $jdkPackage.name -notmatch '^OpenJDK17U-jdk_x64_windows_hotspot_.*\.zip$') { throw 'Unexpected Adoptium package metadata.' }
    $jdkArchive = Get-VerifiedArchive $jdkPackage.link $jdkPackage.checksum $jdkPackage.name
    $jdkExtract = Ensure-MobileDirectory 'tools/jdk17'
    if (-not (Get-ChildItem -LiteralPath $jdkExtract -Directory | Select-Object -First 1)) {
        Expand-Archive -LiteralPath $jdkArchive.path -DestinationPath $jdkExtract
    }
    $jdkDirectory = @(Get-ChildItem -LiteralPath $jdkExtract -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'bin/java.exe') })
    if ($jdkDirectory.Count -ne 1) { throw 'Expected one extracted JDK.' }
    $javaHome = $jdkDirectory[0].FullName

    $gradleMetadata = & node $downloadHelper gradle-checksum
    if ($LASTEXITCODE -ne 0) { throw ('Official Gradle checksum download failed: ' + $gradleMetadata) }
    $gradleSha = ($gradleMetadata | ConvertFrom-Json).checksum
    $gradleArchive = Get-VerifiedArchive 'https://downloads.gradle.org/distributions/gradle-8.13-bin.zip' $gradleSha 'gradle-8.13-bin.zip'
    $gradleHome = Resolve-MobilePath 'tools/gradle-8.13'
    if (-not (Test-Path -LiteralPath (Join-Path $gradleHome 'bin/gradle.bat'))) {
        Expand-Archive -LiteralPath $gradleArchive.path -DestinationPath $toolRoot
    }

    # SHA-256 published on https://developer.android.com/studio on 2026-09-12.
    $sdkArchive = Get-VerifiedArchive 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a' 'commandlinetools-win-15859902_latest.zip'
    $cliHome = Ensure-MobileDirectory 'tools/android-cli-15859902'
    $sdkManager = Join-Path $cliHome 'cmdline-tools/bin/sdkmanager.bat'
    if (-not (Test-Path -LiteralPath $sdkManager)) {
        Expand-Archive -LiteralPath $sdkArchive.path -DestinationPath $cliHome
    }
    $toolchain = [pscustomobject]@{
        preparedAtUtc = [DateTime]::UtcNow.ToString('o')
        javaHome = $javaHome
        gradleHome = $gradleHome
        sdkManager = $sdkManager
        sdkRoot = $sdkRoot
        archives = @($jdkArchive, $gradleArchive, $sdkArchive)
        installationScope = 'work/mobile-v2 only; no global installation'
    }
    $toolchain | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $toolchainPath -Encoding utf8
} else {
    $toolchain = Get-Content -LiteralPath $toolchainPath -Raw | ConvertFrom-Json
}

foreach ($candidate in @($toolchain.javaHome, $toolchain.gradleHome, $toolchain.sdkManager, $toolchain.sdkRoot)) {
    if (-not ([IO.Path]::GetFullPath($candidate)).StartsWith($mobilePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Saved toolchain path escaped mobile workspace.' }
}
$env:JAVA_HOME = $toolchain.javaHome
$env:ANDROID_HOME = $toolchain.sdkRoot
$env:ANDROID_SDK_ROOT = $toolchain.sdkRoot
$env:ANDROID_USER_HOME = Ensure-MobileDirectory 'android-user-home'
$env:GRADLE_USER_HOME = Ensure-MobileDirectory 'gradle-user-home'
$env:Path = (Join-Path $env:JAVA_HOME 'bin') + [IO.Path]::PathSeparator + $env:Path

if (-not $BuildOnly) {
    Write-Output 'Installing Android SDK platform 36 and build tools in the mobile workspace.'
    # The requested installation requires accepting Google's Android SDK license.
    # Only the explicitly listed SDK packages are installed. No device is accessed.
    $sdkLog = Resolve-MobilePath 'logs/sdk-install.log'
    1..20 | ForEach-Object { 'y' } | & $toolchain.sdkManager "--sdk_root=$sdkRoot" 'platforms;android-36' 'build-tools;35.0.0' 2>&1 | Out-File -LiteralPath $sdkLog -Encoding utf8
    if ($LASTEXITCODE -ne 0) { Get-Content -LiteralPath $sdkLog -Tail 20; throw 'Android SDK installation failed.' }
}

Write-Output 'Building unsigned Android release bundle and APK; no test tasks requested.'
$buildLog = Resolve-MobilePath 'logs/android-release-build.log'
$gradle = Join-Path $toolchain.gradleHome 'bin/gradle.bat'
& $gradle --no-daemon --console=plain -p $projectRoot ':app:bundleRelease' ':app:assembleRelease' 2>&1 | Out-File -LiteralPath $buildLog -Encoding utf8
if ($LASTEXITCODE -ne 0) { Get-Content -LiteralPath $buildLog -Tail 35; throw 'Android release build failed. See logs/android-release-build.log.' }

$artifactPaths = @('android/app/build/outputs/bundle/release/app-release.aab', 'android/app/build/outputs/apk/release/app-release-unsigned.apk')
$artifacts = foreach ($relative in $artifactPaths) {
    $candidate = Resolve-MobilePath $relative
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { throw ('Expected build artifact missing: ' + $relative) }
    [pscustomobject]@{ path = $relative; bytes = (Get-Item -LiteralPath $candidate).Length; sha256 = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant(); signed = $false }
}
$record = [pscustomobject]@{
    schema = 'numina.android-build.v1'
    completedAtUtc = [DateTime]::UtcNow.ToString('o')
    status = 'unsigned_release_artifacts_built'
    applicationVersion = '2.0.0'
    versionCode = 1
    proposedPackageId = 'xyz.numinalabs.app'
    hostedWorkspace = 'https://numinalabs.xyz/app'
    tasks = @(':app:bundleRelease', ':app:assembleRelease')
    testsRequested = $false
    deviceInstallationPerformed = $false
    signingPerformed = $false
    storeSubmissionPerformed = $false
    artifacts = @($artifacts)
}
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Resolve-MobilePath 'android-build-record.json') -Encoding utf8
$record | ConvertTo-Json -Depth 8
