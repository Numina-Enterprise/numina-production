import { createHash } from 'node:crypto';
import { createReadStream, createWriteStream } from 'node:fs';
import { access, rename, stat } from 'node:fs/promises';
import { dirname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable, Transform } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const root = dirname(fileURLToPath(import.meta.url));
const allowedHosts = new Set(['api.adoptium.net', 'github.com', 'release-assets.githubusercontent.com', 'objects.githubusercontent.com', 'downloads.gradle.org', 'services.gradle.org', 'dl.google.com']);
function allowedUrl(value) {
  const url = new URL(value);
  if (url.protocol !== 'https:' || url.username || url.password || url.hash || !allowedHosts.has(url.hostname)) throw new Error('DOWNLOAD_URL_NOT_ALLOWED');
  return url;
}
async function readResponse(value, signal) {
  let url = allowedUrl(value);
  for (let count = 0; count < 9; count += 1) {
    const response = await fetch(url, { method: 'GET', redirect: 'manual', credentials: 'omit', signal });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get('location');
      await response.body?.cancel();
      if (!location) throw new Error('DOWNLOAD_REDIRECT_INVALID');
      url = allowedUrl(new URL(location, url).href);
      continue;
    }
    if (response.status !== 200 || !response.body) throw new Error('DOWNLOAD_HTTP_' + response.status);
    return response;
  }
  throw new Error('DOWNLOAD_REDIRECT_LIMIT');
}
async function smallText(url, signal) {
  const response = await readResponse(url, signal);
  const chunks = [];
  let size = 0;
  for await (const chunk of response.body) {
    size += chunk.length;
    if (size > 2097152) throw new Error('METADATA_TOO_LARGE');
    chunks.push(chunk);
  }
  return new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks));
}
async function digestFile(path) {
  const digest = createHash('sha256');
  for await (const chunk of createReadStream(path)) digest.update(chunk);
  return digest.digest('hex');
}
async function run(args) {
  const signal = AbortSignal.timeout(600000);
  if (args.length === 1 && args[0] === 'jdk-metadata') {
    const document = JSON.parse(await smallText('https://api.adoptium.net/v3/assets/latest/17/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse', signal));
    const item = document?.[0]?.binary?.package;
    if (!item || !/^OpenJDK17U-jdk_x64_windows_hotspot_.*\.zip$/.test(item.name)
        || !/^https:\/\/github\.com\/adoptium\/temurin17-binaries\/releases\/download\//.test(item.link)
        || !/^[a-f0-9]{64}$/i.test(item.checksum)) throw new Error('JDK_METADATA_INVALID');
    return { name: item.name, link: item.link, checksum: item.checksum, size: item.size };
  }
  if (args.length === 1 && args[0] === 'gradle-checksum') {
    const checksum = (await smallText('https://downloads.gradle.org/distributions/gradle-8.13-bin.zip.sha256', signal)).trim();
    if (!/^[a-f0-9]{64}$/i.test(checksum)) throw new Error('GRADLE_CHECKSUM_INVALID');
    return { checksum };
  }
  if (args.length === 4 && args[0] === 'archive') {
    const [, url, expected, file] = args;
    allowedUrl(url);
    if (!/^[a-f0-9]{64}$/i.test(expected)) throw new Error('ARCHIVE_CHECKSUM_INVALID');
    const destination = resolve(file);
    if (!destination.startsWith(root + sep)) throw new Error('ARCHIVE_PATH_OUTSIDE_WORKSPACE');
    let exists = false;
    try { await access(destination); exists = true; } catch {}
    if (!exists) {
      const temporary = destination + '.partial-' + Date.now();
      const response = await readResponse(url, signal);
      let bytes = 0;
      const bounded = new Transform({ transform(chunk, _encoding, callback) {
        bytes += chunk.length;
        callback(bytes > 1073741824 ? new Error('ARCHIVE_TOO_LARGE') : null, chunk);
      } });
      await pipeline(Readable.fromWeb(response.body), bounded, createWriteStream(temporary, { flags: 'wx' }), { signal });
      if ((await digestFile(temporary)) !== expected.toLowerCase()) throw new Error('ARCHIVE_CHECKSUM_MISMATCH');
      await rename(temporary, destination);
    }
    const sha256 = await digestFile(destination);
    if (sha256 !== expected.toLowerCase()) throw new Error('ARCHIVE_CHECKSUM_MISMATCH');
    return { path: destination, source: url, sha256, bytes: (await stat(destination)).size };
  }
  throw new Error('DOWNLOAD_HELPER_USAGE');
}
try { process.stdout.write(JSON.stringify(await run(process.argv.slice(2))) + '\n'); }
catch (error) {
  const candidate = error?.cause?.code ?? error?.code ?? error?.message;
  const code = typeof candidate === 'string' && /^[A-Z0-9_]{3,70}$/.test(candidate) ? candidate : 'NETWORK_OR_DOWNLOAD_FAILED';
  process.stdout.write(JSON.stringify({ error: code }) + '\n');
  process.exitCode = 1;
}
