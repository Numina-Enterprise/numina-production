# 500T NUSD deployment handoff

This is an unsigned preparation checklist for the approved **v3 uncapped candidate** and three dependent contracts. The initial amount is **500,000,000,000,000 NUSD**, or **500,000,000,000,000,000,000 base units** at six decimals. The existing native treasury is referenced once; this package adds no native or provider balance.

## Version and evidence

- v3 has **eight constructor arguments** and **no `cap()` getter**. Its finite numeric maximum is uint256. The older capped-v2 request/encoder had nine arguments and different artifact pins; do not reuse its creation data.
- The positive initial amount is minted to the explicit recipient during a successful deployment, before the token pauses. The owner must review this consequence before signing.
- The supplied administrator, issuer, minter and pauser addresses are retained in **known-inputs.json**. Their key custody and on-chain assignments are unverified.
- Nine local Ganache tests passed, including exact 500T issuance once to one synthetic recipient. These used ephemeral test accounts and a synthetic policy, not production wallets. The copied local report is under **reference/**.
- All current production recipients, transaction data, signatures, token addresses and receipts remain null.

## Owner signing and verification sequence

1. Resolve **network-inputs.json**: reviewed RPC/authentication reference, chain ID and genesis, sender and signing control, native fee asset, fresh nonce, exact gas estimate and an explicit fee budget. Keep credentials outside these files.
2. Supply the native NUSD initial recipient and genuine evidence for all eight review records in **requests/NuminaUSD.constructor-review.json**. The historically supplied Stripe USDC address is separately labeled; it is not assumed to be the NUSD recipient. Confirm the exact issuer policy bytes/hash and four distinct token roles.
3. Use an encoder explicitly supporting this v3 artifact and eight-argument ABI. Generate data only after required inputs are complete; include the reviewed source, artifact, request and policy hashes. The old capped-v2 encoder is incompatible. This package contains no encoded transaction.
4. The owner independently reviews the full constructor, chain identity, sender, nonce, amount, recipient, roles and fee ceiling, then signs and submits that specific deployment from their wallet. Each later transaction needs its own complete review and signature.
5. Obtain the actual transaction and receipt. Use **token-receipt-verification.json** to verify success, canonical finality, exact creation data, constructor-bound runtime, roles/delay, policy hash, six decimals, one exact initial mint, supply/recipient balance and paused state at the deployment block. **Do not call `cap()` for v3.** Preserve the verified receipt and only then record its NUSD address.
6. Place that same confirmed NUSD address into all three sheets in **dependent-inputs/**. Review the proposed admin/pauser reuse and delay separately. Supply the missing liquidity manager, bank operator and distinct bank confirmer; these roles are not inferred from issuer/minter roles.
7. For conversion, establish the **official six-decimal USDC contract on that same chain** from actual issuer/provider evidence. Its symbol or decimals alone do not prove identity. If there is no verified official USDC on the selected chain, leave conversion unresolved. The contract does not bridge assets or create USDC.
8. Retest each dependent with the exact v3 token, derive its constructor immutable mapping from reproducible compilation, and finish its complete unsigned transaction. The owner reviews and signs each deployment separately; verify its own final receipt, runtime and configured token/roles before use. The current dependent artifacts omit immutable offsets, so direct comparison with their unbound runtime templates is insufficient.
9. Any unpause, role grant, token approval, liquidity funding, settlement, conversion, redemption or bank payment is a separate fully specified transaction/operation. Conversion requires actual funded output liquidity. Bank payout requires a configured funded provider operation and a real bank receipt; an on-chain attestation hash is only a reference.

## Dependent sheets

| Contract | Constructor inputs | Still missing |
| --- | --- | --- |
| NuminaSettlement | nusdToken | Confirmed NUSD deployment address |
| NuminaUSDCConversion | nusdToken, usdcToken, admin, liquidityManager, pauser, adminDelaySeconds | Confirmed NUSD, official same-chain USDC, liquidity manager; review proposed admin/pauser/delay |
| NuminaUSDRedemption | nusdToken, admin, operator, confirmer, pauser, adminDelaySeconds | Confirmed NUSD, operator, independent confirmer; review proposed admin/pauser/delay |

The machine-readable **unresolved-inputs.json** separates requirements before signing from evidence obtained after submission. Every sheet has an empty wallet-transaction record, references exact source/artifact hashes and leaves the result unsubmitted. Paths inside these records resolve from this package root.

No private keys, RPC credentials, signatures, encoded deployment, production chain receipt or provider deposit are created by this handoff.
